package com.mideast.history.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Handshake
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mideast.history.data.local.entity.CountryEntity
import com.mideast.history.ui.theme.*

@Composable
fun RelationsScreen(
    countries: List<CountryEntity>,
    modifier: Modifier = Modifier
) {
    var countryA by remember { mutableStateOf(countries.getOrNull(0)) }
    var countryB by remember { mutableStateOf(countries.getOrNull(1)) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        Text(
            text = "مقارنة وتحليل العلاقات الثنائية",
            style = MaterialTheme.typography.titleLarge,
            color = GoldPrimary,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "استكشف أواصر التعاون والاتفاقيات والمحطات الدبلوماسية المشتركة بين دول المنطقة",
            style = MaterialTheme.typography.bodyMedium,
            color = TextSecondary
        )

        // Selectors Card
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = DarkSurface,
            border = androidx.compose.foundation.BorderStroke(1.dp, DarkSurfaceBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "الدولة الأولى: ${countryA?.flagEmoji ?: ""} ${countryA?.nameAr ?: ""}",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = GoldLight
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.SwapHoriz,
                        contentDescription = "تبديل",
                        tint = GoldPrimary,
                        modifier = Modifier.size(28.dp)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "الدولة الثانية: ${countryB?.flagEmoji ?: ""} ${countryB?.nameAr ?: ""}",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = AccentCyan
                    )
                }
            }
        }

        // Bilateral Analysis Result Card
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = DarkSurface,
            border = androidx.compose.foundation.BorderStroke(1.dp, GoldPrimary.copy(alpha = 0.5f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(Icons.Default.Handshake, contentDescription = null, tint = GoldPrimary)
                    Text(
                        text = "ملف الشراكة والروابط المشتركة",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                }

                HorizontalDivider(color = DarkSurfaceBorder.copy(alpha = 0.5f))

                RelationDetailItem(
                    title = "العلاقات الدبلوماسية والتاريخية",
                    description = "علاقات أخوية وتاريخية متجذرة تستند إلى روابط اللغة والدين والجوار الجغرافي والمصير المشترك في إطار جامعة الدول العربية والمنظمات الإقليمية."
                )

                RelationDetailItem(
                    title = "التبادل الاقتصادي والاستثماري",
                    description = "شراكات تجارية متنامية في مجالات الطاقة، والخدمات اللوجستية، والأمن الغذائي، والمشاريع التنموية المشتركة مع حرية انتقال رؤوس الأموال."
                )

                RelationDetailItem(
                    title = "التنسيق الاستراتيجي والأمني",
                    description = "تنسيق متواصل لحفظ أمن واستقرار الممرات المائية والملاحة الدولية في البحر الأحمر والخليج العربي، ومكافحة الإرهاب وتعزيز السلام الإقليمي."
                )
            }
        }

        Spacer(modifier = Modifier.height(70.dp))
    }
}

@Composable
fun RelationDetailItem(title: String, description: String) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = GoldLight
        )
        Text(
            text = description,
            style = MaterialTheme.typography.bodyMedium,
            color = TextSecondary,
            lineHeight = 22.sp
        )
    }
}
