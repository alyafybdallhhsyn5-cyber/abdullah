package com.mideast.history.ui.theme

import androidx.compose.ui.graphics.Color

// Background & Surface Colors (Dark Aesthetic)
val DarkBackground = Color(0xFF080C14)
val DarkSurface = Color(0xFF0F172A)
val DarkSurfaceVariant = Color(0xFF1E293B)
val DarkSurfaceBorder = Color(0xFF334155)

// Brand Gold & Amber Gradients
val GoldPrimary = Color(0xFFF59E0B)
val GoldLight = Color(0xFFFBBF24)
val GoldDark = Color(0xFFB45309)
val GoldContainer = Color(0x33F59E0B)

// Accent Colors
val AccentCyan = Color(0xFF06B6D4)
val AccentEmerald = Color(0xFF10B981)
val AccentIndigo = Color(0xFF6366F1)
val AccentRose = Color(0xFFF43F5E)

// Text & Content Colors
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
