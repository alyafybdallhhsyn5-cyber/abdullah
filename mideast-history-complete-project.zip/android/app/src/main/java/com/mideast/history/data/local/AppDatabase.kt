package com.mideast.history.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.mideast.history.data.local.dao.BookmarkDao
import com.mideast.history.data.local.dao.CountryDao
import com.mideast.history.data.local.dao.QuizScoreDao
import com.mideast.history.data.local.entity.BookmarkEntity
import com.mideast.history.data.local.entity.CountryEntity
import com.mideast.history.data.local.entity.QuizScoreEntity
import com.mideast.history.data.local.entity.WarEntity
import com.mideast.history.data.model.MiddleEastInitialData
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        CountryEntity::class,
        WarEntity::class,
        BookmarkEntity::class,
        QuizScoreEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun countryDao(): CountryDao
    abstract fun bookmarkDao(): BookmarkDao
    abstract fun quizScoreDao(): QuizScoreDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "mideast_history.db"
                )
                    .addCallback(AppDatabaseCallback(scope))
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private class AppDatabaseCallback(
            private val scope: CoroutineScope
        ) : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    scope.launch(Dispatchers.IO) {
                        // Seed initial 20 countries so app works 100% offline out-of-the-box
                        database.countryDao().insertCountries(MiddleEastInitialData.getSeedCountries())
                    }
                }
            }
        }
    }
}
