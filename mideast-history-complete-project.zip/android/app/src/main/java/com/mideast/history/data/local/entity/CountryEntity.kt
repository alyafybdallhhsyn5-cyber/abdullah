package com.mideast.history.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "countries")
data class CountryEntity(
    @PrimaryKey val id: String,
    val nameAr: String,
    val nameEn: String,
    val capital: String,
    val population: String,
    val area: String,
    val currency: String,
    val flagEmoji: String,
    val region: String, // "الخليج العربي", "بلاد الشام والعراق", "شمال أفريقيا"
    val ancientCivilization: String,
    val islamicEra: String,
    val modernEra: String,
    val economicOverview: String,
    val keyMonuments: String, // Comma-separated or JSON list
    val isBookmarked: Boolean = false
)
