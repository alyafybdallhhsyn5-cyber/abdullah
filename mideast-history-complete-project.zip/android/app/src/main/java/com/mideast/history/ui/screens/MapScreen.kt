package com.mideast.history.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CompassCalibration
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Public
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mideast.history.data.local.entity.CountryEntity
import com.mideast.history.ui.theme.*

@Composable
fun MapScreen(
    countries: List<CountryEntity>,
    onSelectCountry: (CountryEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Hero Map Header Card
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = DarkSurface,
            border = androidx.compose.foundation.BorderStroke(1.dp, GoldPrimary.copy(alpha = 0.5f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .background(
                                Brush.linearGradient(listOf(GoldLight, GoldDark)),
                                RoundedCornerShape(8.dp)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Public, contentDescription = null, tint = DarkBackground, modifier = Modifier.size(18.dp))
                    }
                    Text(
                        text = "خريطة وأقاليم الشرق الأوسط",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                }

                Text(
                    text = "موقع استراتيجي يربط قارات آسيا وأفريقيا وأوروبا، ويطل على أهم المضائق البحرية العالمية (هرمز، باب المندب، وقناة السويس).",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary,
                    lineHeight = 22.sp
                )
            }
        }

        // Region 1: Arabian Gulf
        RegionCard(
            title = "إقليم الجزيرة والخليج العربي",
            description = "موطن الحضارات القديمة وطرق القوافل، ومهبط الرسالة الإسلامية، وأكبر مركز لإنتاج الطاقة عالمياً.",
            countries = countries.filter { it.region == "الخليج العربي" },
            accentColor = GoldPrimary,
            onSelectCountry = onSelectCountry
        )

        // Region 2: Levant & Mesopotamia
        RegionCard(
            title = "بلاد الشام وحوض الرافدين (الهلال الخصيب)",
            description = "مهد أولى الحضارات الإنسانية في سومر وبابل وأوغاريت وعواصم الخلافة الإسلامية في دمشق وبغداد.",
            countries = countries.filter { it.region == "بلاد الشام والعراق" },
            accentColor = AccentCyan,
            onSelectCountry = onSelectCountry
        )

        // Region 3: North Africa
        RegionCard(
            title = "شمال أفريقيا ووادي النيل",
            description = "حضارة وادي النيل الفرعونية، وشريان قناة السويس، وبوابة الفتوحات نحو المغرب العربي والأندلس.",
            countries = countries.filter { it.region == "شمال أفريقيا" },
            accentColor = AccentEmerald,
            onSelectCountry = onSelectCountry
        )

        Spacer(modifier = Modifier.height(70.dp))
    }
}

@Composable
fun RegionCard(
    title: String,
    description: String,
    countries: List<CountryEntity>,
    accentColor: Color,
    onSelectCountry: (CountryEntity) -> Unit
) {
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = DarkSurface,
        border = androidx.compose.foundation.BorderStroke(1.dp, DarkSurfaceBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(Icons.Default.LocationOn, contentDescription = null, tint = accentColor, modifier = Modifier.size(18.dp))
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            }

            Text(
                text = description,
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary,
                lineHeight = 20.sp
            )

            HorizontalDivider(color = DarkSurfaceBorder.copy(alpha = 0.5f))

            // Country Chips in this Region
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                countries.take(4).forEach { country ->
                    Surface(
                        onClick = { onSelectCountry(country) },
                        shape = RoundedCornerShape(12.dp),
                        color = DarkSurfaceVariant,
                        border = androidx.compose.foundation.BorderStroke(1.dp, DarkSurfaceBorder)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(country.flagEmoji, fontSize = 14.sp)
                            Text(country.nameAr, fontSize = 11.sp, color = TextPrimary, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }
        }
    }
}
