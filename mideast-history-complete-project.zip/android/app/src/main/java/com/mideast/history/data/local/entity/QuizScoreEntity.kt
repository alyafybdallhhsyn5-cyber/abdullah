package com.mideast.history.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "quiz_scores")
data class QuizScoreEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val category: String,
    val score: Int,
    val total: Int,
    val percentage: Int,
    val timestamp: Long = System.currentTimeMillis()
)
