package com.mideast.history.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.mideast.history.data.local.entity.CountryEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface CountryDao {
    @Query("SELECT * FROM countries ORDER BY nameAr ASC")
    fun getAllCountries(): Flow<List<CountryEntity>>

    @Query("SELECT * FROM countries WHERE id = :countryId LIMIT 1")
    suspend fun getCountryById(countryId: String): CountryEntity?

    @Query("SELECT * FROM countries WHERE region = :region ORDER BY nameAr ASC")
    fun getCountriesByRegion(region: String): Flow<List<CountryEntity>>

    @Query("SELECT * FROM countries WHERE nameAr LIKE '%' || :query || '%' OR capital LIKE '%' || :query || '%'")
    fun searchCountries(query: String): Flow<List<CountryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCountries(countries: List<CountryEntity>)

    @Update
    suspend fun updateCountry(country: CountryEntity)
}
