package com.mideast.history.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AwardStar
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mideast.history.ui.theme.*

data class QuizQuestion(
    val id: Int,
    val question: String,
    val options: List<String>,
    val correctIndex: Int,
    val explanation: String
)

@Composable
fun QuizScreen(
    onSaveScore: (score: Int, total: Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val questions = remember {
        listOf(
            QuizQuestion(
                id = 1,
                question = "ما هي المدينة التي كانت عاصمة الخلافة الأموية الكبرى؟",
                options = listOf("القاهرة", "دمشق", "بغداد", "المدينة المنورة"),
                correctIndex = 1,
                explanation = "دمشق كانت عاصمة الدولة الأموية منذ تأسيسها عام 661م حتى سقوطها عام 750م."
            ),
            QuizQuestion(
                id = 2,
                question = "في أي عام تم توحيد المملكة العربية السعودية تحت اسمها الحالي؟",
                options = listOf("1902م", "1924م", "1932م", "1945م"),
                correctIndex = 2,
                explanation = "أعلن الملك عبدالعزيز آل سعود طيب الله ثراه توحيد المملكة في 23 سبتمبر 1932م."
            ),
            QuizQuestion(
                id = 3,
                question = "ما هي الحضارة القديمة التي اشتهرت بنحت مدينة البتراء في الصخر الوردي؟",
                options = listOf("الأنباط", "الفينيقيون", "الكنعانيون", "البابليون"),
                correctIndex = 0,
                explanation = "حضارة الأنباط العربية شيدت ونحتت عاصمتها البتراء في جنوب الأردن."
            ),
            QuizQuestion(
                id = 4,
                question = "ما هي أقدم أبجدية صوتية كاملة موثقة في التاريخ واكتُشفت في ساحل سوريا؟",
                options = listOf("الهيروغليفية", "الأبجدية الأوغاريتية", "المسمارية السومرية", "الآرامية"),
                correctIndex = 1,
                explanation = "أبجدية رأس شمرا (أوغاريت) تعود للقرن الرابع عشر قبل الميلاد وهي أقدم أبجدية صوتية متكاملة."
            ),
            QuizQuestion(
                id = 5,
                question = "من القائد الإسلامي الذي انتصر في معركة حطين عام 1187م واسترد القدس؟",
                options = listOf("خالد بن الوليد", "الناصر صلاح الدين الأيوبي", "سيف الدين قطز", "طارق بن زياد"),
                correctIndex = 1,
                explanation = "الناصر صلاح الدين الأيوبي قاد الجيش الإسلامي الموحد في معركة حطين وحرر القدس الشريف."
            )
        )
    }

    var currentIndex by remember { mutableIntStateOf(0) }
    var selectedOption by remember { mutableStateOf<Int?>(null) }
    var score by remember { mutableIntStateOf(0) }
    var isAnswered by remember { mutableStateOf(false) }
    var isQuizCompleted by remember { mutableStateOf(false) }

    val currentQuestion = questions.getOrNull(currentIndex)

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "مسابقة المؤرخ التفاعلية",
                    style = MaterialTheme.typography.titleLarge,
                    color = GoldPrimary,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "اختبر معلوماتك التاريخية واكسب وسام الباحث التاريخي",
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondary
                )
            }

            Surface(
                shape = RoundedCornerShape(12.dp),
                color = DarkSurfaceVariant,
                border = androidx.compose.foundation.BorderStroke(1.dp, GoldPrimary)
            ) {
                Text(
                    text = "النقاط: $score",
                    color = GoldLight,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                )
            }
        }

        if (isQuizCompleted) {
            // Quiz Completed Card
            Surface(
                shape = RoundedCornerShape(24.dp),
                color = DarkSurface,
                border = androidx.compose.foundation.BorderStroke(1.dp, GoldPrimary),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text(text = "🏆", fontSize = 48.sp)
                    Text(
                        text = "اكتمل الاختبار بنجاح!",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = GoldPrimary
                    )
                    Text(
                        text = "حصلت على $score من أصل ${questions.size} إجابات صحيحة (${(score * 100) / questions.size}%)",
                        style = MaterialTheme.typography.bodyLarge,
                        color = TextPrimary
                    )

                    Button(
                        onClick = {
                            currentIndex = 0
                            selectedOption = null
                            score = 0
                            isAnswered = false
                            isQuizCompleted = false
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = null, tint = DarkBackground)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("إعادة الاختبار مرة أخرى", color = DarkBackground, fontWeight = FontWeight.Bold)
                    }
                }
            }
        } else if (currentQuestion != null) {
            // Question Progress
            LinearProgressIndicator(
                progress = { (currentIndex + 1).toFloat() / questions.size.toFloat() },
                modifier = Modifier.fillMaxWidth(),
                color = GoldPrimary,
                trackColor = DarkSurfaceBorder
            )

            Text(
                text = "السؤال ${currentIndex + 1} من ${questions.size}:",
                style = MaterialTheme.typography.labelSmall,
                color = GoldLight,
                fontWeight = FontWeight.Bold
            )

            // Question Card
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = DarkSurface,
                border = androidx.compose.foundation.BorderStroke(1.dp, DarkSurfaceBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text(
                        text = currentQuestion.question,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary,
                        lineHeight = 26.sp
                    )

                    // Options
                    currentQuestion.options.forEachIndexed { index, option ->
                        val isSelected = selectedOption == index
                        val isCorrect = index == currentQuestion.correctIndex

                        val containerColor = when {
                            !isAnswered && isSelected -> GoldContainer
                            isAnswered && isCorrect -> Color(0x3310B981)
                            isAnswered && isSelected && !isCorrect -> Color(0x33EF4444)
                            else -> DarkSurfaceVariant
                        }

                        val borderColor = when {
                            !isAnswered && isSelected -> GoldPrimary
                            isAnswered && isCorrect -> AccentEmerald
                            isAnswered && isSelected && !isCorrect -> Color(0xFFEF4444)
                            else -> DarkSurfaceBorder
                        }

                        Surface(
                            onClick = {
                                if (!isAnswered) {
                                    selectedOption = index
                                }
                            },
                            shape = RoundedCornerShape(14.dp),
                            color = containerColor,
                            border = androidx.compose.foundation.BorderStroke(1.dp, borderColor),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = option,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = TextPrimary
                                )
                                if (isAnswered && isCorrect) {
                                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = AccentEmerald)
                                }
                            }
                        }
                    }

                    // Explanation Box if Answered
                    if (isAnswered) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = Color(0x22F59E0B),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "💡 المعلومة: ${currentQuestion.explanation}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = GoldLight,
                                modifier = Modifier.padding(12.dp),
                                lineHeight = 20.sp
                            )
                        }
                    }

                    // Action Button
                    Button(
                        onClick = {
                            if (!isAnswered) {
                                if (selectedOption != null) {
                                    isAnswered = true
                                    if (selectedOption == currentQuestion.correctIndex) {
                                        score += 1
                                    }
                                }
                            } else {
                                if (currentIndex < questions.size - 1) {
                                    currentIndex += 1
                                    selectedOption = null
                                    isAnswered = false
                                } else {
                                    isQuizCompleted = true
                                    onSaveScore(score, questions.size)
                                }
                            }
                        },
                        enabled = selectedOption != null,
                        colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = if (!isAnswered) "تأكيد الإجابة" else if (currentIndex < questions.size - 1) "السؤال التالي ⬅️" else "عرض النتيجة النهائية 🏆",
                            color = DarkBackground,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}
