package com.mideast.history.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "wars")
data class WarEntity(
    @PrimaryKey val id: String,
    val title: String,
    val period: String,
    val participants: String,
    val causes: String,
    val events: String,
    val outcome: String,
    val impact: String
)
