package com.mideast.history.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mideast.history.data.local.entity.WarEntity
import com.mideast.history.data.model.MiddleEastInitialData
import com.mideast.history.ui.theme.*

@Composable
fun WarsScreen(
    modifier: Modifier = Modifier
) {
    val wars = remember { MiddleEastInitialData.getSeedWars() }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
            .padding(horizontal = 16.dp)
    ) {
        Spacer(modifier = Modifier.height(12.dp))

        // Screen Header
        Text(
            text = "سجل الحروب والمعارك الكبرى",
            style = MaterialTheme.typography.titleLarge,
            color = GoldPrimary,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "محطات فاصلة أعادت رسم خرائط الشرق الأوسط وتوازنات القوى عبر العصور",
            style = MaterialTheme.typography.bodyMedium,
            color = TextSecondary
        )

        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(14.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(wars, key = { it.id }) { war ->
                WarCard(war = war)
            }

            item {
                Spacer(modifier = Modifier.height(80.dp))
            }
        }
    }
}

@Composable
fun WarCard(war: WarEntity) {
    var isExpanded by remember { mutableStateOf(false) }

    Surface(
        onClick = { isExpanded = !isExpanded },
        shape = RoundedCornerShape(18.dp),
        color = DarkSurface,
        border = androidx.compose.foundation.BorderStroke(1.dp, if (isExpanded) GoldPrimary else DarkSurfaceBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = null,
                        tint = GoldPrimary,
                        modifier = Modifier.size(20.dp)
                    )
                    Column {
                        Text(
                            text = war.title,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Text(
                            text = "الفترة: ${war.period}",
                            style = MaterialTheme.typography.labelSmall,
                            color = GoldLight
                        )
                    }
                }

                Icon(
                    imageVector = if (isExpanded) Icons.Default.ExpandMore else Icons.Default.ChevronLeft,
                    contentDescription = null,
                    tint = TextMuted
                )
            }

            Text(
                text = "الأطراف: ${war.participants}",
                style = MaterialTheme.typography.bodyMedium,
                color = AccentCyan
            )

            AnimatedVisibility(visible = isExpanded) {
                Column(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.padding(top = 8.dp)
                ) {
                    HorizontalDivider(color = DarkSurfaceBorder.copy(alpha = 0.5f))

                    WarDetailSection(label = "الأسباب والدوافع", text = war.causes)
                    WarDetailSection(label = "أبرز الوقائع والمجريات", text = war.events)
                    WarDetailSection(label = "النتائج والآثار العسكرية", text = war.outcome)
                    WarDetailSection(label = "التأثير الاستراتيجي بعيد المدى", text = war.impact)
                }
            }
        }
    }
}

@Composable
fun WarDetailSection(label: String, text: String) {
    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = GoldPrimary
        )
        Text(
            text = text,
            style = MaterialTheme.typography.bodyMedium,
            color = TextSecondary,
            lineHeight = 22.sp
        )
    }
}
