package com.mideast.history

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.*
import androidx.lifecycle.lifecycleScope
import com.mideast.history.data.local.AppDatabase
import com.mideast.history.data.local.entity.CountryEntity
import com.mideast.history.data.local.entity.QuizScoreEntity
import com.mideast.history.data.model.MiddleEastInitialData
import com.mideast.history.ui.screens.MainScreen
import com.mideast.history.ui.theme.MiddleEastHistoryTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private lateinit var database: AppDatabase
    private var isOnlineState = mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // 1. Initialize Room Database for 100% complete offline access
        database = AppDatabase.getDatabase(applicationContext, lifecycleScope)

        // Pre-populate if empty
        lifecycleScope.launch(Dispatchers.IO) {
            val count = database.countryDao().getCountryById("saudi-arabia")
            if (count == null) {
                database.countryDao().insertCountries(MiddleEastInitialData.getSeedCountries())
            }
        }

        // 2. Register Network Connectivity Monitor for Seamless Offline/Online Switching
        registerNetworkCallback()

        setContent {
            MiddleEastHistoryTheme {
                val countries by database.countryDao().getAllCountries()
                    .collectAsState(initial = MiddleEastInitialData.getSeedCountries())

                val isOnline by remember { isOnlineState }

                MainScreen(
                    countries = countries,
                    isOnline = isOnline,
                    onToggleBookmark = { country ->
                        lifecycleScope.launch(Dispatchers.IO) {
                            val updated = country.copy(isBookmarked = !country.isBookmarked)
                            database.countryDao().updateCountry(updated)
                        }
                    },
                    onSaveQuizScore = { score, total ->
                        lifecycleScope.launch(Dispatchers.IO) {
                            val percentage = (score * 100) / total
                            database.quizScoreDao().insertScore(
                                QuizScoreEntity(
                                    category = "general_history",
                                    score = score,
                                    total = total,
                                    percentage = percentage
                                )
                            )
                        }
                    }
                )
            }
        }
    }

    private fun registerNetworkCallback() {
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val activeNetwork = connectivityManager.activeNetwork
        val capabilities = connectivityManager.getNetworkCapabilities(activeNetwork)
        isOnlineState.value = capabilities?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true

        val request = NetworkRequest.Builder()
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .build()

        connectivityManager.registerNetworkCallback(request, object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                runOnUiThread { isOnlineState.value = true }
            }

            override fun onLost(network: Network) {
                runOnUiThread { isOnlineState.value = false }
            }
        })
    }
}
