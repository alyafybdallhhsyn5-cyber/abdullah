package com.mideast.history.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "bookmarks")
data class BookmarkEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val itemType: String, // "country" | "war"
    val itemId: String,
    val title: String,
    val notes: String? = null,
    val timestamp: Long = System.currentTimeMillis(),
    val isSynced: Boolean = false // Synced with remote PostgreSQL/Firebase
)
