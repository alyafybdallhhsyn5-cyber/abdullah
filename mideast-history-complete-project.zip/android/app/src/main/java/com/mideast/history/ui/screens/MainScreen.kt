package com.mideast.history.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.mideast.history.data.local.entity.CountryEntity
import com.mideast.history.ui.components.HistoryTopBar
import com.mideast.history.ui.theme.*

enum class HistoryTab(val title: String, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
    MAP("الخريطة", Icons.Default.Public),
    COUNTRIES("الدول", Icons.Default.AccountBalance),
    WARS("الحروب", Icons.Default.Shield),
    RELATIONS("العلاقات", Icons.Default.Handshake),
    QUIZ("المسابقة", Icons.Default.EmojiEvents)
}

@Composable
fun MainScreen(
    countries: List<CountryEntity>,
    isOnline: Boolean,
    onToggleBookmark: (CountryEntity) -> Unit,
    onSaveQuizScore: (score: Int, total: Int) -> Unit
) {
    var currentTab by remember { mutableStateOf(HistoryTab.MAP) }
    var selectedCountry by remember { mutableStateOf<CountryEntity?>(null) }
    var showDesignerDialog by remember { mutableStateOf(false) }

    // Enforce Right-to-Left (RTL) Arabic layout direction
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            topBar = {
                HistoryTopBar(
                    isOnline = isOnline,
                    onDesignerClick = { showDesignerDialog = true }
                )
            },
            bottomBar = {
                NavigationBar(
                    containerColor = DarkBackground,
                    tonalElevation = 8.dp
                ) {
                    HistoryTab.entries.forEach { tab ->
                        val isSelected = currentTab == tab
                        NavigationBarItem(
                            selected = isSelected,
                            onClick = {
                                selectedCountry = null
                                currentTab = tab
                            },
                            icon = {
                                Icon(
                                    imageVector = tab.icon,
                                    contentDescription = tab.title,
                                    tint = if (isSelected) DarkBackground else TextMuted
                                )
                            },
                            label = {
                                Text(
                                    text = tab.title,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    fontSize = 11.sp
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                indicatorColor = GoldPrimary,
                                selectedTextColor = GoldLight,
                                unselectedTextColor = TextMuted
                            )
                        )
                    }
                }
            },
            containerColor = DarkBackground
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (selectedCountry != null) {
                    CountryDetailScreen(
                        country = selectedCountry!!,
                        onBackClick = { selectedCountry = null },
                        onToggleBookmark = { onToggleBookmark(selectedCountry!!) }
                    )
                } else {
                    when (currentTab) {
                        HistoryTab.MAP -> MapScreen(
                            countries = countries,
                            onSelectCountry = { selectedCountry = it }
                        )
                        HistoryTab.COUNTRIES -> CountriesScreen(
                            countries = countries,
                            onSelectCountry = { selectedCountry = it },
                            onToggleBookmark = onToggleBookmark
                        )
                        HistoryTab.WARS -> WarsScreen()
                        HistoryTab.RELATIONS -> RelationsScreen(countries = countries)
                        HistoryTab.QUIZ -> QuizScreen(onSaveScore = onSaveQuizScore)
                    }
                }
            }
        }

        // Designer Bio Modal (Without ZIP Download)
        if (showDesignerDialog) {
            Dialog(onDismissRequest = { showDesignerDialog = false }) {
                Surface(
                    shape = RoundedCornerShape(24.dp),
                    color = DarkSurface,
                    border = androidx.compose.foundation.BorderStroke(1.dp, GoldPrimary),
                    modifier = Modifier.fillMaxWidth().padding(16.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(text = "👑", fontSize = 36.sp)
                        Text(
                            text = "تصميم وتطوير: عبدالله حسين",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = GoldPrimary
                        )
                        Text(
                            text = "حساب المصمم: @n.0a21",
                            style = MaterialTheme.typography.bodyMedium,
                            color = AccentCyan
                        )
                        HorizontalDivider(color = DarkSurfaceBorder)
                        Text(
                            text = "تم بناء هذا التطبيق كمنصة وثائقية رقمية تفاعلية تعرّف الأجيال بتاريخ الشرق الأوسط وحضاراته العريقة من العصور القديمة والإسلامية وحتى العصر الحديث والمعاصر.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary,
                            lineHeight = 22.sp
                        )
                        Button(
                            onClick = { showDesignerDialog = false },
                            colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("إغلاق", color = DarkBackground, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}
