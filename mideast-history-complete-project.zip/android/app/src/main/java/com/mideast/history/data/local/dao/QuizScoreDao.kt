package com.mideast.history.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.mideast.history.data.local.entity.QuizScoreEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface QuizScoreDao {
    @Query("SELECT * FROM quiz_scores ORDER BY timestamp DESC")
    fun getAllScores(): Flow<List<QuizScoreEntity>>

    @Query("SELECT MAX(score) FROM quiz_scores WHERE category = :category")
    suspend fun getHighScoreByCategory(category: String): Int?

    @Insert
    suspend fun insertScore(score: QuizScoreEntity): Long
}
