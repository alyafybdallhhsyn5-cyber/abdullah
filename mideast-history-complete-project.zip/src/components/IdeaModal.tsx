import React, { useState } from 'react';
import { ProjectData } from '../types';
import { PRESET_PROJECTS, createCustomProjectFromIdea } from '../data/presets';
import { playSound } from '../utils/audio';
import confetti from 'canvas-confetti';
import { X, Sparkles, Send, Lightbulb, Check } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  currentProject: ProjectData;
  onSelectProject: (project: ProjectData) => void;
}

export const IdeaModal: React.FC<Props> = ({ isOpen, onClose, currentProject, onSelectProject }) => {
  const [customIdea, setCustomIdea] = useState('');
  const [projectType, setProjectType] = useState<'game' | 'app'>('game');

  if (!isOpen) return null;

  const handleSubmitCustom = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customIdea.trim()) return;

    const newProject = createCustomProjectFromIdea(customIdea.trim(), projectType);
    onSelectProject(newProject);
    playSound('success');
    confetti({
      particleCount: 50,
      spread: 70,
      origin: { y: 0.6 }
    });
    setCustomIdea('');
    onClose();
  };

  const handleSelectPreset = (p: ProjectData) => {
    onSelectProject(p);
    playSound('coin');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto animate-in fade-in">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-2xl w-full p-6 shadow-2xl relative my-8">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 left-5 p-2 rounded-xl bg-slate-800 text-slate-400 hover:text-white transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="mb-5 text-right">
          <div className="inline-flex items-center gap-1.5 bg-amber-500/20 text-amber-300 border border-amber-500/30 px-3 py-1 rounded-full text-xs font-bold mb-2">
            <Lightbulb className="w-3.5 h-3.5" />
            <span>ما هي فكرتك التي تريد تحويلها إلى مشروع حقيقي؟</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-black text-white font-heading">
            أدخل فكرتك البسيطة أو اختر من المشاريع الجاهزة
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            سواء كانت لعبة مغامرات سريعة أو تطبيق لخدمة معينة، سنقوم بتحويلها فوراً إلى المراحل الـ 9 ونموذج أولي يعمل على هاتفك.
          </p>
        </div>

        {/* Custom Idea Input Form */}
        <form onSubmit={handleSubmitCustom} className="mb-6 space-y-3">
          <div className="flex gap-2">
            <button
              type="button"
              onClick={() => setProjectType('game')}
              className={`flex-1 py-2 rounded-xl text-xs font-bold border transition-all ${
                projectType === 'game'
                  ? 'bg-amber-500/20 border-amber-500 text-amber-300'
                  : 'bg-slate-950 border-slate-800 text-slate-400'
              }`}
            >
              🎮 فكرة لعبة
            </button>
            <button
              type="button"
              onClick={() => setProjectType('app')}
              className={`flex-1 py-2 rounded-xl text-xs font-bold border transition-all ${
                projectType === 'app'
                  ? 'bg-indigo-500/20 border-indigo-500 text-indigo-300'
                  : 'bg-slate-950 border-slate-800 text-slate-400'
              }`}
            >
              📱 فكرة تطبيق
            </button>
          </div>

          <div className="relative">
            <textarea
              rows={3}
              value={customIdea}
              onChange={(e) => setCustomIdea(e.target.value)}
              placeholder="اكتب فكرتك هنا بأي لغة بسيطة... مثلاً: (لعبة سباق جمال في الصحراء، أو تطبيق تتبع كمية الماء والأذكار، أو تطبيق حاسبة مصاريف شهرية)..."
              className="w-full bg-slate-950 border border-slate-700/80 rounded-2xl p-4 text-xs sm:text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-indigo-500 transition-colors"
            />
          </div>

          {/* Quick Idea Starters */}
          <div className="flex flex-wrap gap-1.5 text-[11px]">
            <span className="text-slate-400 self-center">أفكار مقترحة سريعة:</span>
            {[
              'لعبة تفادي عوائق وقفز في الفضاء',
              'تطبيق مسبحة وأذكار مع عداد ذكي',
              'لعبة تخمين الأعلام والدول العربية',
              'تطبيق تدوين ملاحظات صوتية وكتابية'
            ].map((starter, sIdx) => (
              <button
                key={sIdx}
                type="button"
                onClick={() => setCustomIdea(starter)}
                className="bg-slate-800 hover:bg-slate-700 text-slate-300 px-2.5 py-1 rounded-lg transition-colors"
              >
                + {starter}
              </button>
            ))}
          </div>

          <button
            type="submit"
            disabled={!customIdea.trim()}
            className={`w-full py-3.5 rounded-2xl font-black text-sm flex items-center justify-center gap-2 shadow-lg transition-all ${
              customIdea.trim()
                ? 'bg-gradient-to-r from-indigo-600 via-purple-600 to-amber-500 text-white shadow-indigo-500/25 active:scale-98'
                : 'bg-slate-800 text-slate-500 cursor-not-allowed'
            }`}
          >
            <Sparkles className="w-4 h-4" />
            <span>تحويل فكرتي إلى مشروع وتطبيق حقيقي الآن 🚀</span>
          </button>
        </form>

        {/* Divider */}
        <div className="relative flex py-2 items-center mb-4">
          <div className="flex-grow border-t border-slate-800" />
          <span className="flex-shrink mx-4 text-xs text-slate-500 font-bold">أو اختر أحد المشاريع المكتملة فوراً</span>
          <div className="flex-grow border-t border-slate-800" />
        </div>

        {/* Preset Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-[260px] overflow-y-auto pr-1">
          {PRESET_PROJECTS.map((preset) => {
            const isCurrent = preset.id === currentProject.id;
            return (
              <div
                key={preset.id}
                onClick={() => handleSelectPreset(preset)}
                className={`p-3.5 rounded-2xl border text-right transition-all cursor-pointer flex items-start justify-between gap-3 ${
                  isCurrent
                    ? 'bg-indigo-950/40 border-indigo-500 text-white shadow-lg shadow-indigo-500/10'
                    : 'bg-slate-950/70 border-slate-800 hover:border-slate-700 text-slate-300'
                }`}
              >
                <div>
                  <div className="flex items-center gap-1.5 mb-1">
                    <span className="text-base">{preset.type === 'game' ? '🎮' : '📱'}</span>
                    <h4 className="text-xs font-bold text-white font-heading">{preset.title}</h4>
                  </div>
                  <p className="text-[11px] text-slate-400 line-clamp-2 leading-relaxed">
                    {preset.slogan}
                  </p>
                </div>

                {isCurrent && (
                  <span className="w-5 h-5 rounded-full bg-indigo-500 text-slate-950 flex items-center justify-center shrink-0">
                    <Check className="w-3 h-3 stroke-[3]" />
                  </span>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
