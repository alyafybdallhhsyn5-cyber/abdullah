import React, { useState } from 'react';
import { Country } from '../types/history';
import { playSound } from '../utils/audio';
import { MapPin, Compass, Globe, Sparkles } from 'lucide-react';

interface Props {
  countries: Country[];
  selectedCountry: Country;
  onSelectCountry: (country: Country) => void;
  activeEra: string;
}

export const MiddleEastMap: React.FC<Props> = ({
  countries,
  selectedCountry,
  onSelectCountry,
  activeEra
}) => {
  const [hoveredCountry, setHoveredCountry] = useState<Country | null>(null);

  return (
    <div className="relative w-full bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950 border border-slate-800 rounded-3xl p-4 sm:p-6 shadow-2xl overflow-hidden select-none">
      {/* Background Graticule / Subtle Compass Grid */}
      <div className="absolute inset-0 opacity-15 pointer-events-none bg-[radial-gradient(#d4af37_1px,transparent_1px)] [background-size:24px_24px]" />
      
      {/* Map Header Overlay */}
      <div className="relative z-10 flex flex-wrap items-center justify-between gap-3 mb-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-amber-400 mb-1">
            <Compass className="w-4 h-4 animate-spin-slow" />
            <span>الخريطة الجيوسياسية والتاريخية للشرق الأوسط</span>
          </div>
          <h3 className="text-lg sm:text-xl font-black text-white font-heading">
            انقر على أي دولة لاستعراض تاريخها وحاضرها
          </h3>
        </div>

        {/* Selected Country Quick Pill */}
        <div className="flex items-center gap-2 bg-slate-900/90 border border-amber-500/30 px-3 py-1.5 rounded-2xl shadow-sm">
          <span className="text-xl">{selectedCountry.flag}</span>
          <div className="text-right">
            <div className="text-xs font-bold text-white font-heading">{selectedCountry.name}</div>
            <div className="text-[10px] text-amber-400 font-mono">العاصمة: {selectedCountry.capital}</div>
          </div>
        </div>
      </div>

      {/* Interactive Map Canvas Container */}
      <div className="relative w-full aspect-[16/10] sm:aspect-[16/9] bg-slate-950/80 border border-slate-800/80 rounded-2xl overflow-hidden shadow-inner flex items-center justify-center">
        {/* Stylized SVG Map of Middle East Region */}
        <svg
          viewBox="0 0 1000 650"
          className="w-full h-full object-contain"
          style={{ filter: 'drop-shadow(0 4px 12px rgba(0,0,0,0.5))' }}
        >
          {/* Water Bodies (Red Sea, Persian Gulf, Mediterranean) */}
          <defs>
            <radialGradient id="waterGlow" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#0f172a" />
              <stop offset="100%" stopColor="#070a12" />
            </radialGradient>

            <linearGradient id="landGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#1e293b" />
              <stop offset="100%" stopColor="#0f172a" />
            </linearGradient>

            <linearGradient id="goldLandGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#b45309" />
              <stop offset="100%" stopColor="#78350f" />
            </linearGradient>
          </defs>

          {/* Background Ocean */}
          <rect width="1000" height="650" fill="url(#waterGlow)" />

          {/* Sea Label Watermarks */}
          <text x="140" y="240" fill="#334155" fontSize="18" fontFamily="Cairo" opacity="0.4" textAnchor="middle">
            البحر الأبيض المتوسط
          </text>
          <text x="340" y="470" fill="#334155" fontSize="16" fontFamily="Cairo" opacity="0.4" textAnchor="middle" transform="rotate(45, 340, 470)">
            البحر الأحمر
          </text>
          <text x="760" y="320" fill="#334155" fontSize="16" fontFamily="Cairo" opacity="0.4" textAnchor="middle" transform="rotate(-30, 760, 320)">
            الخليج العربي
          </text>
          <text x="820" y="580" fill="#334155" fontSize="16" fontFamily="Cairo" opacity="0.4" textAnchor="middle">
            بحر العرب والمحيط الهندي
          </text>

          {/* Stylized Landmass Contours: North Africa & Egypt */}
          <path
            d="M 60,180 L 320,180 L 380,240 L 330,360 L 390,490 L 310,580 L 120,580 L 60,380 Z"
            fill="#131b2e"
            stroke="#1e293b"
            strokeWidth="2"
            opacity="0.85"
          />

          {/* Nile River Curve */}
          <path
            d="M 280,180 Q 270,300 290,400 T 320,580"
            fill="none"
            stroke="#0284c7"
            strokeWidth="2"
            opacity="0.6"
            strokeDasharray="4 2"
          />

          {/* Levant & Fertile Crescent (Palestine, Lebanon, Syria, Jordan) */}
          <path
            d="M 330,220 L 480,140 L 540,160 L 510,290 L 380,310 L 350,260 Z"
            fill="#141e33"
            stroke="#1e293b"
            strokeWidth="2"
            opacity="0.9"
          />

          {/* Mesopotamia & Iraq (Tigris and Euphrates) */}
          <path
            d="M 480,140 L 620,110 L 690,260 L 650,330 L 530,300 Z"
            fill="#152238"
            stroke="#1e293b"
            strokeWidth="2"
            opacity="0.9"
          />

          {/* Rivers Tigris and Euphrates */}
          <path
            d="M 500,140 Q 560,200 640,300"
            fill="none"
            stroke="#0284c7"
            strokeWidth="1.5"
            opacity="0.5"
          />
          <path
            d="M 530,130 Q 590,190 660,290"
            fill="none"
            stroke="#0284c7"
            strokeWidth="1.5"
            opacity="0.5"
          />

          {/* Arabian Peninsula Mass (Saudi, Gulf, Yemen, Oman) */}
          <path
            d="M 380,310 L 530,300 L 660,290 L 730,320 L 820,380 L 880,480 L 840,570 L 660,610 L 460,590 L 390,490 Z"
            fill="#18233a"
            stroke="#334155"
            strokeWidth="2"
            opacity="0.95"
          />

          {/* Persian / Iranian Plateau Outline (North East) */}
          <path
            d="M 690,120 L 960,110 L 980,380 L 840,350 L 700,250 Z"
            fill="#0f172a"
            stroke="#1e293b"
            strokeWidth="2"
            opacity="0.4"
          />

          {/* Country Markers / Clickable Nodes */}
          {countries.map((c) => {
            const isSelected = selectedCountry.id === c.id;
            const isHovered = hoveredCountry?.id === c.id;

            // Map percentage coordinates (0-100) to SVG viewbox (0-1000, 0-650)
            const cx = (c.coordinates.x / 100) * 1000;
            const cy = (c.coordinates.y / 100) * 650;

            // Events count for this country
            const eventCount = activeEra === 'all'
              ? c.events.length
              : c.events.filter((e) => e.era === activeEra).length;

            return (
              <g
                key={c.id}
                className="cursor-pointer transition-all duration-300"
                onClick={() => {
                  onSelectCountry(c);
                  playSound('click');
                }}
                onMouseEnter={() => setHoveredCountry(c)}
                onMouseLeave={() => setHoveredCountry(null)}
              >
                {/* Outer Pulse Wave for Selected Country */}
                {isSelected && (
                  <>
                    <circle
                      cx={cx}
                      cy={cy}
                      r="32"
                      fill="none"
                      stroke="#d4af37"
                      strokeWidth="2"
                      opacity="0.4"
                      className="animate-ping"
                    />
                    <circle
                      cx={cx}
                      cy={cy}
                      r="24"
                      fill="rgba(212, 175, 55, 0.2)"
                    />
                  </>
                )}

                {/* Marker Outer Ring */}
                <circle
                  cx={cx}
                  cy={cy}
                  r={isSelected ? 16 : isHovered ? 14 : 11}
                  fill={isSelected ? '#d4af37' : isHovered ? '#f59e0b' : '#1e293b'}
                  stroke={isSelected ? '#ffffff' : '#475569'}
                  strokeWidth={isSelected ? 2.5 : 1.5}
                  className="transition-all duration-200"
                />

                {/* Inner Core */}
                <circle
                  cx={cx}
                  cy={cy}
                  r={isSelected ? 6 : 4}
                  fill={isSelected ? '#090d16' : '#cbd5e1'}
                />

                {/* Flag Emoji Label Pill */}
                <g transform={`translate(${cx}, ${cy - (isSelected ? 28 : 22)})`}>
                  <rect
                    x="-42"
                    y="-14"
                    width="84"
                    height="24"
                    rx="12"
                    fill={isSelected ? '#090d16' : '#0f172a'}
                    stroke={isSelected ? '#d4af37' : '#334155'}
                    strokeWidth={isSelected ? '1.5' : '1'}
                    className="shadow-lg"
                  />
                  <text
                    x="0"
                    y="3"
                    textAnchor="middle"
                    fill={isSelected ? '#fef08a' : '#f1f5f9'}
                    fontSize="11"
                    fontWeight={isSelected ? 'bold' : 'normal'}
                    fontFamily="Tajawal, sans-serif"
                  >
                    {c.flag} {c.name.split(' ')[0]}
                  </text>
                </g>
              </g>
            );
          })}
        </svg>

        {/* Hover / Tooltip Float */}
        {hoveredCountry && (
          <div
            className="absolute bottom-4 right-4 pointer-events-none bg-slate-900/95 border border-amber-500/40 rounded-2xl p-3 shadow-xl backdrop-blur-md text-right z-30 animate-in fade-in"
          >
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xl">{hoveredCountry.flag}</span>
              <span className="font-bold text-white text-sm font-heading">{hoveredCountry.name}</span>
            </div>
            <div className="text-[11px] text-amber-300 font-mono">
              العاصمة: {hoveredCountry.capital} • السكان: {hoveredCountry.population}
            </div>
            <div className="text-[10px] text-slate-400 mt-0.5">
              {hoveredCountry.events.length} محطة تاريخية موثقة
            </div>
          </div>
        )}
      </div>

      {/* Quick Country Buttons Strip */}
      <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center gap-2 overflow-x-auto no-scrollbar pb-1">
        <span className="text-xs text-slate-400 shrink-0 font-semibold">الدول المتاحة:</span>
        {countries.map((c) => {
          const isSelected = selectedCountry.id === c.id;
          return (
            <button
              key={c.id}
              onClick={() => {
                onSelectCountry(c);
                playSound('click');
              }}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap shrink-0 transition-all flex items-center gap-1.5 border ${
                isSelected
                  ? 'bg-amber-500/20 border-amber-500 text-amber-300 font-bold shadow-md shadow-amber-500/10'
                  : 'bg-slate-950/60 border-slate-800 text-slate-300 hover:text-white hover:border-slate-700'
              }`}
            >
              <span>{c.flag}</span>
              <span>{c.name}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
};
