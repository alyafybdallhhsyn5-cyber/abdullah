import React, { useState } from 'react';
import { ProjectData } from '../types';
import { playSound } from '../utils/audio';
import { X, Copy, CheckCircle, Download, FileText } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  project: ProjectData;
}

export const ReportModal: React.FC<Props> = ({ isOpen, onClose, project }) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const generateMarkdown = () => {
    return `# وثيقة المواصفات الفنية الكاملة للمشروع
## ${project.title}
**الشعار:** ${project.slogan}
**نوع المشروع:** ${project.type === 'game' ? 'لعبة تفاعلية للهاتف' : 'تطبيق هاتف ذكي'}

---

### 1. تطوير الفكرة والمميزات المبتكرة
- **الفكرة الجوهرية:** ${project.coreIdea}
- **الملخص:** ${project.summary}
- **المميزات المبتكرة:**
${project.innovations.map((inv, idx) => `  ${idx + 1}. ${inv}`).join('\n')}

---

### 2. الجمهور المستهدف وسيناريو الاستخدام
- **الجمهور الأساسي:** ${project.targetAudience.primary}
- **الجمهور الثانوي:** ${project.targetAudience.secondary}
- **ظروف وسياق الاستخدام على هاتف أندرويد:** ${project.targetAudience.usageContext}
- **شخصيات المستخدمين (Personas):**
${project.targetAudience.personas.map((p) => `  - **${p.name} (${p.age}):** ${p.description}\n    * العادة: ${p.usageHabit}\n    * سر الإعجاب: ${p.whyTheyLoveIt}`).join('\n')}

---

### 3. نظام تصميم الواجهات RTL
- **اللون الأساسي:** ${project.designSystem.primaryColor}
- **اللون الثانوي:** ${project.designSystem.secondaryColor}
- **لون التفاعل (Accent):** ${project.designSystem.accentColor}
- **خط العناوين والنصوص:** ${project.designSystem.fontHeading} / ${project.designSystem.fontFamily}
- **هندسة وصول الإبهام (Thumb Zone):** ${project.designSystem.thumbErgonomics}

---

### 4. تفصيل الشاشات والأزرار والوظائف
${project.screens.map((s, idx) => `
#### شاشة ${idx + 1}: ${s.title}
- **الهدف:** ${s.purpose}
- **الوصف:** ${s.description}
- **الأزرار والتفاعل:**
${s.buttons.map((b) => `  * [${b.label}]: ${b.action} ${b.targetScreen ? `(ينقل إلى: ${b.targetScreen})` : ''}`).join('\n')}
- **البيانات المعروضة:** ${s.keyData.join('، ')}
`).join('\n')}

---

### 5. التقنية المناسبة للمبتدئ وللهاتف
- **التقنية المرشحة:** ${project.techStack.recommended}
- **المبررات:** ${project.techStack.justification}
- **نصائح المطور المبتدئ:**
${project.techStack.beginnerTips.map((tip, idx) => `  ${idx + 1}. ${tip}`).join('\n')}

---

### 6. نموذج أولي يعمل فعلًا
- تم بناء نموذج تفاعلي حي بمعدل 60 إطار في الثانية بالصوت والفيزياء والتخزين المحلي.

---

### 7. معمل فحص الجودة والأخطاء (QA)
${project.qaChecklist.map((c) => `- [x] **${c.title}:** ${c.details}`).join('\n')}

---

### 8. دليل تصدير التطبيق إلى Android (APK/AAB)
1. **طريقة PWA المباشرة:**
${project.androidExport.pwaSteps.map((s, idx) => `   ${idx + 1}. ${s}`).join('\n')}

2. **طريقة حزمة APK عبر PWABuilder:**
${project.androidExport.apkSteps.map((s, idx) => `   ${idx + 1}. ${s}`).join('\n')}

---

### 9. دليل التكاليف والاشتراكات
- **أدوات التطوير والاستضافة:** 0$ (مجانية بالكامل للأبد)
- **بناء ملف APK:** 0$ (مجاناً عبر PWABuilder)
- **حساب مطور Google Play Console:** 25$ لمرة واحدة في العمر (اختياري للنشر على المتجر الرسمي)
- **قاعدة البيانات (Firebase Spark):** 0$ حتى 50,000 مستخدم يومياً

---
تم توليد هذه الوثيقة آلياً عبر *مختبر صانع الألعاب والتطبيقات للمبتدئين*.
`;
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(generateMarkdown());
    setCopied(true);
    playSound('coin');
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const text = generateMarkdown();
    const blob = new Blob([text], { type: 'text/markdown;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${project.id}-specification.md`;
    a.click();
    URL.revokeObjectURL(url);
    playSound('success');
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto animate-in fade-in">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-3xl w-full p-6 shadow-2xl relative my-8 flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800 shrink-0">
          <div className="flex items-center gap-2">
            <FileText className="w-5 h-5 text-indigo-400" />
            <h3 className="text-lg font-bold text-white font-heading">
              وثيقة المشروع الشاملة (Project Specification)
            </h3>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleCopy}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors"
            >
              {copied ? <CheckCircle className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'تم النسخ!' : 'نسخ النص'}</span>
            </button>
            <button
              onClick={handleDownload}
              className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors"
            >
              <Download className="w-3.5 h-3.5" />
              <span>تحميل (.md)</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 rounded-xl bg-slate-800 text-slate-400 hover:text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Markdown Content Viewer */}
        <div className="flex-1 overflow-y-auto p-4 bg-slate-950 rounded-2xl border border-slate-800/80 my-4 text-xs font-mono text-slate-300 leading-relaxed whitespace-pre-wrap select-text text-right" dir="rtl">
          {generateMarkdown()}
        </div>

        <div className="text-[11px] text-slate-400 text-center shrink-0">
          يمكنك لصق هذا النص في أي محرر أو مشاركته مع فريقك أو الاحتفاظ به كمرجع دائم لمشروعك.
        </div>
      </div>
    </div>
  );
};
