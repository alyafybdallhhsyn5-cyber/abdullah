import React, { useState } from 'react';
import { MIDDLE_EAST_WARS } from '../data/warsData';
import { MIDDLE_EAST_COUNTRIES } from '../data/middleEastData';
import { RegionalWar } from '../types/history';
import { playSound } from '../utils/audio';
import { ShieldAlert, Swords, Calendar, Users, Target, Award, ChevronDown, ChevronUp, Flag, Search, Layers } from 'lucide-react';

interface Props {
  onSelectCountry: (countryId: string) => void;
}

export const WarsSection: React.FC<Props> = ({ onSelectCountry }) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [expandedWarId, setExpandedWarId] = useState<string | null>('war-gaza-2023');

  const categories = [
    { id: 'all', label: 'كافة الحروب والصراعات' },
    { id: 'حروب التحرير العربية الإسرائيلية', label: 'حروب التحرير العربية الإسرائيلية' },
    { id: 'حروب الخليج والشرق الأوسط', label: 'حروب الخليج والرافدين' },
    { id: 'صراعات داخلية وإقليمية معاصرة', label: 'الصراعات والحروب المعاصرة' }
  ];

  const filteredWars = MIDDLE_EAST_WARS.filter(war => {
    const matchesCategory = selectedCategory === 'all' || war.category === selectedCategory;
    const query = searchQuery.trim().toLowerCase();
    const matchesQuery = !query || 
      war.name.toLowerCase().includes(query) ||
      (war.alternativeNames && war.alternativeNames.some(n => n.toLowerCase().includes(query))) ||
      war.period.toLowerCase().includes(query) ||
      war.causes.some(c => c.toLowerCase().includes(query)) ||
      war.parties.sideA.countries.some(c => c.toLowerCase().includes(query)) ||
      war.parties.sideB.countries.some(c => c.toLowerCase().includes(query));
    return matchesCategory && matchesQuery;
  });

  const toggleExpand = (warId: string) => {
    playSound('click');
    setExpandedWarId(prev => prev === warId ? null : warId);
  };

  return (
    <div className="space-y-8 animate-fadeIn text-right" dir="rtl">
      {/* Header Banner */}
      <div className="relative rounded-2xl overflow-hidden border border-red-900/40 bg-gradient-to-r from-red-950/70 via-slate-900 to-amber-950/40 p-6 sm:p-8 backdrop-blur-md">
        <div className="max-w-3xl space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-red-500/10 border border-red-500/30 text-red-400 text-xs font-bold">
            <Swords className="w-3.5 h-3.5" />
            <span>التوثيق العسكري والجيوسياسي للشرق الأوسط</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-black text-white font-heading tracking-wide">
            الحروب والصراعات الكبرى في التاريخ الحديث والمعاصر
          </h2>
          <p className="text-sm sm:text-base text-slate-300 leading-relaxed font-body">
            سجل توثيقي شامل ومفصل لأبرز الحروب والمنعطفات العسكرية الفاصلة التي شكلت حدود وموازين القوى في المنطقة، بدءاً من حروب التحرير العربية الإسرائيلية مروراً بحروب الخليج وحتى حرب غزة واليمن وسوريا المعاصرة.
          </p>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4 bg-slate-900/60 p-4 rounded-xl border border-slate-800">
        {/* Category Pills */}
        <div className="flex flex-wrap items-center gap-2">
          {categories.map(cat => (
            <button
              key={cat.id}
              onClick={() => {
                setSelectedCategory(cat.id);
                playSound('click');
              }}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all ${
                selectedCategory === cat.id
                  ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                  : 'bg-slate-800/80 text-slate-300 hover:bg-slate-800 hover:text-white'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Search Input */}
        <div className="relative min-w-[240px]">
          <Search className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="ابحث عن حرب، معركة، أو دولة..."
            className="w-full bg-slate-950/70 border border-slate-700/80 rounded-lg pr-9 pl-3 py-1.5 text-xs text-white placeholder-slate-400 focus:outline-none focus:border-amber-400"
          />
        </div>
      </div>

      {/* Wars List */}
      <div className="space-y-4">
        {filteredWars.length === 0 ? (
          <div className="p-12 text-center bg-slate-900/40 rounded-xl border border-slate-800/60 text-slate-400 text-sm">
            لم يتم العثور على حروب تطابق بحثك الحالي.
          </div>
        ) : (
          filteredWars.map((war) => {
            const isExpanded = expandedWarId === war.id;

            return (
              <div
                key={war.id}
                className={`rounded-2xl transition-all border ${
                  isExpanded
                    ? 'bg-slate-900/90 border-amber-500/50 shadow-xl shadow-amber-500/5'
                    : 'bg-slate-900/50 border-slate-800 hover:border-slate-700'
                } overflow-hidden`}
              >
                {/* War Card Header (Clickable) */}
                <div
                  onClick={() => toggleExpand(war.id)}
                  className="p-5 sm:p-6 cursor-pointer flex flex-col md:flex-row md:items-center justify-between gap-4 select-none"
                >
                  <div className="space-y-2">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="px-2.5 py-0.5 rounded-full text-xs font-black bg-red-950/80 text-red-400 border border-red-800/60">
                        {war.period}
                      </span>
                      <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-slate-800 text-slate-300 border border-slate-700">
                        {war.category}
                      </span>
                      {war.endDate?.includes('مستمرة') && (
                        <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40 animate-pulse">
                          مستمرة / مسار سياسي
                        </span>
                      )}
                    </div>

                    <h3 className="text-xl sm:text-2xl font-black text-white font-heading">
                      {war.name}
                    </h3>

                    {war.alternativeNames && war.alternativeNames.length > 0 && (
                      <p className="text-xs text-slate-400">
                        <span className="text-slate-500 font-semibold">تُعرف أيضاً بـ: </span>
                        {war.alternativeNames.join(' • ')}
                      </p>
                    )}
                  </div>

                  <div className="flex items-center justify-between md:justify-end gap-4 shrink-0 pt-2 md:pt-0 border-t border-slate-800/60 md:border-none">
                    <div className="flex items-center gap-2">
                      {war.relatedCountryIds.map(cid => {
                        const c = MIDDLE_EAST_COUNTRIES.find(item => item.id === cid);
                        if (!c) return null;
                        return (
                          <button
                            key={cid}
                            title={c.name}
                            onClick={(e) => {
                              e.stopPropagation();
                              onSelectCountry(cid);
                              playSound('click');
                            }}
                            className="w-8 h-8 rounded-lg bg-slate-800/90 border border-slate-700/80 flex items-center justify-center text-sm hover:scale-110 hover:border-amber-400 transition-transform"
                          >
                            {c.flag}
                          </button>
                        );
                      })}
                    </div>

                    <div className="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center text-slate-400 hover:text-white">
                      {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                    </div>
                  </div>
                </div>

                {/* Expanded Detailed Content */}
                {isExpanded && (
                  <div className="px-5 sm:px-6 pb-6 pt-2 border-t border-slate-800/80 space-y-6">
                    {/* Sides & Parties */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {/* Side A */}
                      <div className="p-4 rounded-xl bg-slate-950/60 border border-emerald-900/30 space-y-2">
                        <div className="flex items-center gap-2 text-xs font-bold text-emerald-400">
                          <Users className="w-4 h-4" />
                          <span>الطرف الأول / التحالف العربي الوطني:</span>
                        </div>
                        <h4 className="text-sm font-bold text-white">
                          {war.parties.sideA.name}
                        </h4>
                        <div className="flex flex-wrap gap-1.5 pt-1">
                          {war.parties.sideA.countries.map((c, idx) => (
                            <span key={idx} className="px-2 py-0.5 rounded bg-emerald-950/50 border border-emerald-800/40 text-emerald-300 text-xs">
                              {c}
                            </span>
                          ))}
                        </div>
                        {war.parties.sideA.leaders && (
                          <p className="text-xs text-slate-400 pt-1">
                            <span className="text-slate-500 font-semibold">أبرز القادة: </span>
                            {war.parties.sideA.leaders.join('، ')}
                          </p>
                        )}
                      </div>

                      {/* Side B */}
                      <div className="p-4 rounded-xl bg-slate-950/60 border border-red-900/30 space-y-2">
                        <div className="flex items-center gap-2 text-xs font-bold text-red-400">
                          <Target className="w-4 h-4" />
                          <span>الطرف المقابل / الخصم:</span>
                        </div>
                        <h4 className="text-sm font-bold text-white">
                          {war.parties.sideB.name}
                        </h4>
                        <div className="flex flex-wrap gap-1.5 pt-1">
                          {war.parties.sideB.countries.map((c, idx) => (
                            <span key={idx} className="px-2 py-0.5 rounded bg-red-950/50 border border-red-800/40 text-red-300 text-xs">
                              {c}
                            </span>
                          ))}
                        </div>
                        {war.parties.sideB.leaders && (
                          <p className="text-xs text-slate-400 pt-1">
                            <span className="text-slate-500 font-semibold">القيادة: </span>
                            {war.parties.sideB.leaders.join('، ')}
                          </p>
                        )}
                      </div>
                    </div>

                    {/* Causes Section */}
                    <div className="space-y-2">
                      <div className="flex items-center gap-2 text-xs font-bold text-amber-400">
                        <ShieldAlert className="w-4 h-4" />
                        <span>أسباب ودوافع اندلاع الحرب:</span>
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        {war.causes.map((cause, idx) => (
                          <div key={idx} className="p-3 rounded-lg bg-slate-950/40 border border-slate-800/70 text-xs text-slate-300 flex items-start gap-2">
                            <span className="w-1.5 h-1.5 rounded-full bg-amber-400 shrink-0 mt-1.5" />
                            <span>{cause}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Key Battles & Milestones Timeline */}
                    <div className="space-y-3">
                      <div className="flex items-center gap-2 text-xs font-bold text-amber-400">
                        <Calendar className="w-4 h-4" />
                        <span>أبرز المعارك والمنعطفات الحاسمة:</span>
                      </div>
                      <div className="space-y-2.5">
                        {war.keyBattles.map((battle, bIdx) => (
                          <div key={bIdx} className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800 space-y-1">
                            <div className="flex items-center justify-between gap-2">
                              <h5 className="text-sm font-bold text-amber-300 font-heading">
                                {battle.name}
                              </h5>
                              <span className="text-xs font-bold text-slate-400 shrink-0 bg-slate-900 px-2 py-0.5 rounded border border-slate-700/60">
                                {battle.date}
                              </span>
                            </div>
                            <p className="text-xs text-slate-300 leading-relaxed font-body">
                              {battle.description}
                            </p>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Strategic Outcomes & Geopolitical Impact */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {/* Outcomes */}
                      <div className="p-4 rounded-xl bg-slate-950/60 border border-amber-900/30 space-y-2">
                        <div className="flex items-center gap-2 text-xs font-bold text-amber-400">
                          <Award className="w-4 h-4" />
                          <span>النتائج المباشرة والاستراتيجية:</span>
                        </div>
                        <ul className="space-y-1.5 text-xs text-slate-300 font-body">
                          {war.outcomes.map((out, idx) => (
                            <li key={idx} className="flex items-start gap-2">
                              <span className="w-1.5 h-1.5 rounded-full bg-amber-400 shrink-0 mt-1.5" />
                              <span>{out}</span>
                            </li>
                          ))}
                        </ul>
                      </div>

                      {/* Geopolitical Impact */}
                      <div className="p-4 rounded-xl bg-slate-950/60 border border-cyan-900/30 space-y-2">
                        <div className="flex items-center gap-2 text-xs font-bold text-cyan-400">
                          <Layers className="w-4 h-4" />
                          <span>الأثر الجيوسياسي وموازين القوى:</span>
                        </div>
                        <p className="text-xs text-slate-300 leading-relaxed font-body">
                          {war.geopoliticalImpact}
                        </p>
                      </div>
                    </div>

                    {/* Country Navigation Footnote */}
                    <div className="pt-2 flex items-center justify-between flex-wrap gap-2 text-xs text-slate-400">
                      <span>استكشف تاريخ وتفاصيل الدول المشاركة:</span>
                      <div className="flex flex-wrap items-center gap-1.5">
                        {war.relatedCountryIds.map(cid => {
                          const c = MIDDLE_EAST_COUNTRIES.find(item => item.id === cid);
                          if (!c) return null;
                          return (
                            <button
                              key={cid}
                              onClick={() => {
                                onSelectCountry(cid);
                                playSound('click');
                              }}
                              className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-amber-500 hover:text-slate-950 transition-colors text-xs font-semibold flex items-center gap-1"
                            >
                              <span>{c.flag}</span>
                              <span>{c.name}</span>
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
