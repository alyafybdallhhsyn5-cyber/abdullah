import React, { useState } from 'react';
import { ProjectData } from '../../types';
import { FalconGameSimulator } from '../prototypes/FalconGameSimulator';
import { HabitAppSimulator } from '../prototypes/HabitAppSimulator';
import { TriviaGameSimulator } from '../prototypes/TriviaGameSimulator';
import { QuickShopSimulator } from '../prototypes/QuickShopSimulator';
import { PlayCircle, Sliders, Smartphone, CheckCircle, ArrowRight, RefreshCw, Zap } from 'lucide-react';

interface Props {
  project: ProjectData;
  onNextStage: () => void;
  onPrevStage: () => void;
}

export const Stage6_LivePrototype: React.FC<Props> = ({ project, onNextStage, onPrevStage }) => {
  // Determine initial simulator mode based on project ID or type
  const getInitialSimMode = () => {
    if (project.id === 'falcon-runner') return 'falcon';
    if (project.id === 'habit-flow') return 'habit';
    if (project.id === 'arab-trivia') return 'trivia';
    if (project.id === 'easy-shop') return 'shop';
    return project.type === 'game' ? 'falcon' : 'habit';
  };

  const [activeSim, setActiveSim] = useState<'falcon' | 'habit' | 'trivia' | 'shop'>(getInitialSimMode);

  return (
    <div className="space-y-6 animate-in fade-in">
      <div className="bg-gradient-to-br from-indigo-950/40 via-slate-900 to-slate-950 border border-indigo-500/30 rounded-3xl p-6">
        <div className="inline-flex items-center gap-2 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-3 py-1 rounded-full text-xs font-bold mb-3">
          <PlayCircle className="w-3.5 h-3.5" />
          <span>المرحلة 6 من 9: نموذج أولي يعمل فعلًا (Live Interactive Prototype)</span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-black text-white font-heading mb-2">
          جرّب والعب مشروعك الآن على محاكي هاتف أندرويد!
        </h2>
        <p className="text-sm text-slate-300">
          ليس مجرد صور أو كلام نظري! هذا كود حقيقي يعمل بمحرك فيزياء ولمس وصوت تفاعلي وتخزين في ذاكرة هاتفك. انقر والعب واختبر كل وظيفة كما لو كان تطبيقاً مثبتاً على هاتفك.
        </p>
      </div>

      {/* Prototype Switcher Tabs */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-3">
          <div className="flex items-center gap-2 text-xs font-bold text-slate-300">
            <Smartphone className="w-4 h-4 text-indigo-400" />
            <span>اختر النموذج التفاعلي للتجربة:</span>
          </div>
          <span className="text-[11px] text-amber-400 bg-amber-500/10 px-2.5 py-1 rounded-lg border border-amber-500/20 font-bold">
            💡 متوافق مع اللمس على جميع هواتف أندرويد
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
          <button
            onClick={() => setActiveSim('falcon')}
            className={`p-3 rounded-xl border text-right transition-all ${
              activeSim === 'falcon'
                ? 'bg-amber-500/20 border-amber-500 text-white shadow-lg shadow-amber-500/10'
                : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:text-slate-200'
            }`}
          >
            <div className="text-xl mb-1">🦅</div>
            <div className="text-xs font-bold">تحدي الصقر العربي</div>
            <div className="text-[10px] text-slate-400">لعبة أركيد 60 FPS</div>
          </button>

          <button
            onClick={() => setActiveSim('habit')}
            className={`p-3 rounded-xl border text-right transition-all ${
              activeSim === 'habit'
                ? 'bg-indigo-500/20 border-indigo-500 text-white shadow-lg shadow-indigo-500/10'
                : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:text-slate-200'
            }`}
          >
            <div className="text-xl mb-1">🚀</div>
            <div className="text-xs font-bold">تطبيق خطوة للعادات</div>
            <div className="text-[10px] text-slate-400">تطبيق حقيقي بذاكرة هاتف</div>
          </button>

          <button
            onClick={() => setActiveSim('trivia')}
            className={`p-3 rounded-xl border text-right transition-all ${
              activeSim === 'trivia'
                ? 'bg-purple-500/20 border-purple-500 text-white shadow-lg shadow-purple-500/10'
                : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:text-slate-200'
            }`}
          >
            <div className="text-xl mb-1">⚡</div>
            <div className="text-xs font-bold">تحدي المعرفة السريع</div>
            <div className="text-[10px] text-slate-400">لعبة مسابقات بمؤقت</div>
          </button>

          <button
            onClick={() => setActiveSim('shop')}
            className={`p-3 rounded-xl border text-right transition-all ${
              activeSim === 'shop'
                ? 'bg-emerald-500/20 border-emerald-500 text-white shadow-lg shadow-emerald-500/10'
                : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:text-slate-200'
            }`}
          >
            <div className="text-xl mb-1">🛒</div>
            <div className="text-xs font-bold">دكّان WhatsApp السريع</div>
            <div className="text-[10px] text-slate-400">متجر بطلبات واتساب</div>
          </button>
        </div>
      </div>

      {/* Phone Simulator Display Area */}
      <div className="bg-slate-950/80 border border-slate-800/80 rounded-3xl p-4 sm:p-8 flex flex-col items-center justify-center relative overflow-hidden">
        <div className="w-full max-w-md">
          {activeSim === 'falcon' && <FalconGameSimulator primaryColor={project.designSystem.primaryColor} />}
          {activeSim === 'habit' && <HabitAppSimulator />}
          {activeSim === 'trivia' && <TriviaGameSimulator />}
          {activeSim === 'shop' && <QuickShopSimulator />}
        </div>
      </div>

      {/* Simulator Feature Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="p-4 bg-slate-900/80 border border-slate-800 rounded-2xl flex items-start gap-3">
          <div className="p-2 rounded-xl bg-indigo-500/10 text-indigo-400 shrink-0">
            <Zap className="w-4 h-4" />
          </div>
          <div>
            <h4 className="text-xs font-bold text-white mb-0.5">محاكي فيزياء ومعدل 60 إطار</h4>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              تحكم حقيقي باللمس مع محاكاة الجاذبية والتصادمات والاستجابة الفورية.
            </p>
          </div>
        </div>

        <div className="p-4 bg-slate-900/80 border border-slate-800 rounded-2xl flex items-start gap-3">
          <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-400 shrink-0">
            <CheckCircle className="w-4 h-4" />
          </div>
          <div>
            <h4 className="text-xs font-bold text-white mb-0.5">حفظ حقيقي في ذاكرة الجهاز</h4>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              أرقامك القياسية وعاداتك المضافة تُحفظ في متصفحك ولا تضيع عند إعادة التحميل.
            </p>
          </div>
        </div>

        <div className="p-4 bg-slate-900/80 border border-slate-800 rounded-2xl flex items-start gap-3">
          <div className="p-2 rounded-xl bg-amber-500/10 text-amber-400 shrink-0">
            <RefreshCw className="w-4 h-4" />
          </div>
          <div>
            <h4 className="text-xs font-bold text-white mb-0.5">مؤثرات صوتية واحتفالات</h4>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              مؤثرات صوتية مُولَّدة داخلياً عبر Web Audio API دون الحاجة لتحميل ملفات mp3 خارجية.
            </p>
          </div>
        </div>
      </div>

      {/* Navigation Buttons */}
      <div className="flex items-center justify-between pt-2">
        <button
          onClick={onPrevStage}
          className="px-5 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-bold"
        >
          السابق: التقنية المناسبة
        </button>

        <button
          onClick={onNextStage}
          className="px-6 py-3 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl text-sm flex items-center gap-2 shadow-lg shadow-indigo-600/25 transition-transform active:scale-95"
        >
          <span>المرحلة التالية: معمل فحص واختبار الأخطاء (QA)</span>
          <ArrowRight className="w-4 h-4 rotate-180" />
        </button>
      </div>
    </div>
  );
};
