import React, { useState } from 'react';
import { ProjectData } from '../../types';
import { DollarSign, CheckCircle2, AlertCircle, HelpCircle, Sparkles, ArrowRight, Wallet, ShieldAlert } from 'lucide-react';

interface Props {
  project: ProjectData;
  onPrevStage: () => void;
  onOpenReport: () => void;
  onNewProject: () => void;
}

export const Stage9_Costs: React.FC<Props> = ({ project, onPrevStage, onOpenReport, onNewProject }) => {
  const [includePlayStore, setIncludePlayStore] = useState(false);
  const [includeDomain, setIncludeDomain] = useState(false);

  const calculateTotal = () => {
    let total = 0;
    if (includePlayStore) total += 25;
    if (includeDomain) total += 12;
    return total;
  };

  return (
    <div className="space-y-6 animate-in fade-in">
      <div className="bg-gradient-to-br from-indigo-950/40 via-slate-900 to-slate-950 border border-indigo-500/30 rounded-3xl p-6">
        <div className="inline-flex items-center gap-2 bg-amber-500/20 text-amber-300 border border-amber-500/30 px-3 py-1 rounded-full text-xs font-bold mb-3">
          <DollarSign className="w-3.5 h-3.5" />
          <span>المرحلة 9 من 9: توضيح أي ميزات تحتاج إلى اشتراك أو خدمات مدفوعة</span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-black text-white font-heading mb-2">
          دليل التكاليف الشفاف: ما هو المجاني وما هو المدفوع؟
        </h2>
        <p className="text-sm text-slate-300">
          لا تدفع دولاراً واحداً في البداية! يمكنك بناء لعبتك أو تطبيقك، ونشرها لأصدقائك، وتثبيتها على الهواتف بميزانية 0$ تماماً. إليك التفاصيل الكاملة.
        </p>
      </div>

      {/* Free vs Paid Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Free Tier Card */}
        <div className="bg-emerald-950/20 border border-emerald-500/30 rounded-2xl p-5">
          <div className="flex items-center gap-2 text-emerald-400 font-bold text-base mb-3 font-heading">
            <CheckCircle2 className="w-5 h-5" />
            <span>خدمات مجانية بالكامل للأبد (0$)</span>
          </div>

          <ul className="space-y-2 text-xs sm:text-sm text-slate-200">
            <li className="flex items-start gap-2">
              <span className="text-emerald-400 font-bold">✓</span>
              <span><strong>التطوير والتجربة:</strong> كتابة الكود والتعديل عليه عبر الويب أو الهاتف مجاناً 100%.</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-emerald-400 font-bold">✓</span>
              <span><strong>الاستضافة العالمية:</strong> رفع تطبيقك عبر Vercel أو GitHub Pages مجاناً مع سرعة خارقة.</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-emerald-400 font-bold">✓</span>
              <span><strong>توليد APK للهاتف:</strong> استخدام أداة PWABuilder الرسمية بدون أي اشتراك.</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-emerald-400 font-bold">✓</span>
              <span><strong>قاعدة بيانات سحابية (Firebase):</strong> باقة Spark المجانية تمنحك حتى 50,000 قراءة يومياً دون دفع سنت!</span>
            </li>
          </ul>
        </div>

        {/* Paid / Optional Card */}
        <div className="bg-amber-950/20 border border-amber-500/30 rounded-2xl p-5">
          <div className="flex items-center gap-2 text-amber-400 font-bold text-base mb-3 font-heading">
            <AlertCircle className="w-5 h-5" />
            <span>ما الذي يتطلب دفع مبالغ؟ (ومتى تحتاجه؟)</span>
          </div>

          <ul className="space-y-2 text-xs sm:text-sm text-slate-200">
            <li className="flex items-start gap-2">
              <span className="text-amber-400 font-bold">⚠️</span>
              <span><strong>حساب مطور Google Play:</strong> رسم لمرة واحدة بقيمة <strong>25$ فقط</strong> (مدى الحياة وليس شهرياً). تحتاجه فقط إذا أردت أن يبحث الناس عن لعبتك داخل تطبيق متجر Google Play الرسمي.</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-amber-400 font-bold">⚠️</span>
              <span><strong>اسم نطاق خاص (.com / .app):</strong> اختياري، يكلف حوالي 10$ إلى 12$ في السنة. ليس إلزامياً، فالرابط المجاني الممنوح لك يكفي تماماً.</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-amber-400 font-bold">⚠️</span>
              <span><strong>خدمات الذكاء الاصطناعي (Gemini API):</strong> الحصة التجريبية مجانية، وتدفع فقط إذا كبر تطبيقك لآلاف الطلبات المتقدمة.</span>
            </li>
          </ul>
        </div>
      </div>

      {/* Interactive Budget Estimator */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2 text-white font-bold font-heading">
            <Wallet className="w-5 h-5 text-indigo-400" />
            <span>حاسبة ميزانية إطلاق مشروعك:</span>
          </div>
          <div className="text-xl font-black text-emerald-400 font-mono">
            المجموع التقديري: {calculateTotal()} $
          </div>
        </div>

        <div className="space-y-3">
          <label className="flex items-center justify-between p-3.5 bg-slate-950 border border-slate-800 rounded-xl cursor-pointer hover:border-slate-700 transition-colors">
            <div className="flex items-center gap-3">
              <input
                type="checkbox"
                checked={includePlayStore}
                onChange={(e) => setIncludePlayStore(e.target.checked)}
                className="w-4 h-4 rounded text-indigo-600 focus:ring-0"
              />
              <div>
                <div className="text-xs sm:text-sm font-bold text-white">النشر على متجر Google Play الرسمي</div>
                <div className="text-[11px] text-slate-400">رسوم حساب مطور جوجل لمرة واحدة في العمر لفتح حساب غير محدود</div>
              </div>
            </div>
            <span className="text-xs font-mono font-bold text-amber-400">+ 25 $ (مرة واحدة)</span>
          </label>

          <label className="flex items-center justify-between p-3.5 bg-slate-950 border border-slate-800 rounded-xl cursor-pointer hover:border-slate-700 transition-colors">
            <div className="flex items-center gap-3">
              <input
                type="checkbox"
                checked={includeDomain}
                onChange={(e) => setIncludeDomain(e.target.checked)}
                className="w-4 h-4 rounded text-indigo-600 focus:ring-0"
              />
              <div>
                <div className="text-xs sm:text-sm font-bold text-white">شراء اسم نطاق خاص (Domain)</div>
                <div className="text-[11px] text-slate-400">مثل myawesomegame.com بدلاً من الرابط المجاني</div>
              </div>
            </div>
            <span className="text-xs font-mono font-bold text-slate-300">+ 12 $ (سنوياً)</span>
          </label>
        </div>

        <div className="mt-4 p-3 bg-indigo-950/30 border border-indigo-500/20 rounded-xl text-xs text-indigo-200">
          💡 <strong>استراتيجية المطور الذكي للمبتدئين:</strong> ابدأ بإطلاق اللعبة لأصدقائك بـ <strong>0 دولار</strong>، وحقق أول 100 لاعب، ثم أضف إعلانات Google AdMob المجانية لتحقيق أول أرباح، واستخدم تلك الأرباح لدفع رسوم متجر جوجل بلاي دون أن تدفع من جيبك!
        </div>
      </div>

      {/* Full Cost Table */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5">
        <h3 className="font-bold text-base text-white mb-3 font-heading">
          جدول بنود التكاليف التفصيلي:
        </h3>
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-right">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400">
                <th className="pb-2 font-bold">الخدمة</th>
                <th className="pb-2 font-bold">التصنيف</th>
                <th className="pb-2 font-bold">التكلفة</th>
                <th className="pb-2 font-bold">التكرار</th>
                <th className="pb-2 font-bold">ملاحظة عملية</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {project.costBreakdown.map((item, idx) => (
                <tr key={idx} className="hover:bg-slate-950/40">
                  <td className="py-2.5 font-bold text-white">{item.service}</td>
                  <td className="py-2.5">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      item.category === 'مجاني بالكامل'
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                        : item.category === 'اختياري'
                        ? 'bg-slate-800 text-slate-300'
                        : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                    }`}>
                      {item.category}
                    </span>
                  </td>
                  <td className="py-2.5 font-mono font-bold text-emerald-400">{item.costAmount}</td>
                  <td className="py-2.5 text-slate-400">{item.frequency}</td>
                  <td className="py-2.5 text-slate-300 max-w-xs">{item.notes}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Action Completion Footer */}
      <div className="bg-gradient-to-r from-indigo-900/50 via-purple-900/50 to-slate-900 border border-indigo-500/40 rounded-3xl p-6 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 text-xs text-emerald-400 font-bold mb-1">
            <Sparkles className="w-4 h-4" />
            <span>اكتملت جميع المراحل التسع بنجاح! 🎉</span>
          </div>
          <h3 className="text-lg font-black text-white font-heading">
            مشروعك جاهز الآن للمعاينة والتصدير والبدء
          </h3>
          <p className="text-xs text-slate-300 mt-0.5">
            يمكنك نسخ وثيقة المشروع الشاملة أو تجربة فكرة جديدة بالكامل.
          </p>
        </div>

        <div className="flex flex-wrap gap-2.5 shrink-0">
          <button
            onClick={onOpenReport}
            className="px-5 py-3 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold shadow-lg shadow-indigo-600/30 transition-transform active:scale-95 flex items-center gap-1.5"
          >
            <span>عرض ونسخ وثيقة المشروع 📄</span>
          </button>

          <button
            onClick={onNewProject}
            className="px-5 py-3 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-bold transition-colors"
          >
            <span>فكرة مشروع أخرى 💡</span>
          </button>
        </div>
      </div>

      {/* Navigation Buttons */}
      <div className="flex items-center justify-between pt-2">
        <button
          onClick={onPrevStage}
          className="px-5 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-bold"
        >
          السابق: دليل تصدير Android
        </button>
      </div>
    </div>
  );
};
