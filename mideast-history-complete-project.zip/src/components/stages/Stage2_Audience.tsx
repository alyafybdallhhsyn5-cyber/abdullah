import React from 'react';
import { ProjectData } from '../../types';
import { Users, UserCheck, Smartphone, Clock, ArrowRight } from 'lucide-react';

interface Props {
  project: ProjectData;
  onNextStage: () => void;
  onPrevStage: () => void;
}

export const Stage2_Audience: React.FC<Props> = ({ project, onNextStage, onPrevStage }) => {
  return (
    <div className="space-y-6 animate-in fade-in">
      <div className="bg-gradient-to-br from-indigo-950/40 via-slate-900 to-slate-950 border border-indigo-500/30 rounded-3xl p-6">
        <div className="inline-flex items-center gap-2 bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 px-3 py-1 rounded-full text-xs font-bold mb-3">
          <Users className="w-3.5 h-3.5" />
          <span>المرحلة 2 من 9: تحديد الجمهور المستهدف وطريقة الاستخدام</span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-black text-white font-heading mb-2">
          من سيلعب أو يستخدم مشروعك؟ وكيف؟
        </h2>
        <p className="text-sm text-slate-300">
          فهم نفسية وسلوك المستخدم على هاتف أندرويد هو الفارق الجوهري بين مشروع يتركه الناس في ثوانٍ وتطبيق يحبونه يومياً.
        </p>
      </div>

      {/* Target Segments */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5">
          <div className="text-xs text-indigo-400 font-bold mb-1 flex items-center gap-1.5">
            <UserCheck className="w-4 h-4" />
            <span>الجمهور الأساسي المستهدف (Primary Audience)</span>
          </div>
          <p className="text-sm text-slate-200 font-medium leading-relaxed">
            {project.targetAudience.primary}
          </p>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5">
          <div className="text-xs text-amber-400 font-bold mb-1 flex items-center gap-1.5">
            <Users className="w-4 h-4" />
            <span>الجمهور الثانوي والداعم</span>
          </div>
          <p className="text-sm text-slate-200 font-medium leading-relaxed">
            {project.targetAudience.secondary}
          </p>
        </div>
      </div>

      {/* User Personas */}
      <div className="space-y-3">
        <h3 className="text-base font-bold text-white font-heading flex items-center gap-2">
          <Smartphone className="w-4 h-4 text-emerald-400" />
          <span>شخصيات المستخدمين الحقيقية (User Personas):</span>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {project.targetAudience.personas.map((persona, idx) => (
            <div
              key={idx}
              className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 relative overflow-hidden"
            >
              <div className="flex items-center justify-between mb-3">
                <h4 className="text-base font-bold text-white font-heading">{persona.name}</h4>
                <span className="text-xs bg-slate-800 text-slate-300 px-2 py-0.5 rounded-md font-mono">
                  {persona.age}
                </span>
              </div>

              <p className="text-xs text-slate-300 mb-3 leading-relaxed">
                {persona.description}
              </p>

              <div className="space-y-2 text-xs border-t border-slate-800/80 pt-3">
                <div className="flex items-start gap-2">
                  <span className="text-amber-400 font-bold">⏱️ عادة الاستخدام:</span>
                  <span className="text-slate-300">{persona.usageHabit}</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-rose-400 font-bold">⚠️ ما يزعجه في التطبيقات الأخرى:</span>
                  <span className="text-slate-300">{persona.painPoint}</span>
                </div>
                <div className="flex items-start gap-2">
                  <span className="text-emerald-400 font-bold">❤️ لماذا سيعشق مشروعك:</span>
                  <span className="text-slate-200 font-medium">{persona.whyTheyLoveIt}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Context of Use */}
      <div className="bg-indigo-950/20 border border-indigo-500/20 rounded-2xl p-4 flex items-start gap-3">
        <Clock className="w-5 h-5 text-indigo-400 shrink-0 mt-0.5" />
        <div>
          <h4 className="text-xs font-bold text-indigo-300 mb-1">ظروف وبيئة الاستخدام على هاتف أندرويد:</h4>
          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
            {project.targetAudience.usageContext}
          </p>
        </div>
      </div>

      {/* Navigation Buttons */}
      <div className="flex items-center justify-between pt-2">
        <button
          onClick={onPrevStage}
          className="px-5 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-bold"
        >
          السابق: الفكرة والمميزات
        </button>

        <button
          onClick={onNextStage}
          className="px-6 py-3 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl text-sm flex items-center gap-2 shadow-lg shadow-indigo-600/25 transition-transform active:scale-95"
        >
          <span>المرحلة التالية: تصميم الواجهات وتجربة RTL</span>
          <ArrowRight className="w-4 h-4 rotate-180" />
        </button>
      </div>
    </div>
  );
};
