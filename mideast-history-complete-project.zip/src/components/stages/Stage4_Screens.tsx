import React, { useState } from 'react';
import { ProjectData, ScreenDefinition } from '../../types';
import { LayoutGrid, Layers, ArrowRight, CornerDownLeft, PlayCircle } from 'lucide-react';

interface Props {
  project: ProjectData;
  onNextStage: () => void;
  onPrevStage: () => void;
}

export const Stage4_Screens: React.FC<Props> = ({ project, onNextStage, onPrevStage }) => {
  const [selectedScreenId, setSelectedScreenId] = useState<string>(project.screens[0]?.id || '');

  const activeScreen = project.screens.find((s) => s.id === selectedScreenId) || project.screens[0];

  return (
    <div className="space-y-6 animate-in fade-in">
      <div className="bg-gradient-to-br from-indigo-950/40 via-slate-900 to-slate-950 border border-indigo-500/30 rounded-3xl p-6">
        <div className="inline-flex items-center gap-2 bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 px-3 py-1 rounded-full text-xs font-bold mb-3">
          <Layers className="w-3.5 h-3.5" />
          <span>المرحلة 4 من 9: تحديد جميع الشاشات والأزرار والوظائف</span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-black text-white font-heading mb-2">
          خريطة الشاشات ومنطق الأزرار والتفاعل
        </h2>
        <p className="text-sm text-slate-300">
          دليل برمجي عملي يشرح كل شاشة، وظيفتها، وماذا يحدث بالضبط عند الضغط على كل زر (Action & State Trigger).
        </p>
      </div>

      {/* Screen Tabs Selector */}
      <div className="flex flex-wrap gap-2">
        {project.screens.map((screen, idx) => {
          const isSelected = screen.id === selectedScreenId;
          return (
            <button
              key={screen.id}
              onClick={() => setSelectedScreenId(screen.id)}
              className={`px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 border ${
                isSelected
                  ? 'bg-indigo-600 border-indigo-500 text-white shadow-lg shadow-indigo-600/30'
                  : 'bg-slate-900/90 border-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              <span className="w-5 h-5 rounded-md bg-black/20 flex items-center justify-center font-mono text-[10px]">
                {idx + 1}
              </span>
              <span>{screen.title}</span>
            </button>
          );
        })}
      </div>

      {/* Active Screen Detail Card */}
      {activeScreen && (
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 pb-4">
            <div>
              <span className="text-xs text-indigo-400 font-mono">معرف الشاشة: #{activeScreen.id}</span>
              <h3 className="text-xl font-bold text-white font-heading">{activeScreen.title}</h3>
              <p className="text-xs text-slate-300 mt-1">{activeScreen.description}</p>
            </div>

            <div className="bg-indigo-500/10 border border-indigo-500/20 px-3 py-1.5 rounded-xl text-xs text-indigo-300">
              <span className="font-bold">الهدف الأساسي: </span>
              <span>{activeScreen.purpose}</span>
            </div>
          </div>

          {/* Buttons Table */}
          <div>
            <h4 className="text-sm font-bold text-white mb-3 flex items-center gap-2 font-heading">
              <LayoutGrid className="w-4 h-4 text-amber-400" />
              <span>الأزرار التفاعلية والوظائف البرمجية المرتبطة بها:</span>
            </h4>

            <div className="space-y-2.5">
              {activeScreen.buttons.map((btn, idx) => (
                <div
                  key={idx}
                  className="p-3.5 bg-slate-950/80 border border-slate-800/80 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                >
                  <div className="flex items-center gap-3">
                    <span className="px-3 py-1.5 rounded-lg text-xs font-bold bg-slate-800 text-slate-200 border border-slate-700 font-heading">
                      {btn.label}
                    </span>
                    <div>
                      <div className="text-xs font-semibold text-slate-200 flex items-center gap-1.5">
                        <CornerDownLeft className="w-3 h-3 text-indigo-400" />
                        <span>{btn.action}</span>
                      </div>
                      <div className="text-[11px] text-slate-400 mt-0.5">{btn.notes}</div>
                    </div>
                  </div>

                  {btn.targetScreen && (
                    <div className="inline-flex items-center gap-1 text-[11px] font-mono bg-purple-500/10 text-purple-300 border border-purple-500/20 px-2.5 py-1 rounded-md self-start sm:self-center">
                      <span>ينقل إلى ⬅️</span>
                      <span className="font-bold">{btn.targetScreen}</span>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Key Data Displayed */}
          <div className="pt-3 border-t border-slate-800/80">
            <h5 className="text-xs font-bold text-slate-400 mb-2">البيانات والمتغيرات المعروضة في هذه الشاشة (State & Data):</h5>
            <div className="flex flex-wrap gap-2">
              {activeScreen.keyData.map((data, idx) => (
                <span
                  key={idx}
                  className="text-xs bg-slate-950 border border-slate-800 text-slate-300 px-3 py-1 rounded-lg"
                >
                  🔹 {data}
                </span>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Navigation Buttons */}
      <div className="flex items-center justify-between pt-2">
        <button
          onClick={onPrevStage}
          className="px-5 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-bold"
        >
          السابق: نظام الواجهات والتصميم
        </button>

        <button
          onClick={onNextStage}
          className="px-6 py-3 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl text-sm flex items-center gap-2 shadow-lg shadow-indigo-600/25 transition-transform active:scale-95"
        >
          <span>المرحلة التالية: اختيار التقنية للمبتدئ وهاتف أندرويد</span>
          <ArrowRight className="w-4 h-4 rotate-180" />
        </button>
      </div>
    </div>
  );
};
