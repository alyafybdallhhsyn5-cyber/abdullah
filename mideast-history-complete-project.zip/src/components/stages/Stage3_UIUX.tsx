import React from 'react';
import { ProjectData } from '../../types';
import { Palette, Smartphone, AlignRight, CheckCircle2, ArrowRight } from 'lucide-react';

interface Props {
  project: ProjectData;
  onNextStage: () => void;
  onPrevStage: () => void;
}

export const Stage3_UIUX: React.FC<Props> = ({ project, onNextStage, onPrevStage }) => {
  const { designSystem } = project;

  return (
    <div className="space-y-6 animate-in fade-in">
      <div className="bg-gradient-to-br from-indigo-950/40 via-slate-900 to-slate-950 border border-indigo-500/30 rounded-3xl p-6">
        <div className="inline-flex items-center gap-2 bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 px-3 py-1 rounded-full text-xs font-bold mb-3">
          <Palette className="w-3.5 h-3.5" />
          <span>المرحلة 3 من 9: تصميم الواجهات وتجربة المستخدم RTL</span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-black text-white font-heading mb-2">
          نظام التصميم العربي وهندسة الشاشة للهاتف
        </h2>
        <p className="text-sm text-slate-300">
          كيف نصنع واجهة مريحة لإبهام اليد الواحدة، تدعم الاتجاه العربي من اليمين لليسار، وبألوان متباينة تحمي العين وتوفر طاقة شاشة AMOLED في هواتف أندرويد.
        </p>
      </div>

      {/* Color Palette Display */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5">
        <h3 className="font-bold text-base text-white mb-3 flex items-center gap-2 font-heading">
          <Palette className="w-4 h-4 text-indigo-400" />
          <span>لوحة الألوان المعتمدة (Color Palette):</span>
        </h3>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 text-center">
            <div
              className="w-full h-12 rounded-lg mb-2 shadow-inner"
              style={{ backgroundColor: designSystem.primaryColor }}
            />
            <div className="text-xs font-bold text-white">اللون الأساسي</div>
            <div className="text-[11px] font-mono text-slate-400">{designSystem.primaryColor}</div>
          </div>

          <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 text-center">
            <div
              className="w-full h-12 rounded-lg mb-2 shadow-inner"
              style={{ backgroundColor: designSystem.secondaryColor }}
            />
            <div className="text-xs font-bold text-white">اللون الثانوي</div>
            <div className="text-[11px] font-mono text-slate-400">{designSystem.secondaryColor}</div>
          </div>

          <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 text-center">
            <div
              className="w-full h-12 rounded-lg mb-2 shadow-inner"
              style={{ backgroundColor: designSystem.accentColor }}
            />
            <div className="text-xs font-bold text-white">لون التفاعل والنجاح</div>
            <div className="text-[11px] font-mono text-slate-400">{designSystem.accentColor}</div>
          </div>

          <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 text-center">
            <div
              className="w-full h-12 rounded-lg mb-2 border border-slate-700 shadow-inner"
              style={{ backgroundColor: designSystem.bgColor }}
            />
            <div className="text-xs font-bold text-white">خلفية الشاشة العميقة</div>
            <div className="text-[11px] font-mono text-slate-400">{designSystem.bgColor}</div>
          </div>
        </div>
      </div>

      {/* Thumb Zone & RTL Rules */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Thumb Ergonomics */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5">
          <div className="flex items-center gap-2 text-indigo-400 font-bold mb-3 font-heading">
            <Smartphone className="w-5 h-5" />
            <span>منطقة وصول الإبهام (Thumb Zone Friendly)</span>
          </div>
          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed mb-4">
            {designSystem.thumbErgonomics}
          </p>

          <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 text-xs space-y-2">
            <div className="flex items-center justify-between text-slate-400">
              <span>أعلى الشاشة (الأصعب وصولاً):</span>
              <span className="text-slate-300 font-bold">للعناوين والمؤشرات فقط</span>
            </div>
            <div className="flex items-center justify-between text-slate-400">
              <span>منتصف الشاشة (منطقة الرؤية):</span>
              <span className="text-slate-300 font-bold">للبطاقات والمحتوى</span>
            </div>
            <div className="flex items-center justify-between text-emerald-400 font-bold">
              <span>أسفل الشاشة (المنطقة الذهبية):</span>
              <span>للأزرار الرئيسية والقفز والتأكيد</span>
            </div>
          </div>
        </div>

        {/* RTL Guidelines */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5">
          <div className="flex items-center gap-2 text-emerald-400 font-bold mb-3 font-heading">
            <AlignRight className="w-5 h-5" />
            <span>قواعد التصميم باللغة العربية (RTL)</span>
          </div>
          <div className="space-y-2.5">
            {designSystem.rtlGuidelines.map((rule, idx) => (
              <div key={idx} className="flex items-start gap-2.5 text-xs sm:text-sm text-slate-300">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>{rule}</span>
              </div>
            ))}
          </div>

          <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
            <span>الخط المعتمد للعناوين: <strong className="text-white font-mono">{designSystem.fontHeading}</strong></span>
            <span>خط النصوص: <strong className="text-white font-mono">{designSystem.fontFamily}</strong></span>
          </div>
        </div>
      </div>

      {/* Navigation Buttons */}
      <div className="flex items-center justify-between pt-2">
        <button
          onClick={onPrevStage}
          className="px-5 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-bold"
        >
          السابق: الجمهور المستهدف
        </button>

        <button
          onClick={onNextStage}
          className="px-6 py-3 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl text-sm flex items-center gap-2 shadow-lg shadow-indigo-600/25 transition-transform active:scale-95"
        >
          <span>المرحلة التالية: تفصيل الشاشات والأزرار والوظائف</span>
          <ArrowRight className="w-4 h-4 rotate-180" />
        </button>
      </div>
    </div>
  );
};
