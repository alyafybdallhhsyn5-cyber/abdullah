import React, { useState } from 'react';
import { ProjectData } from '../../types';
import { playSound } from '../../utils/audio';
import { ShieldCheck, CheckCircle2, Play, Activity, Smartphone, ArrowRight, RefreshCw, Cpu } from 'lucide-react';

interface Props {
  project: ProjectData;
  onNextStage: () => void;
  onPrevStage: () => void;
}

export const Stage7_QATestLab: React.FC<Props> = ({ project, onNextStage, onPrevStage }) => {
  const [touchLatency, setTouchLatency] = useState<number | null>(null);
  const [storageStatus, setStorageStatus] = useState<string | null>(null);
  const [screenInfo, setScreenInfo] = useState<{ width: number; height: number; dpr: number } | null>(null);
  const [activeChecklist, setActiveChecklist] = useState(project.qaChecklist);

  // Test 1: Touch / Click Latency
  const testTouchSpeed = () => {
    const start = performance.now();
    setTimeout(() => {
      const elapsed = Math.round(performance.now() - start);
      setTouchLatency(elapsed);
      playSound('success');
    }, 0);
  };

  // Test 2: LocalStorage Persistence
  const testStorage = () => {
    try {
      const testKey = '__qa_test_' + Date.now();
      localStorage.setItem(testKey, 'PASSED_OK');
      const val = localStorage.getItem(testKey);
      localStorage.removeItem(testKey);
      if (val === 'PASSED_OK') {
        setStorageStatus('سليم 100% (يمكن حفظ النقاط والبيانات بدون إنترنت)');
        playSound('coin');
      } else {
        setStorageStatus('تعذر القراءة');
      }
    } catch (err) {
      setStorageStatus('الذاكرة مقيدة أو ممتلئة');
    }
  };

  // Test 3: Screen Dimensions
  const testScreen = () => {
    setScreenInfo({
      width: window.innerWidth,
      height: window.innerHeight,
      dpr: window.devicePixelRatio || 1
    });
    playSound('click');
  };

  return (
    <div className="space-y-6 animate-in fade-in">
      <div className="bg-gradient-to-br from-indigo-950/40 via-slate-900 to-slate-950 border border-indigo-500/30 rounded-3xl p-6">
        <div className="inline-flex items-center gap-2 bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-3 py-1 rounded-full text-xs font-bold mb-3">
          <ShieldCheck className="w-3.5 h-3.5" />
          <span>المرحلة 7 من 9: اختبار الوظائف الأساسية وإصلاح الأخطاء (QA Lab)</span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-black text-white font-heading mb-2">
          معمل الفحص الذاتي واختبار الجودة على هاتفك
        </h2>
        <p className="text-sm text-slate-300">
          قبل إرسال اللعبة أو التطبيق لأصدقائك، اختبر سرعة الاستجابة، حفظ البيانات في ذاكرة الهاتف، وملاءمة الشاشة.
        </p>
      </div>

      {/* Interactive Diagnostics Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {/* Test 1: Touch Latency */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 text-indigo-400 font-bold text-sm mb-2 font-heading">
              <Activity className="w-4 h-4" />
              <span>فحص سرعة استجابة اللمس</span>
            </div>
            <p className="text-xs text-slate-300 mb-3 leading-relaxed">
              يقيس الوقت بالملي ثانية الذي يستغرقه الكود لمعالجة ضغطة إصبعك على الشاشة.
            </p>
          </div>

          <div>
            {touchLatency !== null && (
              <div className="mb-3 p-2.5 rounded-xl bg-emerald-950/40 border border-emerald-500/30 text-center">
                <span className="text-[11px] text-slate-400 block">زمن الاستجابة:</span>
                <span className="text-xl font-black text-emerald-400 font-mono">{touchLatency} ms</span>
                <span className="text-[10px] text-emerald-300 block font-bold">ممتاز وخارق للألعاب! ⚡</span>
              </div>
            )}
            <button
              onClick={testTouchSpeed}
              className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold transition-all active:scale-95 flex items-center justify-center gap-1.5"
            >
              <Play className="w-3.5 h-3.5" />
              <span>انقر للاختبار الفوري</span>
            </button>
          </div>
        </div>

        {/* Test 2: Local Storage */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 text-amber-400 font-bold text-sm mb-2 font-heading">
              <Cpu className="w-4 h-4" />
              <span>فحص ذاكرة الهاتف (Offline)</span>
            </div>
            <p className="text-xs text-slate-300 mb-3 leading-relaxed">
              يفحص قدرة مشروعك على حفظ أعلى النتائج والعادات بدون إنترنت.
            </p>
          </div>

          <div>
            {storageStatus && (
              <div className="mb-3 p-2.5 rounded-xl bg-amber-950/40 border border-amber-500/30 text-center">
                <span className="text-[11px] text-amber-300 font-bold block">{storageStatus}</span>
              </div>
            )}
            <button
              onClick={testStorage}
              className="w-full py-2.5 bg-amber-600 hover:bg-amber-500 text-slate-950 rounded-xl text-xs font-black transition-all active:scale-95 flex items-center justify-center gap-1.5"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>فحص الحفظ المحلي</span>
            </button>
          </div>
        </div>

        {/* Test 3: Screen & Viewport */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 text-emerald-400 font-bold text-sm mb-2 font-heading">
              <Smartphone className="w-4 h-4" />
              <span>فحص مقاس شاشة هاتفك</span>
            </div>
            <p className="text-xs text-slate-300 mb-3 leading-relaxed">
              يتأكد من أبعاد الشاشة الحالية ومعدل كثافة البكسلات (DPR).
            </p>
          </div>

          <div>
            {screenInfo && (
              <div className="mb-3 p-2 rounded-xl bg-slate-950 border border-slate-800 text-center text-xs font-mono text-slate-300">
                <div>العرض: {screenInfo.width}px × الارتفاع: {screenInfo.height}px</div>
                <div className="text-[10px] text-emerald-400">كثافة البكسل: {screenInfo.dpr}x</div>
              </div>
            )}
            <button
              onClick={testScreen}
              className="w-full py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-bold transition-all active:scale-95 flex items-center justify-center gap-1.5"
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span>قراءة أبعاد جهازي</span>
            </button>
          </div>
        </div>
      </div>

      {/* Complete Project QA Checklist */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5">
        <h3 className="font-bold text-base text-white mb-3 flex items-center gap-2 font-heading">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>قائمة الفحص النهائي لمشروعك (QA Audit Checklist):</span>
        </h3>

        <div className="space-y-2.5">
          {activeChecklist.map((item) => (
            <div
              key={item.id}
              className="p-3.5 bg-slate-950/80 border border-slate-800/80 rounded-xl flex items-start justify-between gap-3"
            >
              <div className="flex items-start gap-3">
                <div className="p-1 rounded-lg bg-emerald-500/20 text-emerald-400 shrink-0 mt-0.5">
                  <CheckCircle2 className="w-4 h-4" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h4 className="text-xs sm:text-sm font-bold text-white">{item.title}</h4>
                    <span className="text-[10px] bg-slate-800 text-slate-400 px-2 py-0.5 rounded-md font-mono">
                      {item.category}
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                    {item.details}
                  </p>
                </div>
              </div>

              <span className="text-[11px] font-bold text-emerald-400 bg-emerald-500/10 px-2.5 py-1 rounded-md border border-emerald-500/20 shrink-0">
                تم التحقق ✓
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Navigation Buttons */}
      <div className="flex items-center justify-between pt-2">
        <button
          onClick={onPrevStage}
          className="px-5 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-bold"
        >
          السابق: النموذج الأولي الحي
        </button>

        <button
          onClick={onNextStage}
          className="px-6 py-3 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl text-sm flex items-center gap-2 shadow-lg shadow-indigo-600/25 transition-transform active:scale-95"
        >
          <span>المرحلة التالية: دليل تصدير التطبيق إلى Android (APK) 📦</span>
          <ArrowRight className="w-4 h-4 rotate-180" />
        </button>
      </div>
    </div>
  );
};
