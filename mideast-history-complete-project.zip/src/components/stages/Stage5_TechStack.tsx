import React from 'react';
import { ProjectData } from '../../types';
import { Cpu, CheckCircle2, AlertCircle, ArrowRight, Star, Smartphone, Rocket } from 'lucide-react';

interface Props {
  project: ProjectData;
  onNextStage: () => void;
  onPrevStage: () => void;
}

export const Stage5_TechStack: React.FC<Props> = ({ project, onNextStage, onPrevStage }) => {
  const { techStack } = project;

  return (
    <div className="space-y-6 animate-in fade-in">
      <div className="bg-gradient-to-br from-indigo-950/40 via-slate-900 to-slate-950 border border-indigo-500/30 rounded-3xl p-6">
        <div className="inline-flex items-center gap-2 bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 px-3 py-1 rounded-full text-xs font-bold mb-3">
          <Cpu className="w-3.5 h-3.5" />
          <span>المرحلة 5 من 9: اختيار التقنية المناسبة للمبتدئ وللهاتف</span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-black text-white font-heading mb-2">
          كيف تبني مشروعك وأنت مبتدئ وتملك هاتف أندرويد فقط؟
        </h2>
        <p className="text-sm text-slate-300">
          لا تحتاج لشراء كمبيوتر غالي بآلاف الدولارات للبدء! يمكنك كتابة الكود وتجربته فوراً على هاتفك الذكي باستخدام التقنيات الحديثة.
        </p>
      </div>

      {/* Recommended Tech Banner */}
      <div className="bg-gradient-to-r from-emerald-950/40 via-slate-900 to-indigo-950/40 border-2 border-emerald-500/40 rounded-2xl p-5 relative overflow-hidden">
        <div className="flex items-center gap-2 text-emerald-400 text-xs font-bold mb-2">
          <Star className="w-4 h-4 fill-emerald-400" />
          <span>الترشيح الذهبي الأنسب لوضعك (Recommended Stack)</span>
        </div>

        <h3 className="text-xl font-black text-white font-heading mb-2">
          {techStack.recommended}
        </h3>

        <p className="text-xs sm:text-sm text-slate-200 leading-relaxed mb-4">
          {techStack.justification}
        </p>

        <div className="flex flex-wrap gap-2 text-xs">
          <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 px-2.5 py-1 rounded-lg font-bold">
            التكلفة: 0$ مجاني
          </span>
          <span className="bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 px-2.5 py-1 rounded-lg font-bold">
            يعمل مباشرة في متصفح هاتفك الأندرويد
          </span>
          <span className="bg-amber-500/20 text-amber-300 border border-amber-500/30 px-2.5 py-1 rounded-lg font-bold">
            تحويل مجاني لـ APK عبر PWABuilder
          </span>
        </div>
      </div>

      {/* Detailed Tech Options Comparison */}
      <div className="space-y-3">
        <h3 className="text-base font-bold text-white font-heading flex items-center gap-2">
          <Smartphone className="w-4 h-4 text-indigo-400" />
          <span>مقارنة الخيارات التقنية للمبتدئين:</span>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {techStack.options.map((opt, idx) => (
            <div
              key={idx}
              className={`bg-slate-900/90 border rounded-2xl p-5 flex flex-col justify-between ${
                opt.isRecommended ? 'border-indigo-500/50 shadow-lg shadow-indigo-500/10' : 'border-slate-800'
              }`}
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <h4 className="text-base font-bold text-white font-heading">{opt.name}</h4>
                  <span className="text-[11px] bg-slate-800 text-slate-300 px-2 py-0.5 rounded-md font-bold">
                    {opt.tag}
                  </span>
                </div>

                <p className="text-xs text-slate-300 mb-3 leading-relaxed">
                  {opt.description}
                </p>

                <div className="grid grid-cols-2 gap-2 text-[11px] mb-3">
                  <div className="bg-slate-950 p-2 rounded-lg border border-slate-800">
                    <span className="text-slate-400 block">مستوى الصعوبة:</span>
                    <span className="font-bold text-slate-200">{opt.difficulty}</span>
                  </div>
                  <div className="bg-slate-950 p-2 rounded-lg border border-slate-800">
                    <span className="text-slate-400 block">التوافق مع الهاتف:</span>
                    <span className="font-bold text-emerald-400">{opt.androidCompatibility}</span>
                  </div>
                </div>

                <div className="space-y-1.5 text-xs border-t border-slate-800 pt-3">
                  <div className="text-emerald-400 font-bold text-[11px]">المميزات القوية:</div>
                  {opt.pros.map((p, pIdx) => (
                    <div key={pIdx} className="flex items-center gap-1.5 text-slate-300">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                      <span>{p}</span>
                    </div>
                  ))}
                  <div className="text-rose-400 font-bold text-[11px] pt-1">السلبيات أو التحديات:</div>
                  {opt.cons.map((c, cIdx) => (
                    <div key={cIdx} className="flex items-center gap-1.5 text-slate-400">
                      <AlertCircle className="w-3.5 h-3.5 text-rose-400 shrink-0" />
                      <span>{c}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-800/80 text-[11px] text-slate-400">
                <span className="text-slate-300 font-bold">أفضل استخدام: </span>
                <span>{opt.bestFor}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Beginner Tips for Android Users */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5">
        <h4 className="text-sm font-bold text-amber-400 mb-3 flex items-center gap-2 font-heading">
          <Rocket className="w-4 h-4" />
          <span>نصائح ذهبية للمطور المبتدئ على هاتف أندرويد:</span>
        </h4>
        <div className="space-y-2">
          {techStack.beginnerTips.map((tip, idx) => (
            <div key={idx} className="p-3 bg-slate-950 rounded-xl border border-slate-800/80 text-xs text-slate-200 flex items-start gap-2.5">
              <span className="text-amber-400 font-black">#{idx + 1}</span>
              <span className="leading-relaxed">{tip}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Navigation Buttons */}
      <div className="flex items-center justify-between pt-2">
        <button
          onClick={onPrevStage}
          className="px-5 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-bold"
        >
          السابق: خريطة الشاشات والأزرار
        </button>

        <button
          onClick={onNextStage}
          className="px-6 py-3 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl text-sm flex items-center gap-2 shadow-lg shadow-indigo-600/25 transition-transform active:scale-95"
        >
          <span>المرحلة التالية: تجربة النموذج الأولي الحي والمحاكي 🎮</span>
          <ArrowRight className="w-4 h-4 rotate-180" />
        </button>
      </div>
    </div>
  );
};
