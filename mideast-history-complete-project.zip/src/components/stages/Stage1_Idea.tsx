import React from 'react';
import { ProjectData } from '../../types';
import { Sparkles, Lightbulb, CheckCircle, Target, ArrowRight } from 'lucide-react';

interface Props {
  project: ProjectData;
  onNextStage: () => void;
}

export const Stage1_Idea: React.FC<Props> = ({ project, onNextStage }) => {
  return (
    <div className="space-y-6 animate-in fade-in">
      {/* Hero Header */}
      <div className="bg-gradient-to-br from-indigo-950/40 via-slate-900 to-slate-950 border border-indigo-500/30 rounded-3xl p-6 relative overflow-hidden">
        <div className="absolute top-0 left-0 w-64 h-64 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />
        
        <div className="flex flex-wrap items-center justify-between gap-3 mb-3">
          <div className="inline-flex items-center gap-2 bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 px-3 py-1 rounded-full text-xs font-bold">
            <Sparkles className="w-3.5 h-3.5" />
            <span>المرحلة 1 من 9: تطوير الفكرة والابتكار</span>
          </div>
          <span className="text-xs text-slate-400 font-mono">
            النوع: {project.type === 'game' ? '🎮 لعبة أندرويد تفاعلية' : '📱 تطبيق هاتف ذكي'}
          </span>
        </div>

        <h2 className="text-2xl sm:text-3xl font-black text-white font-heading mb-2">
          {project.title}
        </h2>
        <p className="text-sm sm:text-base text-indigo-200/90 leading-relaxed max-w-3xl">
          {project.slogan}
        </p>
      </div>

      {/* Core Idea & Summary */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5">
          <div className="flex items-center gap-2.5 text-amber-400 mb-3">
            <Lightbulb className="w-5 h-5" />
            <h3 className="font-bold text-base font-heading">الفكرة الجوهرية (Core Loop)</h3>
          </div>
          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
            {project.coreIdea}
          </p>
          <div className="mt-4 pt-3 border-t border-slate-800/80 text-xs text-slate-400 leading-relaxed">
            <span className="font-bold text-slate-300">الملخص: </span>
            {project.summary}
          </div>
        </div>

        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5">
          <div className="flex items-center gap-2.5 text-emerald-400 mb-3">
            <Target className="w-5 h-5" />
            <h3 className="font-bold text-base font-heading">سر النجاح لمستخدم الهاتف الأندرويد</h3>
          </div>
          <ul className="space-y-2 text-xs sm:text-sm text-slate-300">
            <li className="flex items-start gap-2">
              <span className="text-emerald-400 font-bold">✓</span>
              <span><strong>فتح فوري:</strong> لا ينتظر المستخدم أكثر من ثانيتين لتبدأ المتعة أو يبدأ إنجاز المهمة.</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-emerald-400 font-bold">✓</span>
              <span><strong>استهلاك خفيف:</strong> لا يستنزف طاقة بطارية الهاتف ولا يحتاج لذاكرة تخزين ضخمة.</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-emerald-400 font-bold">✓</span>
              <span><strong>لغة عربية أصيلة:</strong> واجهات صريحة ومفهومة بدون ترجمات آلية ركيكة.</span>
            </li>
          </ul>
        </div>
      </div>

      {/* Innovations List */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5">
        <h3 className="font-bold text-base text-white mb-3 flex items-center gap-2 font-heading">
          <Sparkles className="w-4 h-4 text-indigo-400" />
          <span>المميزات المبتكرة المضافة لفكرتك:</span>
        </h3>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {project.innovations.map((item, idx) => (
            <div
              key={idx}
              className="p-3.5 bg-slate-950/80 border border-slate-800/80 rounded-xl flex items-start gap-3 hover:border-indigo-500/40 transition-colors"
            >
              <div className="w-6 h-6 rounded-lg bg-indigo-500/20 text-indigo-400 border border-indigo-500/30 flex items-center justify-center text-xs font-black shrink-0 mt-0.5">
                {idx + 1}
              </div>
              <p className="text-xs sm:text-sm text-slate-200 leading-relaxed">
                {item}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Next Button */}
      <div className="flex justify-end pt-2">
        <button
          onClick={onNextStage}
          className="px-6 py-3 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl text-sm flex items-center gap-2 shadow-lg shadow-indigo-600/25 transition-transform active:scale-95"
        >
          <span>المرحلة التالية: الجمهور وسيناريو الاستخدام</span>
          <ArrowRight className="w-4 h-4 rotate-180" />
        </button>
      </div>
    </div>
  );
};
