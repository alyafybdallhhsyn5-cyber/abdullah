import React, { useState } from 'react';
import { ProjectData } from '../../types';
import { playSound } from '../../utils/audio';
import { Download, Smartphone, Share2, FileCode, CheckCircle, Copy, ArrowRight, ExternalLink } from 'lucide-react';

interface Props {
  project: ProjectData;
  onNextStage: () => void;
  onPrevStage: () => void;
}

export const Stage8_AndroidExport: React.FC<Props> = ({ project, onNextStage, onPrevStage }) => {
  const [activeTab, setActiveTab] = useState<'pwa' | 'apk' | 'manifest'>('pwa');
  const [copiedManifest, setCopiedManifest] = useState(false);

  const copyManifest = () => {
    navigator.clipboard.writeText(project.androidExport.manifestExample);
    setCopiedManifest(true);
    playSound('coin');
    setTimeout(() => setCopiedManifest(false), 2000);
  };

  const downloadManifestFile = () => {
    const blob = new Blob([project.androidExport.manifestExample], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'manifest.json';
    a.click();
    URL.revokeObjectURL(url);
    playSound('success');
  };

  return (
    <div className="space-y-6 animate-in fade-in">
      <div className="bg-gradient-to-br from-indigo-950/40 via-slate-900 to-slate-950 border border-indigo-500/30 rounded-3xl p-6">
        <div className="inline-flex items-center gap-2 bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 px-3 py-1 rounded-full text-xs font-bold mb-3">
          <Smartphone className="w-3.5 h-3.5" />
          <span>المرحلة 8 من 9: شرح طريقة تجربة وتصدير المشروع إلى تطبيق Android</span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-black text-white font-heading mb-2">
          كيف تحوّل هذا المشروع إلى تطبيق مثبت على هاتف أندرويد؟
        </h2>
        <p className="text-sm text-slate-300">
          دليل عملي مبسط جداً بدون تعقيد، مخصص لك كمبتدئ يستخدم هاتف أندرويد فقط: 3 طرق من الأسهل والأسرع إلى التصدير الرسمي.
        </p>
      </div>

      {/* Method Selector Tabs */}
      <div className="flex border-b border-slate-800 gap-2">
        <button
          onClick={() => setActiveTab('pwa')}
          className={`pb-3 px-4 text-xs sm:text-sm font-bold border-b-2 transition-all flex items-center gap-2 ${
            activeTab === 'pwa'
              ? 'border-emerald-500 text-emerald-400'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <span>الطريقة 1: التثبيت الفوري PWA (الأسهل والأسرع ⚡)</span>
        </button>

        <button
          onClick={() => setActiveTab('apk')}
          className={`pb-3 px-4 text-xs sm:text-sm font-bold border-b-2 transition-all flex items-center gap-2 ${
            activeTab === 'apk'
              ? 'border-indigo-500 text-indigo-400'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <span>الطريقة 2: بناء حزمة APK عبر PWABuilder (مجاناً 📦)</span>
        </button>

        <button
          onClick={() => setActiveTab('manifest')}
          className={`pb-3 px-4 text-xs sm:text-sm font-bold border-b-2 transition-all flex items-center gap-2 ${
            activeTab === 'manifest'
              ? 'border-purple-500 text-purple-400'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <span>ملف التعريف manifest.json</span>
        </button>
      </div>

      {/* Tab 1: PWA Instant Install */}
      {activeTab === 'pwa' && (
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 space-y-4 animate-in fade-in">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-white font-heading flex items-center gap-2">
              <span className="text-emerald-400">📲</span>
              <span>خطوات تثبيت التطبيق على هاتفك خلال 30 ثانية بدون أي برامج:</span>
            </h3>
            <span className="text-xs bg-emerald-500/20 text-emerald-300 px-2.5 py-1 rounded-lg border border-emerald-500/30 font-bold">
              مجاني 100%
            </span>
          </div>

          <div className="space-y-3">
            {project.androidExport.pwaSteps.map((step, idx) => (
              <div
                key={idx}
                className="p-3.5 bg-slate-950/80 border border-slate-800/80 rounded-xl flex items-start gap-3"
              >
                <div className="w-6 h-6 rounded-lg bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center text-xs font-black shrink-0 mt-0.5">
                  {idx + 1}
                </div>
                <div className="text-xs sm:text-sm text-slate-200 leading-relaxed font-medium">
                  {step}
                </div>
              </div>
            ))}
          </div>

          <div className="p-4 bg-emerald-950/20 border border-emerald-500/20 rounded-xl text-xs text-slate-300 leading-relaxed">
            <strong className="text-emerald-400">لماذا هذه الطريقة هي الأفضل لك كمبتدئ؟</strong><br />
            لأنك عندما تحدث أي شيء في الكود أو اللعبة، سيتحدث تطبيق الهاتف تلقائياً فوراً دون الحاجة لإعادة تثبيت أي شيء، ويعمل ملء الشاشة تماماً مثل أي لعبة محملة من متجر جوجل بلاي!
          </div>
        </div>
      )}

      {/* Tab 2: PWABuilder APK Generator */}
      {activeTab === 'apk' && (
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 space-y-4 animate-in fade-in">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-white font-heading flex items-center gap-2">
              <span className="text-indigo-400">📦</span>
              <span>تحويل الرابط إلى ملف Android APK قابل للإرسال والتثبيت:</span>
            </h3>
            <span className="text-xs bg-indigo-500/20 text-indigo-300 px-2.5 py-1 rounded-lg border border-indigo-500/30 font-bold">
              أداة مايكروسوفت الرسمية
            </span>
          </div>

          <div className="space-y-3">
            {project.androidExport.apkSteps.map((step, idx) => (
              <div
                key={idx}
                className="p-3.5 bg-slate-950/80 border border-slate-800/80 rounded-xl flex items-start gap-3"
              >
                <div className="w-6 h-6 rounded-lg bg-indigo-500/20 text-indigo-400 border border-indigo-500/30 flex items-center justify-center text-xs font-black shrink-0 mt-0.5">
                  {idx + 1}
                </div>
                <div className="text-xs sm:text-sm text-slate-200 leading-relaxed font-medium">
                  {step}
                </div>
              </div>
            ))}
          </div>

          <div className="p-4 bg-slate-950 border border-indigo-500/30 rounded-xl flex flex-col sm:flex-row items-center justify-between gap-3">
            <div>
              <div className="text-xs font-bold text-white mb-0.5">موقع PWABuilder المعتمد:</div>
              <div className="text-[11px] text-slate-400">أداة مجانية من Microsoft لتحويل تطبيقات الويب إلى APK / AAB.</div>
            </div>
            <a
              href="https://www.pwabuilder.com"
              target="_blank"
              rel="noreferrer"
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shrink-0"
            >
              <span>فتح PWABuilder</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>
        </div>
      )}

      {/* Tab 3: Manifest JSON */}
      {activeTab === 'manifest' && (
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 space-y-4 animate-in fade-in">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-white font-heading">ملف تعريف تطبيق أندرويد (manifest.json)</h3>
              <p className="text-xs text-slate-400">هذا الملف هو البطاقة التعريفية التي تخبر نظام أندرويد باسم تطبيقك ولونه وأيقونته.</p>
            </div>
            <div className="flex gap-2">
              <button
                onClick={copyManifest}
                className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs flex items-center gap-1"
              >
                {copiedManifest ? <CheckCircle className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedManifest ? 'تم النسخ!' : 'نسخ الكود'}</span>
              </button>
              <button
                onClick={downloadManifestFile}
                className="px-3 py-1.5 bg-purple-600 hover:bg-purple-500 text-white rounded-lg text-xs font-bold flex items-center gap-1"
              >
                <Download className="w-3.5 h-3.5" />
                <span>تحميل الملف</span>
              </button>
            </div>
          </div>

          <pre className="p-4 bg-slate-950 border border-slate-800 rounded-xl text-xs text-purple-300 font-mono overflow-x-auto text-left" dir="ltr">
            {project.androidExport.manifestExample}
          </pre>
        </div>
      )}

      {/* Navigation Buttons */}
      <div className="flex items-center justify-between pt-2">
        <button
          onClick={onPrevStage}
          className="px-5 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-bold"
        >
          السابق: معمل فحص الجودة
        </button>

        <button
          onClick={onNextStage}
          className="px-6 py-3 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl text-sm flex items-center gap-2 shadow-lg shadow-indigo-600/25 transition-transform active:scale-95"
        >
          <span>المرحلة الأخيرة: كاشف التكاليف والخدمات المجانية vs المدفوعة 💰</span>
          <ArrowRight className="w-4 h-4 rotate-180" />
        </button>
      </div>
    </div>
  );
};
