import React from 'react';
import { EraType } from '../types/history';
import { ERAS_CONFIG } from '../data/middleEastData';
import { playSound } from '../utils/audio';
import { History, Sparkles } from 'lucide-react';

interface Props {
  activeEra: EraType;
  onSelectEra: (era: EraType) => void;
}

export const EraFilterBar: React.FC<Props> = ({ activeEra, onSelectEra }) => {
  return (
    <div className="w-full bg-slate-900/90 border border-slate-800 rounded-2xl p-2.5 shadow-md">
      <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar">
        <div className="hidden sm:flex items-center gap-1.5 px-3 py-1 text-xs text-amber-400 font-bold shrink-0">
          <History className="w-3.5 h-3.5" />
          <span>الحقبة التاريخية:</span>
        </div>

        {ERAS_CONFIG.map((era) => {
          const isSelected = activeEra === era.id;
          return (
            <button
              key={era.id}
              onClick={() => {
                onSelectEra(era.id as EraType);
                playSound('click');
              }}
              className={`px-3 py-2 rounded-xl text-xs font-semibold whitespace-nowrap shrink-0 transition-all flex flex-col items-start text-right border ${
                isSelected
                  ? 'bg-amber-500/20 border-amber-500 text-amber-300 font-bold shadow-md shadow-amber-500/10'
                  : 'bg-slate-950/60 border-slate-800/80 text-slate-300 hover:text-white hover:border-slate-700'
              }`}
            >
              <span className="font-heading">{era.label}</span>
              <span className="text-[10px] text-slate-400 font-normal hidden lg:inline">
                {era.subtitle}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
};
