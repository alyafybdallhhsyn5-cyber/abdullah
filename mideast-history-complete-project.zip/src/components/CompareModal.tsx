import React, { useState } from 'react';
import { Country } from '../types/history';
import { playSound } from '../utils/audio';
import { X, ArrowLeftRight, Check, Sparkles } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  countries: Country[];
}

export const CompareModal: React.FC<Props> = ({ isOpen, onClose, countries }) => {
  const [country1Id, setCountry1Id] = useState(countries[0]?.id || 'saudi');
  const [country2Id, setCountry2Id] = useState(countries[1]?.id || 'egypt');

  if (!isOpen) return null;

  const country1 = countries.find((c) => c.id === country1Id) || countries[0];
  const country2 = countries.find((c) => c.id === country2Id) || countries[1];

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto animate-in fade-in">
      <div className="relative w-full max-w-4xl bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl my-8 text-right flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800 shrink-0">
          <div className="flex items-center gap-2">
            <ArrowLeftRight className="w-5 h-5 text-amber-400" />
            <h3 className="text-lg font-bold text-white font-heading">
              مقارنة تاريخ وحاضر دولتين في الشرق الأوسط
            </h3>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-xl bg-slate-800 text-slate-400 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Selectors Bar */}
        <div className="grid grid-cols-2 gap-4 my-4 shrink-0">
          <div>
            <label className="text-xs text-slate-400 block mb-1 font-semibold">الدولة الأولى:</label>
            <select
              value={country1Id}
              onChange={(e) => {
                setCountry1Id(e.target.value);
                playSound('click');
              }}
              className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500"
            >
              {countries.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.flag} {c.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-xs text-slate-400 block mb-1 font-semibold">الدولة الثانية:</label>
            <select
              value={country2Id}
              onChange={(e) => {
                setCountry2Id(e.target.value);
                playSound('click');
              }}
              className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500"
            >
              {countries.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.flag} {c.name}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Comparison Content Body */}
        <div className="flex-1 overflow-y-auto space-y-4 pr-1">
          {/* Side by Side Heads */}
          <div className="grid grid-cols-2 gap-4">
            <div className="p-4 rounded-2xl bg-slate-950/70 border border-slate-800 text-center">
              <span className="text-4xl">{country1.flag}</span>
              <h4 className="text-base font-black text-white font-heading mt-1">{country1.name}</h4>
              <div className="text-xs text-amber-400 font-mono mt-0.5">العاصمة: {country1.capital}</div>
            </div>

            <div className="p-4 rounded-2xl bg-slate-950/70 border border-slate-800 text-center">
              <span className="text-4xl">{country2.flag}</span>
              <h4 className="text-base font-black text-white font-heading mt-1">{country2.name}</h4>
              <div className="text-xs text-amber-400 font-mono mt-0.5">العاصمة: {country2.capital}</div>
            </div>
          </div>

          {/* Stats Matrix */}
          <div className="bg-slate-950/50 border border-slate-800 rounded-2xl p-4 text-xs space-y-3">
            <div className="grid grid-cols-3 text-center border-b border-slate-800/80 pb-2">
              <span className="font-bold text-white">{country1.population}</span>
              <span className="text-slate-400">عدد السكان</span>
              <span className="font-bold text-white">{country2.population}</span>
            </div>

            <div className="grid grid-cols-3 text-center border-b border-slate-800/80 pb-2">
              <span className="font-mono text-emerald-400">{country1.areaKm2.toLocaleString('ar-EG')} كم²</span>
              <span className="text-slate-400">المساحة الجغرافية</span>
              <span className="font-mono text-emerald-400">{country2.areaKm2.toLocaleString('ar-EG')} كم²</span>
            </div>

            <div className="grid grid-cols-3 text-center border-b border-slate-800/80 pb-2">
              <span className="font-mono text-amber-300">{country1.currency}</span>
              <span className="text-slate-400">العملة الوطنية</span>
              <span className="font-mono text-amber-300">{country2.currency}</span>
            </div>

            <div className="grid grid-cols-3 text-center">
              <span className="font-bold text-sky-400">{country1.events.length} محطات</span>
              <span className="text-slate-400">التوثيق التاريخي</span>
              <span className="font-bold text-sky-400">{country2.events.length} محطات</span>
            </div>
          </div>

          {/* Ancient Civilizations Comparison */}
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-slate-950/80 border border-slate-800 rounded-2xl p-4">
              <h5 className="text-xs font-bold text-purple-400 mb-2">حضارات {country1.name}:</h5>
              <div className="flex flex-wrap gap-1">
                {country1.ancientCivilizations.map((civ, i) => (
                  <span key={i} className="text-[11px] bg-slate-900 text-slate-300 px-2 py-0.5 rounded-md border border-slate-800">
                    {civ}
                  </span>
                ))}
              </div>
            </div>

            <div className="bg-slate-950/80 border border-slate-800 rounded-2xl p-4">
              <h5 className="text-xs font-bold text-purple-400 mb-2">حضارات {country2.name}:</h5>
              <div className="flex flex-wrap gap-1">
                {country2.ancientCivilizations.map((civ, i) => (
                  <span key={i} className="text-[11px] bg-slate-900 text-slate-300 px-2 py-0.5 rounded-md border border-slate-800">
                    {civ}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* Modern Vision Comparison */}
          <div className="grid grid-cols-2 gap-4">
            <div className="bg-slate-950/80 border border-slate-800 rounded-2xl p-4 text-xs text-slate-300 leading-relaxed">
              <h5 className="font-bold text-emerald-400 mb-1">رؤية {country1.name}:</h5>
              <p>{country1.modernVision}</p>
            </div>

            <div className="bg-slate-950/80 border border-slate-800 rounded-2xl p-4 text-xs text-slate-300 leading-relaxed">
              <h5 className="font-bold text-emerald-400 mb-1">رؤية {country2.name}:</h5>
              <p>{country2.modernVision}</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
