import React, { useState } from 'react';
import { HISTORIAN_QUIZ_QUESTIONS } from '../data/middleEastData';
import { playSound } from '../utils/audio';
import confetti from 'canvas-confetti';
import { Award, CheckCircle2, XCircle, RotateCcw, Sparkles, BookOpen } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext.tsx';

export const HistorianQuiz: React.FC = () => {
  const { user, saveQuizScore } = useAuth();
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);
  const [score, setScore] = useState(0);
  const [quizFinished, setQuizFinished] = useState(false);

  const currentQ = HISTORIAN_QUIZ_QUESTIONS[currentIndex];

  const handleSelect = (idx: number) => {
    if (isAnswered) return;
    setSelectedOption(idx);
    setIsAnswered(true);

    const isCorrect = idx === currentQ.correctIndex;
    if (isCorrect) {
      playSound('success');
      setScore((s) => s + 10);
      confetti({
        particleCount: 30,
        spread: 50,
        origin: { y: 0.6 }
      });
    } else {
      playSound('gameover');
    }
  };

  const handleNext = () => {
    if (currentIndex + 1 < HISTORIAN_QUIZ_QUESTIONS.length) {
      setCurrentIndex((c) => c + 1);
      setSelectedOption(null);
      setIsAnswered(false);
      playSound('click');
    } else {
      setQuizFinished(true);
      playSound('level');
      if (user) {
        saveQuizScore('historian_challenge', score, HISTORIAN_QUIZ_QUESTIONS.length * 10);
      }
      confetti({
        particleCount: 60,
        spread: 80,
        origin: { y: 0.5 }
      });
    }
  };

  const restartQuiz = () => {
    setCurrentIndex(0);
    setSelectedOption(null);
    setIsAnswered(false);
    setScore(0);
    setQuizFinished(false);
    playSound('click');
  };

  return (
    <div className="bg-gradient-to-br from-slate-900 via-slate-950 to-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl text-right max-w-2xl mx-auto animate-in fade-in">
      {/* Quiz Top Header */}
      <div className="flex items-center justify-between pb-4 border-b border-slate-800 mb-6">
        <div className="flex items-center gap-2">
          <BookOpen className="w-5 h-5 text-amber-400" />
          <h3 className="text-lg font-black text-white font-heading">
            تحدي مؤرخ الشرق الأوسط 🏆
          </h3>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-400 font-mono">
            سؤال {currentIndex + 1} من {HISTORIAN_QUIZ_QUESTIONS.length}
          </span>
          <div className="bg-amber-500/15 border border-amber-500/30 px-3 py-1 rounded-xl text-xs font-mono font-bold text-amber-300">
            النقاط: {score}
          </div>
        </div>
      </div>

      {!quizFinished ? (
        <div className="space-y-5">
          {/* Country & Era Badge */}
          <div className="flex items-center justify-between text-xs">
            <span className="text-amber-400 font-bold bg-amber-500/10 px-2.5 py-0.5 rounded-md border border-amber-500/20">
              الدولة: {currentQ.countryName}
            </span>
            <span className="text-slate-400 font-mono">
              الحقبة: {currentQ.era}
            </span>
          </div>

          {/* Question Box */}
          <div className="p-5 rounded-2xl bg-slate-950 border border-slate-800 shadow-md">
            <h4 className="text-base sm:text-lg font-bold text-white leading-relaxed font-heading">
              {currentQ.question}
            </h4>
          </div>

          {/* Answer Options */}
          <div className="space-y-2.5">
            {currentQ.options.map((opt, idx) => {
              let btnClass = 'bg-slate-950 border-slate-800 text-slate-200 hover:border-amber-500/50';

              if (isAnswered) {
                if (idx === currentQ.correctIndex) {
                  btnClass = 'bg-emerald-950/70 border-emerald-500 text-emerald-300 font-bold';
                } else if (idx === selectedOption) {
                  btnClass = 'bg-rose-950/70 border-rose-500 text-rose-300 font-bold';
                } else {
                  btnClass = 'bg-slate-950/40 border-slate-800/40 text-slate-500';
                }
              }

              return (
                <button
                  key={idx}
                  onClick={() => handleSelect(idx)}
                  disabled={isAnswered}
                  className={`w-full p-4 rounded-xl border text-xs sm:text-sm text-right transition-all flex items-center justify-between ${btnClass}`}
                >
                  <span>{opt}</span>
                  {isAnswered && idx === currentQ.correctIndex && (
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  )}
                  {isAnswered && idx === selectedOption && idx !== currentQ.correctIndex && (
                    <XCircle className="w-4 h-4 text-rose-400 shrink-0" />
                  )}
                </button>
              );
            })}
          </div>

          {/* Explanation if Answered */}
          {isAnswered && (
            <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-500/20 text-xs text-amber-200 leading-relaxed animate-in fade-in">
              <strong className="text-amber-300">التفسير التاريخي: </strong>
              {currentQ.explanation}
            </div>
          )}

          {/* Next Button */}
          {isAnswered && (
            <button
              onClick={handleNext}
              className="w-full py-3.5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-black rounded-xl text-xs sm:text-sm shadow-lg shadow-amber-500/20 active:scale-95 transition-transform"
            >
              {currentIndex + 1 < HISTORIAN_QUIZ_QUESTIONS.length ? 'السؤال التالي ⬅️' : 'عرض النتيجة النهائية 🏆'}
            </button>
          )}
        </div>
      ) : (
        /* Quiz Finished Screen */
        <div className="text-center py-6 space-y-4 animate-in zoom-in-95">
          <div className="w-16 h-16 rounded-3xl bg-amber-500/20 border-2 border-amber-500/50 flex items-center justify-center text-3xl mx-auto shadow-lg shadow-amber-500/20">
            🏆
          </div>

          <h4 className="text-xl font-black text-white font-heading">
            أحسنت! أتممت بنجاح تحدي تاريخ الشرق الأوسط
          </h4>

          <p className="text-xs text-slate-300 max-w-md mx-auto">
            مستواك المعرفي يدل على شغفك بتاريخ وحاضر العالم العربي والإسلامي.
          </p>

          <div className="bg-slate-950 border border-amber-500/30 rounded-2xl p-4 max-w-xs mx-auto">
            <div className="text-xs text-slate-400">مجموع النقاط المحققة</div>
            <div className="text-3xl font-black text-amber-400 font-mono mt-1">
              {score} / {HISTORIAN_QUIZ_QUESTIONS.length * 10}
            </div>
          </div>

          <button
            onClick={restartQuiz}
            className="px-6 py-3 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-xl text-xs flex items-center justify-center gap-2 mx-auto transition-transform active:scale-95 shadow-md"
          >
            <RotateCcw className="w-4 h-4" />
            <span>خوض التحدي مرة أخرى</span>
          </button>
        </div>
      )}
    </div>
  );
};
