import React, { useState } from 'react';
import { Country, EraType } from '../types/history';
import { CountryTimeline } from './CountryTimeline';
import { playSound } from '../utils/audio';
import { Globe, Building2, TrendingUp, Landmark, Calendar, Layers, ShieldCheck, Share2, Check, Bookmark } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext.tsx';

interface Props {
  country: Country;
  activeEra: EraType;
  onSelectEra: (era: EraType) => void;
}

export const CountryDossier: React.FC<Props> = ({ country, activeEra, onSelectEra }) => {
  const { user, bookmarks, addBookmark, removeBookmark, signInWithGoogle } = useAuth();
  const [activeTab, setActiveTab] = useState<'timeline' | 'present' | 'heritage'>('timeline');
  const [copied, setCopied] = useState(false);

  const existingBookmark = bookmarks.find((b) => b.itemType === 'country' && b.itemId === country.id);
  const isBookmarked = !!existingBookmark;

  const handleBookmarkToggle = async () => {
    playSound('click');
    if (!user) {
      try {
        await signInWithGoogle();
      } catch (e) {
        console.error(e);
      }
      return;
    }

    if (isBookmarked && existingBookmark) {
      await removeBookmark(existingBookmark.id);
    } else {
      await addBookmark('country', country.id, `${country.flag} ${country.name}`);
      playSound('coin');
    }
  };

  const handleShare = () => {
    const text = `استكشف تاريخ وحاضر ${country.name} - عاصمتها ${country.capital} وتضم ${country.events.length} محطة تاريخية بارزة. صممه: عبدالله حسين (Instagram: @n.0a21)`;
    navigator.clipboard.writeText(text);
    setCopied(true);
    playSound('coin');
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6 animate-in fade-in">
      {/* Country Hero Dossier Header */}
      <div className="relative bg-gradient-to-br from-slate-900 via-slate-950 to-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl overflow-hidden text-right">
        {/* Glow accent */}
        <div
          className="absolute top-0 left-0 w-64 h-64 rounded-full blur-3xl pointer-events-none opacity-20"
          style={{ backgroundColor: country.color }}
        />

        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-4">
          <div className="flex items-center gap-4">
            <span className="text-5xl sm:text-6xl select-none filter drop-shadow-md">{country.flag}</span>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs text-amber-400 font-bold bg-amber-500/10 border border-amber-500/20 px-2.5 py-0.5 rounded-full">
                  إقليم {country.region}
                </span>
                <span className="text-xs text-slate-400 font-mono">
                  {country.areaKm2.toLocaleString('ar-EG')} كم²
                </span>
              </div>
              <h2 className="text-2xl sm:text-4xl font-black text-white font-heading mt-1">
                {country.name}
              </h2>
              <div className="text-xs text-slate-400 mt-0.5">
                {country.officialName}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
            <button
              onClick={handleBookmarkToggle}
              className={`px-3.5 py-2 rounded-xl border text-xs font-bold transition-all flex items-center gap-1.5 ${
                isBookmarked
                  ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                  : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border-slate-700'
              }`}
              title={isBookmarked ? 'إزالة من المحفوظات' : 'حفظ الدولة في حسابك السحابي'}
            >
              <Bookmark className={`w-3.5 h-3.5 ${isBookmarked ? 'fill-amber-400 text-amber-400' : ''}`} />
              <span>{isBookmarked ? 'محفوظة ⭐' : 'حفظ'}</span>
            </button>

            <button
              onClick={handleShare}
              className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-bold transition-all flex items-center gap-1.5"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Share2 className="w-3.5 h-3.5" />}
              <span>{copied ? 'تم نسخ النبذة!' : 'مشاركة الدولة'}</span>
            </button>
          </div>
        </div>

        {/* Quick Summary */}
        <p className="text-sm sm:text-base text-slate-300 leading-relaxed max-w-3xl mb-6">
          {country.summary}
        </p>

        {/* Key Country Stat Strip */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
          <div className="bg-slate-950/80 border border-slate-800/80 p-3 rounded-2xl">
            <span className="text-[11px] text-slate-400 block mb-0.5">العاصمة الرسمية</span>
            <span className="text-sm font-bold text-white font-heading">{country.capital}</span>
          </div>
          <div className="bg-slate-950/80 border border-slate-800/80 p-3 rounded-2xl">
            <span className="text-[11px] text-slate-400 block mb-0.5">عدد السكان التقديري</span>
            <span className="text-sm font-bold text-emerald-400 font-mono">{country.population}</span>
          </div>
          <div className="bg-slate-950/80 border border-slate-800/80 p-3 rounded-2xl">
            <span className="text-[11px] text-slate-400 block mb-0.5">العملة الوطنية</span>
            <span className="text-sm font-bold text-amber-300 font-mono">{country.currency}</span>
          </div>
          <div className="bg-slate-950/80 border border-slate-800/80 p-3 rounded-2xl">
            <span className="text-[11px] text-slate-400 block mb-0.5">الأحداث الموثقة</span>
            <span className="text-sm font-bold text-sky-400 font-mono">{country.events.length} محطات تاريخية</span>
          </div>
        </div>
      </div>

      {/* Main Tab Navigation */}
      <div className="flex border-b border-slate-800 gap-2">
        <button
          onClick={() => {
            setActiveTab('timeline');
            playSound('click');
          }}
          className={`pb-3 px-4 text-xs sm:text-sm font-bold border-b-2 transition-all flex items-center gap-2 ${
            activeTab === 'timeline'
              ? 'border-amber-500 text-amber-400'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <Calendar className="w-4 h-4" />
          <span>الجدول الزمني للأحداث ({country.events.length})</span>
        </button>

        <button
          onClick={() => {
            setActiveTab('present');
            playSound('click');
          }}
          className={`pb-3 px-4 text-xs sm:text-sm font-bold border-b-2 transition-all flex items-center gap-2 ${
            activeTab === 'present'
              ? 'border-emerald-500 text-emerald-400'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <TrendingUp className="w-4 h-4" />
          <span>الحاضر والاقتصاد والرؤية المعاصرة</span>
        </button>

        <button
          onClick={() => {
            setActiveTab('heritage');
            playSound('click');
          }}
          className={`pb-3 px-4 text-xs sm:text-sm font-bold border-b-2 transition-all flex items-center gap-2 ${
            activeTab === 'heritage'
              ? 'border-purple-500 text-purple-400'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <Landmark className="w-4 h-4" />
          <span>الحضارات القديمة والمعالم ({country.landmarks.length})</span>
        </button>
      </div>

      {/* Tab 1: Timeline */}
      {activeTab === 'timeline' && (
        <CountryTimeline
          country={country}
          activeEra={activeEra}
          onSelectEra={onSelectEra}
        />
      )}

      {/* Tab 2: Present Day & Economic Vision */}
      {activeTab === 'present' && (
        <div className="space-y-6 animate-in fade-in">
          {/* Modern Vision Card */}
          <div className="bg-gradient-to-br from-emerald-950/20 via-slate-900 to-slate-950 border border-emerald-500/30 rounded-3xl p-6 text-right">
            <div className="flex items-center gap-2 text-emerald-400 font-bold text-xs mb-2">
              <TrendingUp className="w-4 h-4" />
              <span>الرؤية المعاصرة ومسار التنمية المستدامة</span>
            </div>
            <h3 className="text-xl font-black text-white font-heading mb-2">
              نهضة الحاضر وتطلعات المستقبل
            </h3>
            <p className="text-xs sm:text-sm text-slate-200 leading-relaxed">
              {country.modernVision}
            </p>
          </div>

          {/* Economic Pillars */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 text-right">
            <h4 className="text-base font-bold text-white font-heading mb-3 flex items-center gap-2">
              <Building2 className="w-4 h-4 text-amber-400" />
              <span>الركائز الاقتصادية والصناعية الأساسية:</span>
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {country.economicPillars.map((pillar, idx) => (
                <div
                  key={idx}
                  className="p-3.5 bg-slate-950/80 border border-slate-800 rounded-xl flex items-center gap-3"
                >
                  <div className="w-6 h-6 rounded-lg bg-amber-500/20 text-amber-300 border border-amber-500/30 flex items-center justify-center text-xs font-black shrink-0">
                    {idx + 1}
                  </div>
                  <span className="text-xs sm:text-sm text-slate-200 font-medium">
                    {pillar}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Tab 3: Ancient Civilizations & Landmarks */}
      {activeTab === 'heritage' && (
        <div className="space-y-6 animate-in fade-in">
          {/* Civilizations Roots */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 text-right">
            <h4 className="text-base font-bold text-white font-heading mb-2 flex items-center gap-2">
              <Layers className="w-4 h-4 text-purple-400" />
              <span>الحضارات والممالك التي قامت على هذه الأرض:</span>
            </h4>
            <p className="text-xs text-slate-400 mb-4">
              تاريخ ضارب في القدم يعود لآلاف السنين قبل الميلاد.
            </p>

            <div className="flex flex-wrap gap-2">
              {country.ancientCivilizations.map((civ, idx) => (
                <span
                  key={idx}
                  className="px-3.5 py-1.5 rounded-xl bg-purple-500/10 border border-purple-500/30 text-purple-300 text-xs font-bold font-heading"
                >
                  🏛️ {civ}
                </span>
              ))}
            </div>
          </div>

          {/* Key Landmarks Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {country.landmarks.map((lm, idx) => (
              <div
                key={idx}
                className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 text-right flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[10px] text-amber-400 font-mono bg-amber-500/10 border border-amber-500/20 px-2 py-0.5 rounded-md">
                      {lm.type}
                    </span>
                    <span className="text-xs text-slate-400 font-mono">{lm.period}</span>
                  </div>
                  <h5 className="text-base font-bold text-white font-heading mb-1">{lm.name}</h5>
                  <p className="text-xs text-slate-300 leading-relaxed mt-1">
                    {lm.description}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
