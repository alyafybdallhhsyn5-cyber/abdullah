import React, { useState, useEffect } from 'react';
import { playSound } from '../utils/audio';
import { Smartphone, Download, Check, Copy, ExternalLink, ShieldCheck, Sparkles, X, ChevronLeft, Chrome, Layers, DollarSign, Globe, FileArchive } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
}

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed'; platform: string }>;
}

export const InstallAppModal: React.FC<Props> = ({ isOpen, onClose }) => {
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [isCopied, setIsCopied] = useState(false);
  const [activeTab, setActiveTab] = useState<'pwa' | 'apk' | 'domain' | 'playstore' | 'zip'>('zip');

  const appUrl = window.location.href;

  useEffect(() => {
    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    };
  }, []);

  if (!isOpen) return null;

  const handleInstallClick = async () => {
    playSound('coin');
    if (deferredPrompt) {
      await deferredPrompt.prompt();
      const choice = await deferredPrompt.userChoice;
      if (choice.outcome === 'accepted') {
        setDeferredPrompt(null);
      }
    } else {
      alert('لتثبيت التطبيق على هاتف أندرويد:\n1. اضغط على النقاط الثلاث (⋮) في أعلى متصفح Chrome.\n2. اختر "تثبيت التطبيق" أو "إضافة إلى الشاشة الرئيسية".');
    }
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(appUrl);
    setIsCopied(true);
    playSound('success');
    setTimeout(() => setIsCopied(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-fadeIn" dir="rtl">
      <div className="relative w-full max-w-2xl bg-slate-900 border border-amber-500/40 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-5 sm:p-6 bg-gradient-to-r from-amber-950/40 via-slate-900 to-indigo-950/40 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg sm:text-xl font-black text-white font-heading">
                تحويل وتثبيت التطبيق على هاتف Android 📱
              </h3>
              <p className="text-xs text-slate-400">
                دليل خطوة بخطوة ومبسط للمبتدئين بدون الحاجة لخبرة برمجية
              </p>
            </div>
          </div>
          <button
            onClick={() => {
              playSound('click');
              onClose();
            }}
            className="p-2 rounded-xl bg-slate-800 text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center border-b border-slate-800 bg-slate-950/50 p-2 gap-1.5 text-xs font-bold overflow-x-auto scrollbar-none">
          <button
            onClick={() => {
              setActiveTab('pwa');
              playSound('click');
            }}
            className={`whitespace-nowrap py-2 px-2.5 rounded-xl transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'pwa'
                ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Chrome className="w-3.5 h-3.5" />
            <span>1. تثبيت PWA</span>
          </button>

          <button
            onClick={() => {
              setActiveTab('apk');
              playSound('click');
            }}
            className={`whitespace-nowrap py-2 px-2.5 rounded-xl transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'apk'
                ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Download className="w-3.5 h-3.5" />
            <span>2. تطبيق APK</span>
          </button>

          <button
            onClick={() => {
              setActiveTab('domain');
              playSound('click');
            }}
            className={`whitespace-nowrap py-2 px-2.5 rounded-xl transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'domain'
                ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20 font-black'
                : 'text-cyan-400 hover:text-cyan-300'
            }`}
          >
            <Globe className="w-3.5 h-3.5" />
            <span>3. موقع ودومين (.com)</span>
          </button>

          <button
            onClick={() => {
              setActiveTab('playstore');
              playSound('click');
            }}
            className={`whitespace-nowrap py-2 px-2.5 rounded-xl transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'playstore'
                ? 'bg-amber-500 text-slate-950 shadow-md shadow-amber-500/20'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>4. Google Play</span>
          </button>

          <button
            onClick={() => {
              setActiveTab('zip');
              playSound('click');
            }}
            className={`whitespace-nowrap py-2 px-2.5 rounded-xl transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'zip'
                ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20 font-black'
                : 'text-emerald-400 hover:text-emerald-300'
            }`}
          >
            <FileArchive className="w-3.5 h-3.5" />
            <span>5. تنزيل المشروع الكامل (ZIP 💾)</span>
          </button>
        </div>

        {/* Tab Content (Scrollable) */}
        <div className="p-5 sm:p-6 space-y-6 overflow-y-auto font-body text-right">
          {/* TAB 1: PWA Instant Install */}
          {activeTab === 'pwa' && (
            <div className="space-y-4 animate-fadeIn">
              <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 space-y-2">
                <span className="text-xs font-black text-amber-400 inline-block">
                  ⚡ الطريقة الأسرع والمجانية 100% (تستغرق 10 ثوانٍ فقط):
                </span>
                <p className="text-xs text-slate-200 leading-relaxed">
                  تمت برمجة هذا المشروع كـ <strong>تطبيق ويب تقدمي (PWA)</strong> معتمد، مما يعني أنه يمكنك تثبيته مباشرة كـ تطبيق حقيقي على شاشة هاتف Android الخاص بك بدون أي متجر، وسيفتح بكامل الشاشة وبأيقونة التطبيق الذهبية الخاصة!
                </p>
              </div>

              {/* Step by step for Android */}
              <div className="space-y-3">
                <h4 className="text-sm font-bold text-white flex items-center gap-2">
                  <span className="w-6 h-6 rounded-full bg-slate-800 text-amber-400 flex items-center justify-center text-xs">١</span>
                  <span>خطوات التثبيت من متصفح هاتف Android (Chrome):</span>
                </h4>

                <div className="grid grid-cols-1 gap-2.5 text-xs text-slate-300">
                  <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800 flex items-start gap-3">
                    <span className="w-5 h-5 rounded-md bg-amber-500/20 text-amber-400 font-bold flex items-center justify-center shrink-0 mt-0.5">1</span>
                    <div>
                      <strong className="text-white block mb-0.5">افتح رابط التطبيق في متصفح Chrome</strong>
                      <span>انسخ رابط التطبيق بالأسفل وافتحه من متصفح جوجل كروم على هاتفك.</span>
                    </div>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800 flex items-start gap-3">
                    <span className="w-5 h-5 rounded-md bg-amber-500/20 text-amber-400 font-bold flex items-center justify-center shrink-0 mt-0.5">2</span>
                    <div>
                      <strong className="text-white block mb-0.5">اضغط على زر الخيارات (⋮)</strong>
                      <span>اضغط على الثلاث نقاط الرأسية في الزاوية العلوية لمتصفح Chrome.</span>
                    </div>
                  </div>

                  <div className="p-3 rounded-xl bg-slate-950/70 border border-slate-800 flex items-start gap-3">
                    <span className="w-5 h-5 rounded-md bg-amber-500/20 text-amber-400 font-bold flex items-center justify-center shrink-0 mt-0.5">3</span>
                    <div>
                      <strong className="text-white block mb-0.5">اختر «تثبيت التطبيق» أو «إضافة إلى الشاشة الرئيسية»</strong>
                      <span>اضغط على "Install App" وسيتم تنزيله فوراً كأي تطبيق عادي في هاتفك!</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Install Action Button */}
              <div className="pt-2">
                <button
                  onClick={handleInstallClick}
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-black text-sm transition-all shadow-lg shadow-amber-500/20 flex items-center justify-center gap-2"
                >
                  <Download className="w-4 h-4" />
                  <span>اضغط هنا لتثبيت التطبيق على جهازك الآن</span>
                </button>
              </div>
            </div>
          )}

          {/* TAB 2: Export APK */}
          {activeTab === 'apk' && (
            <div className="space-y-4 animate-fadeIn">
              {/* Feature Highlights: Offline & Online + Custom Name & Icon */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-start gap-2.5">
                  <div className="w-7 h-7 rounded-lg bg-amber-500/20 text-amber-400 font-bold flex items-center justify-center shrink-0">
                    📶
                  </div>
                  <div>
                    <strong className="text-amber-300 block mb-0.5">يعمل بدون إنترنت (100% Offline):</strong>
                    <span className="text-slate-300 text-[11px] leading-relaxed">
                      جميع الخرائط، صفحات الدول، الحروب، والاختبارات مخزنة محلياً في الـ APK عبر تقنية Service Worker و Local-First.
                    </span>
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-start gap-2.5">
                  <div className="w-7 h-7 rounded-lg bg-cyan-500/20 text-cyan-400 font-bold flex items-center justify-center shrink-0">
                    🌐
                  </div>
                  <div>
                    <strong className="text-cyan-300 block mb-0.5">ويعمل بالإنترنت (Online Sync):</strong>
                    <span className="text-slate-300 text-[11px] leading-relaxed">
                      عند توفر الشبكة، يتصل بقاعدة البيانات السحابية لمزامنة درجات مسابقة المؤرخين والمفضلة.
                    </span>
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-purple-500/10 border border-purple-500/30 flex items-start gap-2.5">
                  <div className="w-7 h-7 rounded-lg bg-purple-500/20 text-purple-400 font-bold flex items-center justify-center shrink-0">
                    🏷️
                  </div>
                  <div>
                    <strong className="text-purple-300 block mb-0.5">اسم التطبيق المعتمد:</strong>
                    <span className="text-slate-300 text-[11px] leading-relaxed">
                      "موسوعة تاريخ الشرق الأوسط" مدمج في ملفات التكوين (manifest & capacitor).
                    </span>
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-start gap-2.5">
                  <div className="w-7 h-7 rounded-lg bg-emerald-500/20 text-emerald-400 font-bold flex items-center justify-center shrink-0">
                    ⭐
                  </div>
                  <div>
                    <strong className="text-emerald-300 block mb-0.5">الأيقونة الملكية الذهبية:</strong>
                    <span className="text-slate-300 text-[11px] leading-relaxed">
                      شعار الإسطرلاب والنجمة الإسلامية الذهبية بصيغتي SVG و PNG (192px / 512px).
                    </span>
                  </div>
                </div>
              </div>

              {/* Method 1: PWABuilder (Instant No-Code Cloud) */}
              <div className="p-4 rounded-2xl bg-indigo-950/40 border border-indigo-500/40 space-y-3">
                <div className="flex items-center justify-between">
                  <h5 className="text-xs font-black text-indigo-400 flex items-center gap-1.5">
                    <span className="w-5 h-5 rounded-full bg-indigo-500/20 flex items-center justify-center text-xs">١</span>
                    <span>الطريقة الأولى: توليد APK سحابي بضغطة زر واحدة (بدون برامج):</span>
                  </h5>
                  <span className="text-[10px] bg-indigo-500/20 text-indigo-300 px-2 py-0.5 rounded-full font-bold">
                    الأسهل للمبتدئين
                  </span>
                </div>

                <div className="space-y-2 text-xs text-slate-300">
                  <div className="flex items-center gap-2">
                    <input
                      type="text"
                      readOnly
                      value={appUrl}
                      className="bg-slate-900 text-slate-300 px-3 py-1.5 rounded-lg border border-slate-700 text-xs flex-1 font-mono text-left"
                    />
                    <button
                      onClick={handleCopyLink}
                      className="px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shrink-0 flex items-center gap-1"
                    >
                      {isCopied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{isCopied ? 'تم النسخ!' : 'نسخ الرابط'}</span>
                    </button>
                  </div>

                  <p className="text-[11px] text-slate-300 leading-relaxed">
                    1. ادخل إلى موقع <a href="https://www.pwabuilder.com" target="_blank" rel="noopener noreferrer" className="text-amber-400 underline font-bold">PWABuilder.com</a> أو موقع <a href="https://web2application.com" target="_blank" rel="noopener noreferrer" className="text-amber-400 underline font-bold">Web2Application</a>.<br/>
                    2. الصق رابط تطبيقك واضغط <strong>Start</strong>.<br/>
                    3. اختر <strong>Package for Android</strong> وحمل ملف الـ <strong>APK</strong> وثبته في هاتفك فوراً!
                  </p>
                </div>
              </div>

              {/* Method 2: Capacitor / Android Studio (100% Offline Native App) */}
              <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <h5 className="text-xs font-black text-amber-400 flex items-center gap-1.5">
                    <span className="w-5 h-5 rounded-full bg-amber-500/20 flex items-center justify-center text-xs">٢</span>
                    <span>الطريقة الثانية: تحويل الكود إلى تطبيق أندرويد أصلي (Capacitor):</span>
                  </h5>
                  <span className="text-[10px] bg-amber-500/20 text-amber-300 px-2 py-0.5 rounded-full font-bold">
                    أوفلاين 100% دائم
                  </span>
                </div>

                <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 font-mono text-[11px] text-slate-300 space-y-1 text-left" dir="ltr">
                  <div className="text-slate-400"># 1. فك ضغط ملف ZIP المشروع وافتح موجه الأوامر (Terminal):</div>
                  <div className="text-amber-400 font-bold">npm install</div>
                  <div className="text-slate-400"># 2. بناء ملفات الموقع الثابتة:</div>
                  <div className="text-amber-400 font-bold">npm run build</div>
                  <div className="text-slate-400"># 3. تثبيت إطار أندرويد ودمج الملفات:</div>
                  <div className="text-amber-400 font-bold">npm install @capacitor/core @capacitor/cli @capacitor/android</div>
                  <div className="text-amber-400 font-bold">npx cap add android</div>
                  <div className="text-amber-400 font-bold">npx cap sync</div>
                  <div className="text-slate-400"># 4. فتح المشروع في Android Studio واستخراج ملف APK:</div>
                  <div className="text-emerald-400 font-bold">npx cap open android</div>
                </div>
                <p className="text-[11px] text-slate-400 leading-relaxed">
                  في Android Studio: اضغط على <strong>Build &gt; Build Bundle(s) / APK(s) &gt; Build APK(s)</strong> وستحصل على ملف <strong>app-debug.apk</strong> جاهز للتثبيت على أي هاتف في العالم دون الحاجة لمتجر!
                </p>
              </div>

              {/* Method 3: Website2APK Builder (Windows desktop app) */}
              <div className="p-4 rounded-2xl bg-slate-950/70 border border-slate-800 space-y-2 text-xs">
                <h5 className="font-bold text-slate-200 flex items-center gap-1.5">
                  <span className="w-5 h-5 rounded-full bg-slate-800 flex items-center justify-center text-xs">٣</span>
                  <span>الطريقة الثالثة: برنامج Website 2 APK Builder المباشر (للكمبيوتر):</span>
                </h5>
                <p className="text-[11px] text-slate-400 leading-relaxed">
                  إذا كنت تستخدم نظام Windows، حمل برنامج <strong>Website 2 APK Builder</strong> المجاني، اختر خيار <strong>Local Website Folder</strong> وحدد مجلد <strong>dist</strong>، اكتب اسم التطبيق: "موسوعة تاريخ الشرق الأوسط"، اختر أيقونة التطبيق، واضغط <strong>Generate APK</strong> لإنشاء الملف فوراً بدون سطر كود واحد!
                </p>
              </div>
            </div>
          )}

          {/* TAB 3: Domain & Free Hosting Setup */}
          {activeTab === 'domain' && (
            <div className="space-y-4 animate-fadeIn">
              {/* Free Options Banner */}
              <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 space-y-2">
                <span className="text-xs font-black text-emerald-400 inline-block flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4" />
                  <span>🎉 نعم! توجد طرق مجانية 100% مدى الحياة بدون دفع أي فلس أو دولار:</span>
                </span>
                <p className="text-xs text-slate-200 leading-relaxed">
                  إذا كنت لا ترغب في دفع أي رسوم لشراء نطاق <code className="text-amber-300 font-mono">.com</code>، يمكنك نشر وتشغيل موقعك برابط رسمي مخصص مجاني مدى الحياة عبر أفضل المنصات العالمية:
                </p>
              </div>

              {/* Free Methods List */}
              <div className="space-y-2.5 text-xs">
                {/* Free Option 1: Existing Google Cloud Run Link */}
                <div className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800 flex items-start gap-3">
                  <span className="w-6 h-6 rounded-lg bg-emerald-500/20 text-emerald-400 font-bold flex items-center justify-center shrink-0">1</span>
                  <div className="space-y-1 flex-1">
                    <strong className="text-emerald-300 block">رابط تطبيقك الحالي (مستضاف على سيرفرات Google مجاناً 100%):</strong>
                    <p className="text-slate-300 text-[11px] leading-relaxed">
                      هذا الرابط يعمل الآن ومجاني 24/7 دون أي اشتراك أو تكلفة، يمكنك نسخه ومشاركته فوراً مع أصدقائك أو نشره في حساباتك:
                    </p>
                    <div className="flex items-center gap-2 pt-1">
                      <input
                        type="text"
                        readOnly
                        value={appUrl}
                        className="bg-slate-900 text-slate-300 px-3 py-1.5 rounded-lg border border-slate-700 text-xs flex-1 font-mono text-left"
                      />
                      <button
                        onClick={handleCopyLink}
                        className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shrink-0 flex items-center gap-1"
                      >
                        {isCopied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                        <span>{isCopied ? 'تم النسخ!' : 'نسخ'}</span>
                      </button>
                    </div>
                  </div>
                </div>

                {/* Free Option 2: Vercel Free Custom Subdomain */}
                <div className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800 flex items-start gap-3">
                  <span className="w-6 h-6 rounded-lg bg-cyan-500/20 text-cyan-400 font-bold flex items-center justify-center shrink-0">2</span>
                  <div className="space-y-1 flex-1">
                    <strong className="text-cyan-300 block">نطاق مخصص مجاني على Vercel (ينتهي بـ .vercel.app):</strong>
                    <p className="text-slate-300 text-[11px] leading-relaxed">
                      يمكنك اختيار اسم مجاني لموقعك بالكامل بدون شراء دومين، مثلاً:
                      <span className="text-amber-400 font-mono block pt-0.5" dir="ltr">https://arab-history.vercel.app</span>
                      أو <span className="text-amber-400 font-mono" dir="ltr">https://mideast-encyclopedia.vercel.app</span>
                      فقط ارفع كود المشروع (ZIP) على <a href="https://vercel.com" target="_blank" rel="noopener noreferrer" className="text-cyan-400 underline font-bold">Vercel.com</a> مجاناً وسينشئ لك الرابط في دقيقة واحدة!
                    </p>
                  </div>
                </div>

                {/* Free Option 3: Netlify & GitHub Pages */}
                <div className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800 flex items-start gap-3">
                  <span className="w-6 h-6 rounded-lg bg-purple-500/20 text-purple-400 font-bold flex items-center justify-center shrink-0">3</span>
                  <div className="space-y-1 flex-1">
                    <strong className="text-purple-300 block">منصات Netlify أو GitHub Pages (مجانية من مايكروسوفت):</strong>
                    <p className="text-slate-300 text-[11px] leading-relaxed">
                      تمنحك استضافة سريعة ونطاقاً مجانياً مدى الحياة مثل:
                      <span className="text-amber-400 font-mono block pt-0.5" dir="ltr">https://mideast-history.netlify.app</span>
                    </p>
                  </div>
                </div>
              </div>

              {/* Paid .com Comparison Card */}
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
                <h5 className="font-bold text-amber-400 text-xs flex items-center gap-1.5">
                  <Globe className="w-4 h-4" />
                  <span>متى تحتاج لدفع رسوم؟ (فقط إذا أردت دومين .com خاص بك حصرياً):</span>
                </h5>
                <p className="text-[11px] text-slate-300 leading-relaxed">
                  الاستضافة نفسها والسيرفرات مجانية 100%. التكلفة الوحيدة (حوالي 8$ إلى 10$ سنوياً) تدفع لشركات تسجيل الدومين العالمية فقط إذا أردت أن يكون الرابط بدون كلمة vercel أو netlify، أي مثل: <span className="text-cyan-300 font-mono" dir="ltr">www.yourname.com</span>. وإذا لم ترد ذلك، فإن الخيارات المجانية أعلاه كافية جداً وتعمل مدى الحياة!
                </p>
              </div>
            </div>
          )}

          {/* TAB 3: Google Play Store & Cost breakdown */}
          {activeTab === 'playstore' && (
            <div className="space-y-4 animate-fadeIn">
              <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 space-y-2">
                <span className="text-xs font-black text-emerald-400 inline-block">
                  🌟 النشر على متجر Google Play الرسمي:
                </span>
                <p className="text-xs text-slate-200 leading-relaxed">
                  يمكن رفع التطبيق على متجر جوجل بلاي الرسمي ليكون متاحاً للتحميل لملايين المستخدمين حول العالم باستخدام حزمة الـ <strong>.AAB</strong> التي ينشئها لك موقع PWABuilder أو إطار عمل Capacitor.
                </p>
              </div>

              {/* Pricing & Fees Breakdown */}
              <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3">
                <h5 className="text-xs font-black text-amber-400 flex items-center gap-1.5">
                  <DollarSign className="w-4 h-4" />
                  <span>توضيح التكاليف والاشتراكات (شفافية كاملة للمبتدئ):</span>
                </h5>

                <div className="space-y-2 text-xs text-slate-300">
                  <div className="flex items-center justify-between p-2 rounded-lg bg-slate-900/60 border border-slate-800">
                    <span className="font-semibold text-white">تشغيل وتجربة التطبيق وتثبيته (PWA):</span>
                    <span className="text-emerald-400 font-bold">مجاني 100% وبدون أي رسوم</span>
                  </div>

                  <div className="flex items-center justify-between p-2 rounded-lg bg-slate-900/60 border border-slate-800">
                    <span className="font-semibold text-white">تصدير ملف الـ APK عبر PWABuilder:</span>
                    <span className="text-emerald-400 font-bold">مجاني 100%</span>
                  </div>

                  <div className="flex items-center justify-between p-2 rounded-lg bg-slate-900/60 border border-slate-800">
                    <span className="font-semibold text-white">حساب مطور Google Play Console (اختياري):</span>
                    <span className="text-amber-400 font-bold">25 دولار (تدفع لمرة واحدة فقط لشركة جوجل مدى الحياة)</span>
                  </div>

                  <div className="flex items-center justify-between p-2 rounded-lg bg-slate-900/60 border border-slate-800">
                    <span className="font-semibold text-white">هل يوجد أي اشتراك شهري أو دوري؟</span>
                    <span className="text-cyan-400 font-bold">لا يوجد أي اشتراك إطلاقاً!</span>
                  </div>
                </div>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800 text-xs text-slate-300 flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0" />
                <span>التطبيق خفيف وسريع ولا يحتاج لقواعد بيانات معقدة أو خوادم باهظة التكلفة.</span>
              </div>
            </div>
          )}

          {/* TAB 5: Download Complete Project ZIP (Android Native + Web) */}
          {activeTab === 'zip' && (
            <div className="space-y-4 animate-fadeIn">
              <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 space-y-2">
                <span className="text-xs font-black text-emerald-400 inline-block flex items-center gap-1.5">
                  <FileArchive className="w-4 h-4" />
                  <span>💾 تصدير المشروع بالكامل مع تطبيق Android الأصلي (ملف ZIP حقيقي):</span>
                </span>
                <p className="text-xs text-slate-200 leading-relaxed">
                  تم ضغط المشروع بالكامل في ملف ZIP حقيقي بمساحة <strong>456 كيلوبايت</strong> يحتوي على <strong>110 ملفات</strong>، شاملاً مجلد الأندرويد الأصلي بجميع أكواد Kotlin و Jetpack Compose، ملفات Gradle، قاعدة بيانات Room المحلية، والبيانات الأصلية.
                </p>
              </div>

              {/* Direct Download Card */}
              <div className="p-5 rounded-2xl bg-slate-950 border border-emerald-500/40 space-y-4 shadow-xl">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400 font-black text-base">
                      ZIP
                    </div>
                    <div>
                      <h4 className="text-sm font-black text-white font-heading">
                        mideast-history-complete-project.zip
                      </h4>
                      <p className="text-xs text-slate-400">
                        110 ملفات • الحجم: 456 KB • كود أندرويد الأصلي + الويب + قاعدة بيانات Room
                      </p>
                    </div>
                  </div>
                  <span className="px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-400 font-bold text-xs">
                    جاهز للتحميل
                  </span>
                </div>

                <a
                  href="/mideast-history-complete-project.zip"
                  download="mideast-history-complete-project.zip"
                  onClick={() => playSound('success')}
                  className="w-full py-3.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-sm transition-all shadow-lg shadow-emerald-500/20 flex items-center justify-center gap-2"
                >
                  <Download className="w-4 h-4" />
                  <span>اضغط هنا لتحميل ملف الـ ZIP مباشرة (تحميل فوري)</span>
                </a>
              </div>

              {/* Verified Contents Checklist */}
              <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 space-y-2.5 text-xs text-slate-300">
                <h5 className="font-bold text-amber-400 text-xs">محتويات الملف المضغوط المُحققة:</h5>
                <ul className="space-y-1.5 list-disc list-inside text-slate-300 text-[11px] leading-relaxed">
                  <li><strong>android/ :</strong> مجلد الأندرويد الأصلي كاملاً مع ملفات Kotlin و Jetpack Compose و Material 3.</li>
                  <li><strong>ملفات Gradle :</strong> build.gradle.kts و settings.gradle.kts و gradle.properties جاهزة للبناء.</li>
                  <li><strong>قاعدة بيانات Room :</strong> ملفات AppDatabase و DAOs و Entities للعمل بدون إنترنت 100%.</li>
                  <li><strong>الأيقونات والموارد :</strong> أيقونات التطبيق بدقة عالية داخل مجلدات mipmap المتعددة و icon.svg.</li>
                  <li><strong>src/data/ :</strong> كافة بيانات موسوعة دول الشرق الأوسط الـ 15+ وتاريخ الحروب والعلاقات.</li>
                  <li><strong>ملفات النشر :</strong> capacitor.config.json و vercel.json و netlify.toml للتشغيل السحابي والمحلي.</li>
                </ul>
              </div>

              {/* Quick Android Studio Guide */}
              <div className="p-3.5 rounded-xl bg-slate-900/70 border border-slate-800 text-xs text-slate-400 space-y-1 leading-relaxed">
                <strong className="text-white block">خطوات بناء APK في Android Studio:</strong>
                <span>1. فك ضغط ملف الـ ZIP.</span><br />
                <span>2. افتح برنامج <strong>Android Studio</strong> واختر مجلد <strong>android</strong>.</span><br />
                <span>3. اضغط من القائمة العلوية: <strong>Build &gt; Build Bundle(s) / APK(s) &gt; Build APK(s)</strong>.</span>
              </div>
            </div>
          )}



          {/* Quick Copy Link Box */}
          <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
            <span className="text-xs text-slate-400 block font-semibold">رابط التطبيق الخاص بك للمشاركة والتثبيت:</span>
            <div className="flex items-center gap-2">
              <input
                type="text"
                readOnly
                value={appUrl}
                className="bg-slate-900 border border-slate-700/80 rounded-xl px-3 py-2 text-xs text-amber-300 flex-1 font-mono text-left focus:outline-none"
              />
              <button
                onClick={handleCopyLink}
                className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shrink-0 flex items-center gap-1.5 transition-colors"
              >
                {isCopied ? <Check className="w-4 h-4 text-emerald-950" /> : <Copy className="w-4 h-4" />}
                <span>{isCopied ? 'تم النسخ بنجاح!' : 'نسخ الرابط'}</span>
              </button>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-950/80 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
          <span>تصميم وتطوير: عبدالله حسين (@n.0a21)</span>
          <button
            onClick={() => {
              playSound('click');
              onClose();
            }}
            className="px-4 py-1.5 rounded-lg bg-slate-800 text-white hover:bg-slate-700 font-semibold"
          >
            إغلاق النافذة
          </button>
        </div>
      </div>
    </div>
  );
};
