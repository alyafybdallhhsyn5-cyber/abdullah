import React, { useState } from 'react';
import { Country, EraType, HistoricalEvent } from '../types/history';
import { playSound } from '../utils/audio';
import { Calendar, ChevronDown, ChevronUp, MapPin, Users, Award, Sparkles, Filter } from 'lucide-react';

interface Props {
  country: Country;
  activeEra: EraType;
  onSelectEra: (era: EraType) => void;
}

export const CountryTimeline: React.FC<Props> = ({ country, activeEra, onSelectEra }) => {
  const [expandedEventId, setExpandedEventId] = useState<string | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  const toggleExpand = (id: string) => {
    setExpandedEventId((curr) => (curr === id ? null : id));
    playSound('click');
  };

  // Filter events by Era and Category
  const filteredEvents = country.events.filter((e) => {
    const matchEra = activeEra === 'all' || e.era === activeEra;
    const matchCat = selectedCategory === 'all' || e.category === selectedCategory;
    return matchEra && matchCat;
  });

  const categories = Array.from(new Set(country.events.map((e) => e.category)));

  return (
    <div className="space-y-6">
      {/* Timeline Controls & Filter Bar */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 flex flex-col sm:flex-row items-center justify-between gap-3">
        {/* Category Filters */}
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar w-full sm:w-auto pb-1 sm:pb-0">
          <span className="text-xs text-slate-400 font-semibold shrink-0 flex items-center gap-1">
            <Filter className="w-3.5 h-3.5" />
            <span>التصنيف:</span>
          </span>
          <button
            onClick={() => setSelectedCategory('all')}
            className={`px-2.5 py-1 rounded-lg text-xs font-semibold shrink-0 transition-colors ${
              selectedCategory === 'all'
                ? 'bg-amber-500 text-slate-950 font-bold'
                : 'bg-slate-950 text-slate-400 hover:text-white'
            }`}
          >
            الكل ({country.events.length})
          </button>
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-2.5 py-1 rounded-lg text-xs font-semibold shrink-0 transition-colors ${
                selectedCategory === cat
                  ? 'bg-amber-500 text-slate-950 font-bold'
                  : 'bg-slate-950 text-slate-400 hover:text-white'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Count summary */}
        <div className="text-xs text-slate-400 font-mono self-end sm:self-center shrink-0">
          عرض <span className="text-amber-400 font-bold">{filteredEvents.length}</span> من أصل {country.events.length} محطة
        </div>
      </div>

      {/* Vertical Interactive Timeline */}
      <div className="relative border-r-2 border-amber-500/30 pr-6 mr-3 space-y-6">
        {filteredEvents.map((event, idx) => {
          const isExpanded = expandedEventId === event.id;

          const eraColor =
            event.era === 'ancient'
              ? 'text-amber-400 border-amber-500/40 bg-amber-500/10'
              : event.era === 'islamic'
              ? 'text-emerald-400 border-emerald-500/40 bg-emerald-500/10'
              : event.era === 'modern'
              ? 'text-sky-400 border-sky-500/40 bg-sky-500/10'
              : 'text-purple-400 border-purple-500/40 bg-purple-500/10';

          const eraLabel =
            event.era === 'ancient'
              ? 'العصر القديم'
              : event.era === 'islamic'
              ? 'العصر الإسلامي'
              : event.era === 'modern'
              ? 'التاريخ الحديث'
              : 'الحاضر والمعاصر';

          return (
            <div key={event.id} className="relative group animate-in fade-in">
              {/* Timeline Golden Node Dot */}
              <div
                className="absolute -right-[31px] top-4 w-4 h-4 rounded-full bg-slate-950 border-2 border-amber-500 flex items-center justify-center shadow-md shadow-amber-500/30 group-hover:scale-125 transition-transform"
              >
                <div className="w-1.5 h-1.5 rounded-full bg-amber-400" />
              </div>

              {/* Event Card */}
              <div
                onClick={() => toggleExpand(event.id)}
                className={`p-5 rounded-2xl border transition-all cursor-pointer text-right ${
                  isExpanded
                    ? 'bg-slate-900 border-amber-500/50 shadow-xl shadow-amber-500/10'
                    : 'bg-slate-950/80 border-slate-800 hover:border-slate-700'
                }`}
              >
                {/* Event Header Meta */}
                <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs font-black text-amber-300 bg-amber-500/15 border border-amber-500/30 px-2.5 py-0.5 rounded-md">
                      {event.year}
                    </span>
                    {event.exactDate && (
                      <span className="text-[11px] text-slate-400 font-mono">
                        ({event.exactDate})
                      </span>
                    )}
                  </div>

                  <div className="flex items-center gap-2">
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md border ${eraColor}`}>
                      {eraLabel}
                    </span>
                    <span className="text-[11px] text-slate-400 bg-slate-900 px-2 py-0.5 rounded-md border border-slate-800">
                      {event.category}
                    </span>
                  </div>
                </div>

                {/* Event Title */}
                <h4 className="text-base sm:text-lg font-black text-white font-heading mt-1 mb-2 leading-relaxed">
                  {event.title}
                </h4>

                {/* Event Summary Description */}
                <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                  {event.description}
                </p>

                {/* Historical Impact Callout */}
                <div className="mt-3 p-3 bg-amber-500/5 border border-amber-500/20 rounded-xl text-xs text-amber-200/90 leading-relaxed flex items-start gap-2">
                  <Award className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                  <div>
                    <strong className="text-amber-300">الأثر التاريخي: </strong>
                    <span>{event.impact}</span>
                  </div>
                </div>

                {/* Expanded Details Panel */}
                {isExpanded && (
                  <div className="mt-4 pt-4 border-t border-slate-800 space-y-3 animate-in slide-in-from-top-2">
                    {event.keyFigures && event.keyFigures.length > 0 && (
                      <div className="flex items-center gap-2 text-xs">
                        <Users className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                        <span className="text-slate-400">شخصيات بارزة:</span>
                        <div className="flex flex-wrap gap-1">
                          {event.keyFigures.map((fig, fIdx) => (
                            <span key={fIdx} className="bg-slate-800 text-slate-200 px-2 py-0.5 rounded text-[11px] font-semibold">
                              {fig}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}

                    {event.location && (
                      <div className="flex items-center gap-2 text-xs text-slate-400">
                        <MapPin className="w-3.5 h-3.5 text-rose-400 shrink-0" />
                        <span>الموقع الجغرافي:</span>
                        <span className="text-slate-200 font-medium">{event.location}</span>
                      </div>
                    )}
                  </div>
                )}

                {/* Expand / Collapse Indicator */}
                <div className="mt-3 flex items-center justify-end text-[11px] text-slate-400 gap-1 font-semibold">
                  <span>{isExpanded ? 'طي التفاصيل' : 'قراءة المزيد من التفاصيل'}</span>
                  {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                </div>
              </div>
            </div>
          );
        })}

        {filteredEvents.length === 0 && (
          <div className="text-center py-12 text-slate-400 bg-slate-900/40 rounded-2xl border border-dashed border-slate-800 p-6">
            لا توجد أحداث مطابقة في هذا التصنيف أو العصر المحدد. اختر "كافة العصور" أو غير الفلتر.
          </div>
        )}
      </div>
    </div>
  );
};
