import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext.tsx';
import { X, LogOut, Bookmark, Award, Trash2, Calendar, User as UserIcon } from 'lucide-react';
import { playSound } from '../utils/audio.ts';

interface Props {
  isOpen: boolean;
  onClose: () => void;
}

export const UserProfileModal: React.FC<Props> = ({ isOpen, onClose }) => {
  const { user, signOutUser, bookmarks, removeBookmark, quizScores } = useAuth();
  const [activeTab, setActiveTab] = useState<'bookmarks' | 'scores'>('bookmarks');

  if (!isOpen || !user) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in">
      <div className="bg-slate-900 border border-slate-800 rounded-3xl w-full max-w-lg overflow-hidden shadow-2xl text-right">
        {/* Header */}
        <div className="p-6 border-b border-slate-800 flex items-center justify-between">
          <button
            onClick={() => {
              playSound('click');
              onClose();
            }}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-3">
            <div>
              <h3 className="font-bold text-white text-base">حسابي السحابي</h3>
              <p className="text-xs text-slate-400">مزامنة البيانات الآمنة</p>
            </div>
            {user.photoURL ? (
              <img
                src={user.photoURL}
                alt={user.displayName || 'User'}
                className="w-10 h-10 rounded-full border border-amber-500/40"
              />
            ) : (
              <div className="w-10 h-10 rounded-full bg-amber-500/20 text-amber-300 flex items-center justify-center border border-amber-500/30">
                <UserIcon className="w-5 h-5" />
              </div>
            )}
          </div>
        </div>

        {/* User Details */}
        <div className="px-6 py-4 bg-slate-950/50 border-b border-slate-800/80 flex items-center justify-between">
          <button
            onClick={async () => {
              playSound('click');
              await signOutUser();
              onClose();
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-red-500/10 hover:bg-red-500/20 border border-red-500/30 text-red-400 text-xs font-bold transition-colors"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>تسجيل الخروج</span>
          </button>
          <div className="text-right">
            <div className="text-sm font-bold text-slate-200">{user.displayName || 'مستخدم مسجل'}</div>
            <div className="text-xs text-slate-400 font-mono">{user.email}</div>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-slate-800 px-6 pt-3 gap-4">
          <button
            onClick={() => {
              playSound('click');
              setActiveTab('bookmarks');
            }}
            className={`pb-2.5 text-xs font-bold flex items-center gap-1.5 border-b-2 transition-colors ${
              activeTab === 'bookmarks'
                ? 'border-amber-400 text-amber-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Bookmark className="w-4 h-4" />
            <span>العناصر المحفوظة ({bookmarks.length})</span>
          </button>

          <button
            onClick={() => {
              playSound('click');
              setActiveTab('scores');
            }}
            className={`pb-2.5 text-xs font-bold flex items-center gap-1.5 border-b-2 transition-colors ${
              activeTab === 'scores'
                ? 'border-amber-400 text-amber-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Award className="w-4 h-4" />
            <span>سجل نتائج الاختبارات ({quizScores.length})</span>
          </button>
        </div>

        {/* Tab Content */}
        <div className="p-6 max-h-80 overflow-y-auto space-y-3">
          {activeTab === 'bookmarks' && (
            <>
              {bookmarks.length === 0 ? (
                <div className="text-center py-8 text-slate-400 text-xs">
                  لا توجد عناصر محفوظة حتى الآن. يمكنك حفظ الدول والمحطات التاريخية المفضلة.
                </div>
              ) : (
                bookmarks.map((b) => (
                  <div
                    key={b.id}
                    className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 flex items-center justify-between gap-3"
                  >
                    <button
                      onClick={() => removeBookmark(b.id)}
                      className="text-slate-500 hover:text-red-400 p-1.5 rounded-lg transition-colors"
                      title="حذف من المحفوظات"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                    <div className="text-right">
                      <div className="text-xs font-bold text-slate-200">{b.title}</div>
                      <div className="text-[10px] text-slate-400">{b.itemType}</div>
                    </div>
                  </div>
                ))
              )}
            </>
          )}

          {activeTab === 'scores' && (
            <>
              {quizScores.length === 0 ? (
                <div className="text-center py-8 text-slate-400 text-xs">
                  لم تقم بإجراء أي اختبار بعد. جرّب خوض "تحدي المؤرخ" الآن!
                </div>
              ) : (
                quizScores.map((s) => (
                  <div
                    key={s.id}
                    className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 flex items-center justify-between gap-3"
                  >
                    <div className="text-xs font-mono font-bold text-amber-400 bg-amber-500/10 px-2.5 py-1 rounded-lg border border-amber-500/20">
                      {s.score} / {s.total}
                    </div>
                    <div className="text-right">
                      <div className="text-xs font-bold text-slate-200">
                        {s.category === 'historian_challenge' ? 'تحدي مؤرخ الشرق الأوسط' : s.category}
                      </div>
                      <div className="text-[10px] text-slate-500 flex items-center justify-end gap-1 mt-0.5">
                        <Calendar className="w-3 h-3" />
                        <span>{new Date(s.completedAt).toLocaleDateString('ar-EG')}</span>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
};
