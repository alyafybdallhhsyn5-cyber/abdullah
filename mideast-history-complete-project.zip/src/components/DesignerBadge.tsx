import React from 'react';
import { DESIGNER_INFO } from '../data/middleEastData';
import { Instagram, ExternalLink, Sparkles } from 'lucide-react';
import { playSound } from '../utils/audio';

interface Props {
  onOpenModal: () => void;
  variant?: 'nav' | 'card' | 'footer';
}

export const DesignerBadge: React.FC<Props> = ({ onOpenModal, variant = 'nav' }) => {
  if (variant === 'nav') {
    return (
      <div className="flex items-center gap-1.5">
        <a
          href={DESIGNER_INFO.instagramUrl}
          target="_blank"
          rel="noopener noreferrer"
          title="زيارة حساب المصمم على Instagram"
          onClick={(e) => {
            playSound('click');
          }}
          className="inline-flex items-center gap-2 px-3 py-1.5 rounded-xl bg-gradient-to-r from-amber-500/15 via-rose-500/15 to-purple-500/15 border border-amber-500/30 hover:border-amber-400/70 text-slate-200 hover:text-white transition-all text-xs font-semibold group shadow-sm"
        >
          <div className="w-5 h-5 rounded-lg bg-gradient-to-tr from-amber-500 via-rose-500 to-purple-600 flex items-center justify-center text-white shrink-0 shadow-xs">
            <Instagram className="w-3.5 h-3.5" />
          </div>
          <div className="flex items-center gap-1">
            <span className="text-[11px] text-amber-300 font-bold hidden sm:inline">المصمم:</span>
            <span className="font-heading font-bold text-white group-hover:text-amber-300 transition-colors">
              {DESIGNER_INFO.name}
            </span>
            <span className="font-mono text-[11px] text-pink-400" dir="ltr">
              @{DESIGNER_INFO.instagram}
            </span>
          </div>
          <ExternalLink className="w-3 h-3 text-slate-400 group-hover:text-white transition-colors shrink-0" />
        </a>

        <button
          onClick={() => {
            onOpenModal();
            playSound('click');
          }}
          className="p-1.5 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-amber-300 border border-slate-700 transition-colors text-xs"
          title="معلومات المصمم"
          aria-label="معلومات المصمم"
        >
          <Sparkles className="w-3.5 h-3.5" />
        </button>
      </div>
    );
  }

  if (variant === 'card') {
    return (
      <div className="bg-gradient-to-br from-slate-900 via-slate-950 to-slate-900 border border-amber-500/25 rounded-2xl p-4 sm:p-5 relative overflow-hidden text-right shadow-lg">
        <div className="flex flex-col sm:flex-row items-center sm:items-start justify-between gap-4">
          <div className="flex items-center gap-3.5">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-amber-500 via-rose-500 to-purple-600 p-0.5 shrink-0 shadow-md">
              <div className="w-full h-full bg-slate-950 rounded-xl flex items-center justify-center text-amber-400 font-black font-heading text-lg">
                ع·ح
              </div>
            </div>
            <div>
              <div className="text-[11px] text-amber-400 font-semibold flex items-center gap-1">
                <span>تصميم وتطوير الواجهات</span>
                <span>•</span>
                <span>إشراف كامل</span>
              </div>
              <h3 className="text-base font-black text-white font-heading">
                {DESIGNER_INFO.name}
              </h3>
              <p className="text-xs text-slate-400 mt-0.5 line-clamp-1">
                {DESIGNER_INFO.role}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0 w-full sm:w-auto">
            <button
              onClick={() => {
                onOpenModal();
                playSound('click');
              }}
              className="flex-1 sm:flex-initial px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold border border-slate-700 transition-colors"
            >
              نبذة المصمم
            </button>
            <a
              href={DESIGNER_INFO.instagramUrl}
              target="_blank"
              rel="noopener noreferrer"
              onClick={() => playSound('coin')}
              className="flex-1 sm:flex-initial px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 via-rose-500 to-purple-600 hover:opacity-95 text-white text-xs font-bold flex items-center justify-center gap-1.5 shadow-md shadow-rose-500/20 active:scale-95 transition-transform"
            >
              <Instagram className="w-3.5 h-3.5" />
              <span dir="ltr">@{DESIGNER_INFO.instagram}</span>
              <ExternalLink className="w-3 h-3" />
            </a>
          </div>
        </div>
      </div>
    );
  }

  // Footer variant
  return (
    <div className="flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-400 border-t border-slate-800/80 pt-4">
      <div className="flex items-center gap-2">
        <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
        <span>تطبيق توثيق تاريخ وحاضر الشرق الأوسط</span>
        <span>•</span>
        <span>جميع الحقوق محفوظة</span>
      </div>

      <div className="flex items-center gap-2">
        <span>فكرة وتصميم وتطوير:</span>
        <button
          onClick={onOpenModal}
          className="font-bold text-white hover:text-amber-300 transition-colors font-heading underline decoration-amber-500/50 underline-offset-4"
        >
          {DESIGNER_INFO.name}
        </button>
        <a
          href={DESIGNER_INFO.instagramUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-1 font-mono text-pink-400 hover:text-pink-300 font-bold bg-pink-500/10 px-2 py-0.5 rounded-md border border-pink-500/20"
          dir="ltr"
        >
          <Instagram className="w-3 h-3" />
          <span>@{DESIGNER_INFO.instagram}</span>
          <ExternalLink className="w-2.5 h-2.5" />
        </a>
      </div>
    </div>
  );
};
