import React from 'react';
import { DESIGNER_INFO } from '../data/middleEastData';
import { X, ExternalLink, Instagram, Sparkles, Award, Palette, Heart } from 'lucide-react';
import { playSound } from '../utils/audio';

interface Props {
  isOpen: boolean;
  onClose: () => void;
}

export const DesignerModal: React.FC<Props> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto animate-in fade-in">
      <div className="relative w-full max-w-lg bg-gradient-to-b from-slate-900 via-slate-950 to-black border border-amber-500/30 rounded-3xl p-6 sm:p-8 shadow-2xl shadow-amber-500/10 text-right overflow-hidden">
        {/* Decorative Ambient Glow */}
        <div className="absolute -top-20 -right-20 w-48 h-48 bg-amber-500/15 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-20 -left-20 w-48 h-48 bg-pink-500/10 rounded-full blur-3xl pointer-events-none" />

        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 left-5 p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors border border-slate-700"
          aria-label="إغلاق"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header Badge */}
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-semibold mb-4">
          <Palette className="w-3.5 h-3.5" />
          <span>المصمم والمطور المعتمد</span>
        </div>

        {/* Designer Profile Card */}
        <div className="flex flex-col sm:flex-row items-center sm:items-start gap-4 mb-6">
          {/* Avatar with Golden Ring */}
          <div className="relative group shrink-0">
            <div className="w-20 h-20 rounded-2xl bg-gradient-to-tr from-amber-500 via-rose-500 to-purple-600 p-0.5 shadow-xl shadow-amber-500/20">
              <div className="w-full h-full bg-slate-950 rounded-2xl flex items-center justify-center text-3xl font-black text-amber-400 font-heading">
                ع·ح
              </div>
            </div>
            <div className="absolute -bottom-1 -left-1 w-6 h-6 rounded-full bg-gradient-to-tr from-rose-500 to-amber-500 flex items-center justify-center text-white border-2 border-slate-950 shadow">
              <Instagram className="w-3.5 h-3.5" />
            </div>
          </div>

          <div className="text-center sm:text-right flex-1">
            <h2 className="text-2xl font-black text-white font-heading tracking-wide">
              {DESIGNER_INFO.name}
            </h2>
            <div className="text-sm font-semibold text-amber-400 mt-0.5 font-heading">
              {DESIGNER_INFO.role}
            </div>
            <p className="text-xs text-slate-300 mt-2 leading-relaxed">
              {DESIGNER_INFO.bio}
            </p>
          </div>
        </div>

        {/* Direct Clickable Instagram Showcase */}
        <div className="p-4 bg-slate-900/90 border border-slate-800 rounded-2xl mb-6 relative overflow-hidden group">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-slate-400">حساب Instagram الرسمي:</span>
            <span className="text-[10px] text-emerald-400 font-mono bg-emerald-500/10 border border-emerald-500/20 px-2 py-0.5 rounded-full">
              حساب موثق
            </span>
          </div>

          <a
            href={DESIGNER_INFO.instagramUrl}
            target="_blank"
            rel="noopener noreferrer"
            onClick={() => playSound('coin')}
            className="flex items-center justify-between p-3.5 rounded-xl bg-gradient-to-r from-pink-600/20 via-purple-600/20 to-amber-500/20 border border-pink-500/30 hover:border-pink-500/60 transition-all group-hover:scale-[1.01]"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-500 via-rose-500 to-purple-600 flex items-center justify-center text-white shadow-md">
                <Instagram className="w-5 h-5" />
              </div>
              <div className="text-right">
                <div className="text-sm font-mono font-black text-white group-hover:text-amber-300 transition-colors">
                  @{DESIGNER_INFO.instagram}
                </div>
                <div className="text-[11px] text-slate-400">
                  انقر هنا لفتح الحساب مباشرة على تطبيق إنستغرام
                </div>
              </div>
            </div>

            <div className="flex items-center gap-1 text-xs text-pink-400 font-bold bg-pink-500/10 px-2.5 py-1 rounded-lg">
              <span>زيارة الحساب</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </div>
          </a>
        </div>

        {/* Highlights & Vision */}
        <div className="grid grid-cols-2 gap-2 text-xs mb-6">
          <div className="p-3 bg-slate-950/70 border border-slate-800 rounded-xl">
            <div className="flex items-center gap-1.5 text-amber-400 font-bold mb-1">
              <Award className="w-3.5 h-3.5" />
              <span>إتقان التصميم العربي</span>
            </div>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              واجهات متناسقة تحترم قواعد RTL والخطوط العربية الأصيلة.
            </p>
          </div>

          <div className="p-3 bg-slate-950/70 border border-slate-800 rounded-xl">
            <div className="flex items-center gap-1.5 text-rose-400 font-bold mb-1">
              <Sparkles className="w-3.5 h-3.5" />
              <span>أداء متجاوب فائق</span>
            </div>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              تجربة مستخدم سريعة مصممة خصيصاً لهواتف أندرويد والحواسيب.
            </p>
          </div>
        </div>

        {/* Action Button */}
        <div className="flex items-center justify-between gap-3 pt-2 border-t border-slate-800/80">
          <span className="text-[11px] text-slate-400 flex items-center gap-1">
            <span>صُنع بشغف للهوية العربية</span>
            <Heart className="w-3.5 h-3.5 text-rose-500 fill-rose-500" />
          </span>

          <a
            href={DESIGNER_INFO.instagramUrl}
            target="_blank"
            rel="noopener noreferrer"
            onClick={() => playSound('click')}
            className="px-5 py-2.5 bg-gradient-to-r from-amber-500 via-rose-500 to-purple-600 hover:opacity-95 text-white font-bold text-xs rounded-xl shadow-lg shadow-rose-500/20 flex items-center gap-2 transition-transform active:scale-95"
          >
            <Instagram className="w-4 h-4" />
            <span>متابعة على Instagram ↗</span>
          </a>
        </div>
      </div>
    </div>
  );
};
