import React from 'react';
import { playSound } from '../utils/audio';
import { Sparkles, Users, Palette, Layers, Cpu, PlayCircle, ShieldCheck, Smartphone, DollarSign } from 'lucide-react';

interface Props {
  currentStage: number;
  onSelectStage: (stage: number) => void;
}

const STAGES = [
  { id: 1, title: '1. تطوير الفكرة', icon: Sparkles, short: 'الفكرة والابتكار' },
  { id: 2, title: '2. الجمهور المستهدف', icon: Users, short: 'الجمهور وسيناريو الاستخدام' },
  { id: 3, title: '3. واجهات RTL', icon: Palette, short: 'تصميم الواجهات والهاتف' },
  { id: 4, title: '4. الشاشات والأزرار', icon: Layers, short: 'الشاشات والوظائف' },
  { id: 5, title: '5. التقنية للمبتدئ', icon: Cpu, short: 'التقنية وهاتف أندرويد' },
  { id: 6, title: '6. نموذج أولي حي', icon: PlayCircle, short: 'النموذج الأولي واللعب 🎮', badge: 'شغال' },
  { id: 7, title: '7. فحص الجودة QA', icon: ShieldCheck, short: 'فحص الأخطاء واللمس' },
  { id: 8, title: '8. تصدير Android', icon: Smartphone, short: 'تصدير APK والتثبيت' },
  { id: 9, title: '9. دليل التكاليف', icon: DollarSign, short: 'المجاني vs المدفوع' },
];

export const StagesNav: React.FC<Props> = ({ currentStage, onSelectStage }) => {
  return (
    <div className="w-full bg-slate-900/90 border-y border-slate-800/80 sticky top-16 z-30 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 py-2.5 overflow-x-auto no-scrollbar flex items-center gap-2">
        {STAGES.map((s) => {
          const Icon = s.icon;
          const isActive = currentStage === s.id;
          const isPassed = currentStage > s.id;

          return (
            <button
              key={s.id}
              onClick={() => {
                onSelectStage(s.id);
                playSound('click');
              }}
              className={`px-3 py-2 rounded-xl text-xs font-bold transition-all shrink-0 flex items-center gap-2 border ${
                isActive
                  ? 'bg-indigo-600 border-indigo-400 text-white shadow-lg shadow-indigo-600/30 scale-[1.02]'
                  : isPassed
                  ? 'bg-slate-950/80 border-emerald-500/30 text-emerald-300 hover:border-emerald-500/60'
                  : 'bg-slate-950/50 border-slate-800 text-slate-400 hover:text-slate-200 hover:border-slate-700'
              }`}
            >
              <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-white' : isPassed ? 'text-emerald-400' : 'text-slate-500'}`} />
              <span className="font-heading">{s.title}</span>
              {s.badge && (
                <span className="text-[9px] bg-emerald-500 text-slate-950 font-black px-1.5 py-0.2 rounded-full animate-pulse">
                  {s.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
};
