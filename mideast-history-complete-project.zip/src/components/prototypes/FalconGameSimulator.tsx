import React, { useEffect, useRef, useState, useCallback } from 'react';
import { playSound } from '../../utils/audio';
import confetti from 'canvas-confetti';
import { RotateCcw, Volume2, VolumeX, Zap, Trophy, Play, Maximize2, Sparkles } from 'lucide-react';

interface FalconGameSimulatorProps {
  primaryColor?: string;
}

export const FalconGameSimulator: React.FC<FalconGameSimulatorProps> = ({ primaryColor = '#f59e0b' }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [gameState, setGameState] = useState<'idle' | 'playing' | 'gameover'>('idle');
  const [score, setScore] = useState(0);
  const [highScore, setHighScore] = useState(() => {
    return parseInt(localStorage.getItem('falcon_highscore') || '0', 10);
  });
  const [datesCollected, setDatesCollected] = useState(0);
  const [shieldActive, setShieldActive] = useState(false);
  const [soundOn, setSoundOn] = useState(true);
  const [difficulty, setDifficulty] = useState<'easy' | 'normal' | 'hard'>('normal');

  // Game physics state refs
  const stateRef = useRef({
    falconY: 180,
    falconVelocity: 0,
    gravity: 0.38,
    jumpStrength: -6.5,
    obstacles: [] as { x: number; topHeight: number; bottomHeight: number; passed: boolean }[],
    dates: [] as { x: number; y: number; collected: boolean }[],
    gameSpeed: 2.5,
    frameCount: 0,
    score: 0,
    datesCollected: 0,
    shieldTimer: 0,
    animationFrameId: 0
  });

  const jump = useCallback(() => {
    if (gameState === 'idle') {
      setGameState('playing');
      playSound('jump');
      stateRef.current.falconVelocity = stateRef.current.jumpStrength;
      return;
    }
    if (gameState === 'gameover') {
      restartGame();
      return;
    }
    stateRef.current.falconVelocity = stateRef.current.jumpStrength;
    playSound('jump');
  }, [gameState]);

  const restartGame = () => {
    stateRef.current = {
      falconY: 180,
      falconVelocity: 0,
      gravity: difficulty === 'easy' ? 0.32 : difficulty === 'hard' ? 0.44 : 0.38,
      jumpStrength: difficulty === 'easy' ? -6.2 : difficulty === 'hard' ? -6.8 : -6.5,
      obstacles: [],
      dates: [],
      gameSpeed: difficulty === 'easy' ? 2.0 : difficulty === 'hard' ? 3.2 : 2.5,
      frameCount: 0,
      score: 0,
      datesCollected: 0,
      shieldTimer: 0,
      animationFrameId: 0
    };
    setScore(0);
    setDatesCollected(0);
    setShieldActive(false);
    setGameState('playing');
    playSound('click');
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let isRunning = true;

    const gameLoop = () => {
      if (!isRunning) return;

      const state = stateRef.current;
      const width = canvas.width;
      const height = canvas.height;

      // Clear Canvas
      ctx.clearRect(0, 0, width, height);

      // Sky Background gradient
      const skyGradient = ctx.createLinearGradient(0, 0, 0, height);
      skyGradient.addColorStop(0, '#0f172a'); // Night sky top
      skyGradient.addColorStop(0.5, '#1e1b4b'); // Deep indigo
      skyGradient.addColorStop(0.85, '#431407'); // Desert dusk orange
      skyGradient.addColorStop(1, '#78350f'); // Dune ground
      ctx.fillStyle = skyGradient;
      ctx.fillRect(0, 0, width, height);

      // Distant desert dunes (parallax)
      ctx.fillStyle = 'rgba(180, 83, 9, 0.25)';
      ctx.beginPath();
      ctx.moveTo(0, height);
      ctx.quadraticCurveTo(width * 0.3, height - 70, width * 0.6, height - 40);
      ctx.quadraticCurveTo(width * 0.85, height - 20, width, height - 50);
      ctx.lineTo(width, height);
      ctx.fill();

      // Golden Moon / Sun in sky
      ctx.fillStyle = 'rgba(251, 191, 36, 0.85)';
      ctx.beginPath();
      ctx.arc(width - 50, 50, 24, 0, Math.PI * 2);
      ctx.fill();

      // Crescent moon detail
      ctx.fillStyle = '#0f172a';
      ctx.beginPath();
      ctx.arc(width - 44, 46, 20, 0, Math.PI * 2);
      ctx.fill();

      if (gameState === 'playing') {
        state.frameCount++;

        // Apply gravity to falcon
        state.falconVelocity += state.gravity;
        state.falconY += state.falconVelocity;

        // Shield countdown
        if (state.shieldTimer > 0) {
          state.shieldTimer--;
          if (state.shieldTimer === 0) {
            setShieldActive(false);
          }
        }

        // Spawn obstacles
        const spawnInterval = difficulty === 'hard' ? 95 : 125;
        if (state.frameCount % spawnInterval === 0) {
          const gap = 110;
          const minHeight = 45;
          const availableHeight = height - gap - 60;
          const topHeight = Math.floor(Math.random() * (availableHeight - minHeight)) + minHeight;
          const bottomHeight = height - topHeight - gap;

          state.obstacles.push({
            x: width,
            topHeight,
            bottomHeight,
            passed: false
          });

          // 65% chance to spawn a golden date in the middle of the gap
          if (Math.random() < 0.65) {
            state.dates.push({
              x: width + 25,
              y: topHeight + gap / 2,
              collected: false
            });
          }
        }

        // Update obstacles
        for (let i = state.obstacles.length - 1; i >= 0; i--) {
          const obs = state.obstacles[i];
          obs.x -= state.gameSpeed;

          // Check if passed for score
          if (!obs.passed && obs.x + 38 < 60) {
            obs.passed = true;
            state.score += 1;
            setScore(state.score);
            playSound('coin');
          }

          // Remove offscreen
          if (obs.x < -60) {
            state.obstacles.splice(i, 1);
          }
        }

        // Update dates
        for (let i = state.dates.length - 1; i >= 0; i--) {
          const date = state.dates[i];
          date.x -= state.gameSpeed;

          // Collision with falcon (radius 18)
          const dist = Math.hypot(date.x - 70, date.y - state.falconY);
          if (!date.collected && dist < 26) {
            date.collected = true;
            state.datesCollected += 1;
            setDatesCollected(state.datesCollected);
            playSound('coin');

            // 5 dates give speed boost & shield
            if (state.datesCollected % 5 === 0) {
              state.shieldTimer = 180; // 3 seconds
              setShieldActive(true);
              playSound('level');
              confetti({
                particleCount: 25,
                spread: 45,
                origin: { y: 0.6 }
              });
            }
          }

          if (date.x < -30 || date.collected) {
            state.dates.splice(i, 1);
          }
        }

        // Check Falcon collision with floor or ceiling
        if (state.falconY < 15 || state.falconY > height - 25) {
          if (state.shieldTimer <= 0) {
            triggerGameOver();
          } else {
            state.falconY = Math.max(20, Math.min(height - 30, state.falconY));
            state.falconVelocity = 0;
          }
        }

        // Check Falcon collision with pillars
        if (state.shieldTimer <= 0) {
          const falconRadius = 14;
          for (const obs of state.obstacles) {
            if (obs.x < 70 + falconRadius && obs.x + 40 > 70 - falconRadius) {
              if (state.falconY - falconRadius < obs.topHeight || state.falconY + falconRadius > height - obs.bottomHeight) {
                triggerGameOver();
                break;
              }
            }
          }
        }
      }

      // Draw Obstacles (Desert Sandstone Pillars)
      for (const obs of state.obstacles) {
        // Top pillar
        const topGrad = ctx.createLinearGradient(obs.x, 0, obs.x + 40, 0);
        topGrad.addColorStop(0, '#d97706');
        topGrad.addColorStop(0.5, '#f59e0b');
        topGrad.addColorStop(1, '#92400e');
        ctx.fillStyle = topGrad;
        ctx.fillRect(obs.x, 0, 40, obs.topHeight);

        // Top pillar cap
        ctx.fillStyle = '#b45309';
        ctx.fillRect(obs.x - 4, obs.topHeight - 12, 48, 12);

        // Bottom pillar
        const btmY = height - obs.bottomHeight;
        ctx.fillStyle = topGrad;
        ctx.fillRect(obs.x, btmY, 40, obs.bottomHeight);

        // Bottom pillar cap
        ctx.fillStyle = '#b45309';
        ctx.fillRect(obs.x - 4, btmY, 48, 12);
      }

      // Draw Golden Dates (الرطب الذهبي)
      for (const date of state.dates) {
        ctx.save();
        ctx.translate(date.x, date.y);

        // Glowing halo
        ctx.fillStyle = 'rgba(245, 158, 11, 0.4)';
        ctx.beginPath();
        ctx.arc(0, 0, 14, 0, Math.PI * 2);
        ctx.fill();

        // Date oval shape
        ctx.fillStyle = '#f59e0b';
        ctx.beginPath();
        ctx.ellipse(0, 0, 9, 6, Math.PI / 4, 0, Math.PI * 2);
        ctx.fill();

        // Shiny glint
        ctx.fillStyle = '#fef08a';
        ctx.beginPath();
        ctx.arc(-2, -2, 2.5, 0, Math.PI * 2);
        ctx.fill();

        ctx.restore();
      }

      // Draw Ground
      const groundGrad = ctx.createLinearGradient(0, height - 20, 0, height);
      groundGrad.addColorStop(0, '#b45309');
      groundGrad.addColorStop(1, '#78350f');
      ctx.fillStyle = groundGrad;
      ctx.fillRect(0, height - 20, width, 20);

      // Ground sand pattern line
      ctx.strokeStyle = '#f59e0b';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(0, height - 20);
      ctx.lineTo(width, height - 20);
      ctx.stroke();

      // Draw Falcon (الصقر)
      ctx.save();
      ctx.translate(70, state.falconY);

      // Falcon tilt rotation based on velocity
      const rotation = Math.min(Math.PI / 4, Math.max(-Math.PI / 4, state.falconVelocity * 0.08));
      ctx.rotate(rotation);

      // Shield Aura when active
      if (state.shieldTimer > 0) {
        ctx.strokeStyle = 'rgba(56, 189, 248, 0.8)';
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.arc(0, 0, 22, 0, Math.PI * 2);
        ctx.stroke();

        ctx.fillStyle = 'rgba(56, 189, 248, 0.2)';
        ctx.fill();
      }

      // Falcon Body
      ctx.fillStyle = '#78350f'; // Dark warm brown
      ctx.beginPath();
      ctx.ellipse(0, 0, 16, 11, 0, 0, Math.PI * 2);
      ctx.fill();

      // Falcon Belly (Cream / Golden)
      ctx.fillStyle = '#fef3c7';
      ctx.beginPath();
      ctx.ellipse(3, 3, 10, 6, 0, 0, Math.PI * 2);
      ctx.fill();

      // Falcon Wing (Flaps with velocity)
      const wingOffset = Math.sin(state.frameCount * 0.3) * 4;
      ctx.fillStyle = '#92400e';
      ctx.beginPath();
      ctx.ellipse(-4, -4 + wingOffset, 11, 6, -0.3, 0, Math.PI * 2);
      ctx.fill();

      // Falcon Eye
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(8, -4, 4, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#0f172a';
      ctx.beginPath();
      ctx.arc(9.5, -4, 2, 0, Math.PI * 2);
      ctx.fill();

      // Sharp Falcon Beak (Golden)
      ctx.fillStyle = '#f59e0b';
      ctx.beginPath();
      ctx.moveTo(13, -2);
      ctx.lineTo(21, 1);
      ctx.lineTo(13, 4);
      ctx.closePath();
      ctx.fill();

      ctx.restore();

      state.animationFrameId = requestAnimationFrame(gameLoop);
    };

    stateRef.current.animationFrameId = requestAnimationFrame(gameLoop);

    return () => {
      isRunning = false;
      cancelAnimationFrame(stateRef.current.animationFrameId);
    };
  }, [gameState, difficulty]);

  const triggerGameOver = () => {
    setGameState('gameover');
    playSound('gameover');
    const finalScore = stateRef.current.score;
    if (finalScore > highScore) {
      setHighScore(finalScore);
      localStorage.setItem('falcon_highscore', finalScore.toString());
      playSound('success');
      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.5 }
      });
    }
  };

  return (
    <div className="flex flex-col items-center w-full">
      {/* Mobile Frame Container */}
      <div className="relative w-full max-w-[340px] sm:max-w-[360px] bg-slate-900 border-4 border-slate-700/80 rounded-[38px] shadow-2xl shadow-amber-500/10 overflow-hidden select-none">
        {/* Android Top Speaker Notch */}
        <div className="absolute top-2 left-1/2 -translate-x-1/2 w-24 h-4 bg-slate-950 rounded-full z-30 flex items-center justify-center">
          <div className="w-8 h-1.5 bg-slate-800 rounded-full" />
          <div className="w-2.5 h-2.5 bg-slate-900 border border-slate-700 rounded-full ml-3" />
        </div>

        {/* Android Status Bar */}
        <div className="relative pt-6 px-5 pb-2 bg-slate-950/90 text-xs text-slate-300 flex justify-between items-center z-20 font-mono">
          <div className="flex items-center gap-1.5 font-bold">
            <span>12:45</span>
            <span className="text-[10px] text-amber-400">4G+</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-[10px] text-slate-400">⚡ 94%</span>
            <div className="w-5 h-2.5 border border-slate-400 rounded-xs p-0.5 flex items-center">
              <div className="h-full bg-emerald-400 w-4/5 rounded-xs" />
            </div>
          </div>
        </div>

        {/* Top HUD inside the game */}
        <div className="relative px-4 py-2 bg-slate-900/90 border-b border-slate-800 flex items-center justify-between z-20">
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1 bg-amber-500/20 text-amber-300 px-2 py-0.5 rounded-lg border border-amber-500/30 text-xs font-bold font-mono">
              <span>🏆</span>
              <span>{highScore}</span>
            </div>
            <div className="flex items-center gap-1 bg-slate-800 text-amber-400 px-2 py-0.5 rounded-lg text-xs font-bold font-mono">
              <span>🌴</span>
              <span>{datesCollected}</span>
            </div>
          </div>

          <div className="text-xl font-black font-mono text-white tracking-wider">
            {score}
          </div>

          <button
            onClick={() => {
              setSoundOn(!soundOn);
              playSound('click');
            }}
            className="p-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-white"
            title="تبديل الصوت"
          >
            {soundOn ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4 text-rose-400" />}
          </button>
        </div>

        {/* Main Canvas Game Area */}
        <div 
          onClick={jump}
          onTouchStart={(e) => {
            e.preventDefault();
            jump();
          }}
          className="relative w-full h-[400px] bg-slate-950 cursor-pointer overflow-hidden flex items-center justify-center active:scale-[0.99] transition-transform"
        >
          <canvas
            ref={canvasRef}
            width={340}
            height={400}
            className="w-full h-full block"
          />

          {/* Shield active indicator badge */}
          {shieldActive && (
            <div className="absolute top-3 left-1/2 -translate-x-1/2 bg-sky-500/90 text-white text-xs px-3 py-1 rounded-full flex items-center gap-1 shadow-lg animate-pulse z-20">
              <Sparkles className="w-3.5 h-3.5" />
              <span>درع الصقر الخارق نشط!</span>
            </div>
          )}

          {/* Idle Start Overlay */}
          {gameState === 'idle' && (
            <div className="absolute inset-0 bg-slate-950/75 backdrop-blur-[2px] flex flex-col items-center justify-center p-6 text-center z-20 animate-in fade-in">
              <div className="w-16 h-16 rounded-2xl bg-amber-500/20 border-2 border-amber-500/50 flex items-center justify-center text-3xl mb-3 shadow-lg shadow-amber-500/20 animate-bounce">
                🦅
              </div>
              <h3 className="text-xl font-black text-amber-400 mb-1 font-heading">تحدي الصقر العربي</h3>
              <p className="text-xs text-slate-300 mb-4 max-w-[220px]">
                انقر على الشاشة أو زر الطيران للقفز وتفادي العوائق وجمع التمور!
              </p>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  jump();
                }}
                className="w-full py-3 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-black rounded-xl shadow-lg shadow-amber-500/30 flex items-center justify-center gap-2 text-sm transition-all"
              >
                <Play className="w-4 h-4 fill-slate-950" />
                <span>انقر للبدء الفوري</span>
              </button>
            </div>
          )}

          {/* Game Over Overlay */}
          {gameState === 'gameover' && (
            <div className="absolute inset-0 bg-slate-950/85 backdrop-blur-[3px] flex flex-col items-center justify-center p-6 text-center z-20 animate-in zoom-in-95">
              <div className="text-4xl mb-2">💥</div>
              <h3 className="text-xl font-black text-rose-400 mb-1 font-heading">انتهت المحاولة!</h3>
              
              <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-3 w-full my-3 flex justify-around">
                <div className="text-center">
                  <div className="text-[11px] text-slate-400">النتيجة</div>
                  <div className="text-2xl font-black text-amber-400 font-mono">{score}</div>
                </div>
                <div className="w-px bg-slate-800 my-1" />
                <div className="text-center">
                  <div className="text-[11px] text-slate-400">أعلى رقم 🏆</div>
                  <div className="text-2xl font-black text-emerald-400 font-mono">{highScore}</div>
                </div>
              </div>

              {score >= highScore && score > 0 && (
                <div className="text-xs text-amber-300 bg-amber-500/20 border border-amber-500/40 px-3 py-1 rounded-full mb-3 font-bold animate-pulse">
                  🎉 رقم قياسي شخصي جديد!
                </div>
              )}

              <button
                onClick={(e) => {
                  e.stopPropagation();
                  restartGame();
                }}
                className="w-full py-3 bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-400 hover:to-emerald-500 text-slate-950 font-black rounded-xl shadow-lg shadow-emerald-500/30 flex items-center justify-center gap-2 text-sm transition-all"
              >
                <RotateCcw className="w-4 h-4" />
                <span>جرّب مرة أخرى 🔄</span>
              </button>
            </div>
          )}
        </div>

        {/* Big Touch Action Controller (Thumb Zone on Mobile) */}
        <div className="p-4 bg-slate-950 border-t border-slate-800/80 flex flex-col gap-2 z-20">
          <button
            onClick={jump}
            className="w-full py-4 bg-amber-500 active:bg-amber-600 text-slate-950 font-black text-base rounded-2xl shadow-lg shadow-amber-500/25 flex items-center justify-center gap-2 transition-transform active:scale-95"
          >
            <Zap className="w-5 h-5 fill-slate-950" />
            <span>اضغط هنا للطيران والقفز 🚀</span>
          </button>
          
          <div className="flex items-center justify-between text-[11px] text-slate-400 px-1 pt-1">
            <span>الصعوبة:</span>
            <div className="flex gap-1">
              {(['easy', 'normal', 'hard'] as const).map((diff) => (
                <button
                  key={diff}
                  onClick={(e) => {
                    e.stopPropagation();
                    setDifficulty(diff);
                    restartGame();
                  }}
                  className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                    difficulty === diff
                      ? 'bg-amber-500 text-slate-950'
                      : 'bg-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  {diff === 'easy' ? 'سهل' : diff === 'normal' ? 'متوسط' : 'تحدي'}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Android Bottom Navigation Bar */}
        <div className="py-2.5 bg-slate-950 flex justify-center items-center gap-12 text-slate-600 z-20">
          <div className="w-3.5 h-3.5 border-2 border-slate-600 rounded-sm" />
          <div className="w-3.5 h-3.5 border-2 border-slate-600 rounded-full" />
          <div className="w-0 h-0 border-y-4 border-y-transparent border-r-6 border-r-slate-600" />
        </div>
      </div>

      <div className="mt-3 text-xs text-slate-400 text-center flex items-center gap-1">
        <Sparkles className="w-3.5 h-3.5 text-amber-400" />
        <span>نموذج لعبة كامل يعمل 100% بمعدل 60 إطار في الثانية بالفيزياء والصوت ومحاكي الأندرويد.</span>
      </div>
    </div>
  );
};
