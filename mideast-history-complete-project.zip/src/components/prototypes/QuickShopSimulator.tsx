import React, { useState } from 'react';
import { playSound } from '../../utils/audio';
import confetti from 'canvas-confetti';
import { ShoppingBag, Plus, Minus, ArrowLeft, MessageSquare, Check, Trash2 } from 'lucide-react';

interface Product {
  id: string;
  name: string;
  price: number;
  image: string;
  category: string;
}

const PRODUCTS: Product[] = [
  { id: '1', name: 'تمر سكري فاخر (1 كجم)', price: 45, image: '🌴', category: 'تمور' },
  { id: '2', name: 'قهوة عربية بالهيل والزعفران', price: 35, image: '☕', category: 'مشروبات' },
  { id: '3', name: 'عسل سدر طبيعي أصلي', price: 120, image: '🍯', category: 'عسل' },
  { id: '4', name: 'معمول بالتمر ودبس الخلاص', price: 28, image: '🥮', category: 'حلويات' }
];

export const QuickShopSimulator: React.FC = () => {
  const [cart, setCart] = useState<{ [id: string]: number }>({ '1': 1 });
  const [view, setView] = useState<'catalog' | 'cart' | 'success'>('catalog');
  const [customerName, setCustomerName] = useState('عبدالله');
  const [customerCity, setCustomerCity] = useState('الرياض');

  const addToCart = (id: string) => {
    setCart((prev) => ({ ...prev, [id]: (prev[id] || 0) + 1 }));
    playSound('coin');
  };

  const removeFromCart = (id: string) => {
    setCart((prev) => {
      const copy = { ...prev };
      if (copy[id] > 1) {
        copy[id] -= 1;
      } else {
        delete copy[id];
      }
      return copy;
    });
    playSound('click');
  };

  const totalItems = Object.values(cart).reduce((a, b) => a + b, 0);
  const totalPrice = Object.entries(cart).reduce((sum, [id, qty]) => {
    const p = PRODUCTS.find((item) => item.id === id);
    return sum + (p ? p.price * qty : 0);
  }, 0);

  const formatWhatsAppOrder = () => {
    let msg = `السلام عليكم ورحمة الله،\nأود تأكيد طلب جديد من المتجر:\n`;
    Object.entries(cart).forEach(([id, qty]) => {
      const p = PRODUCTS.find((item) => item.id === id);
      if (p) msg += `- ${p.name} × ${qty} = ${p.price * qty} ر.س\n`;
    });
    msg += `---------------------\nالإجمالي: ${totalPrice} ر.س\n`;
    msg += `الاسم: ${customerName}\nالمدينة: ${customerCity}`;
    return msg;
  };

  const submitOrder = () => {
    playSound('success');
    confetti({
      particleCount: 40,
      spread: 60,
      origin: { y: 0.6 }
    });
    setView('success');
  };

  return (
    <div className="flex flex-col items-center w-full">
      <div className="relative w-full max-w-[340px] sm:max-w-[360px] bg-slate-900 border-4 border-slate-700/80 rounded-[38px] shadow-2xl shadow-emerald-500/10 overflow-hidden select-none min-h-[580px] flex flex-col justify-between">
        {/* Notch */}
        <div className="absolute top-2 left-1/2 -translate-x-1/2 w-24 h-4 bg-slate-950 rounded-full z-30 flex items-center justify-center">
          <div className="w-8 h-1.5 bg-slate-800 rounded-full" />
          <div className="w-2.5 h-2.5 bg-slate-900 border border-slate-700 rounded-full ml-3" />
        </div>

        {/* Status Bar */}
        <div className="relative pt-6 px-5 pb-2 bg-slate-950/90 text-xs text-slate-300 flex justify-between items-center z-20 font-mono">
          <span className="font-bold">16:20</span>
          <span className="text-[10px] text-emerald-400">4G</span>
        </div>

        {/* Header */}
        <div className="px-5 py-3 bg-gradient-to-b from-emerald-950/60 to-slate-900 border-b border-emerald-900/30 flex items-center justify-between">
          <div className="flex items-center gap-2">
            {view === 'cart' && (
              <button
                onClick={() => setView('catalog')}
                className="p-1 rounded-lg bg-slate-800 text-slate-300 hover:text-white"
              >
                <ArrowLeft className="w-4 h-4" />
              </button>
            )}
            <h3 className="font-bold text-white text-base font-heading">
              {view === 'catalog' ? 'متجر دكان الأصيل 🛒' : 'سلة المشتريات'}
            </h3>
          </div>

          <button
            onClick={() => setView('cart')}
            className="relative p-2 rounded-xl bg-emerald-500/20 text-emerald-300 border border-emerald-500/30"
          >
            <ShoppingBag className="w-4 h-4" />
            {totalItems > 0 && (
              <span className="absolute -top-1 -right-1 bg-emerald-500 text-slate-950 text-[10px] font-black rounded-full w-4 h-4 flex items-center justify-center">
                {totalItems}
              </span>
            )}
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 p-4 overflow-y-auto max-h-[360px]">
          {view === 'catalog' ? (
            <div className="grid grid-cols-2 gap-2.5">
              {PRODUCTS.map((prod) => {
                const count = cart[prod.id] || 0;
                return (
                  <div
                    key={prod.id}
                    className="bg-slate-950/80 border border-slate-800 rounded-2xl p-3 flex flex-col justify-between"
                  >
                    <div className="text-center py-2 text-4xl mb-1">{prod.image}</div>
                    <div>
                      <h4 className="text-xs font-bold text-slate-200 line-clamp-1 mb-0.5">{prod.name}</h4>
                      <div className="text-xs font-mono font-black text-emerald-400 mb-2">
                        {prod.price} <span className="text-[10px] font-normal text-slate-400">ر.س</span>
                      </div>
                    </div>

                    <button
                      onClick={() => addToCart(prod.id)}
                      className="w-full py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center justify-center gap-1 active:scale-95 transition-transform"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>{count > 0 ? `أضف (${count})` : 'أضف للسلة'}</span>
                    </button>
                  </div>
                );
              })}
            </div>
          ) : view === 'cart' ? (
            <div className="space-y-3">
              {totalItems === 0 ? (
                <div className="text-center py-10 text-slate-400 text-xs">
                  السلة فارغة حالياً. تصفح الكتالوج وأضف منتجاتك المفضلة!
                </div>
              ) : (
                <>
                  <div className="space-y-2">
                    {Object.entries(cart).map(([id, qty]) => {
                      const p = PRODUCTS.find((item) => item.id === id);
                      if (!p) return null;
                      return (
                        <div
                          key={id}
                          className="p-2.5 bg-slate-950 border border-slate-800 rounded-xl flex items-center justify-between"
                        >
                          <div className="flex items-center gap-2">
                            <span className="text-2xl">{p.image}</span>
                            <div>
                              <div className="text-xs font-bold text-white">{p.name}</div>
                              <div className="text-[10px] text-emerald-400 font-mono">
                                {p.price * qty} ر.س
                              </div>
                            </div>
                          </div>

                          <div className="flex items-center gap-1.5 bg-slate-900 px-1.5 py-0.5 rounded-lg border border-slate-800">
                            <button
                              onClick={() => removeFromCart(id)}
                              className="text-slate-400 hover:text-white p-0.5"
                            >
                              <Minus className="w-3 h-3" />
                            </button>
                            <span className="text-xs font-mono font-bold text-white px-1">{qty}</span>
                            <button
                              onClick={() => addToCart(id)}
                              className="text-emerald-400 hover:text-emerald-300 p-0.5"
                            >
                              <Plus className="w-3 h-3" />
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  {/* Customer Info Form */}
                  <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-3 space-y-2 text-xs">
                    <div>
                      <label className="text-[10px] text-slate-400 block mb-1">اسم المشتري:</label>
                      <input
                        type="text"
                        value={customerName}
                        onChange={(e) => setCustomerName(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1 text-white"
                      />
                    </div>
                    <div>
                      <label className="text-[10px] text-slate-400 block mb-1">المدينة / الحي:</label>
                      <input
                        type="text"
                        value={customerCity}
                        onChange={(e) => setCustomerCity(e.target.value)}
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1 text-white"
                      />
                    </div>
                  </div>
                </>
              )}
            </div>
          ) : (
            /* Success Order Screen */
            <div className="text-center py-6 px-2 animate-in zoom-in-95">
              <div className="w-12 h-12 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center mx-auto mb-2 text-xl">
                ✓
              </div>
              <h4 className="text-sm font-bold text-white mb-1">تم تجهيز الطلب بنجاح!</h4>
              <p className="text-[11px] text-slate-400 mb-3">
                تم إنشاء نص الفاتورة التلقائي وجاهز للإرسال إلى واتساب التاجر مباشرة دون عمولات بنكية.
              </p>

              <div className="p-2.5 bg-slate-950 border border-emerald-500/20 rounded-xl text-[10px] font-mono text-slate-300 text-right whitespace-pre-line mb-3">
                {formatWhatsAppOrder()}
              </div>

              <button
                onClick={() => {
                  setView('catalog');
                  setCart({});
                }}
                className="w-full py-2 bg-slate-800 text-slate-300 text-xs rounded-xl hover:text-white"
              >
                العودة للمتجر وطلب جديد
              </button>
            </div>
          )}
        </div>

        {/* Footer / Checkout Button */}
        <div className="p-3 bg-slate-950 border-t border-slate-800/80">
          {view === 'catalog' ? (
            <button
              onClick={() => setView('cart')}
              className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl shadow-lg shadow-emerald-600/30 flex items-center justify-between px-4 active:scale-95 transition-transform"
            >
              <span>عرض السلة ({totalItems})</span>
              <span className="font-mono text-sm">{totalPrice} ر.س 🛒</span>
            </button>
          ) : view === 'cart' ? (
            <button
              onClick={submitOrder}
              disabled={totalItems === 0}
              className={`w-full py-3 rounded-xl font-bold text-xs flex items-center justify-center gap-2 ${
                totalItems > 0
                  ? 'bg-green-600 hover:bg-green-500 text-white shadow-lg shadow-green-600/30 active:scale-95'
                  : 'bg-slate-800 text-slate-500 cursor-not-allowed'
              }`}
            >
              <MessageSquare className="w-4 h-4" />
              <span>إرسال الطلب لواتساب ({totalPrice} ر.س)</span>
            </button>
          ) : null}
        </div>

        {/* Android Bottom Navigation */}
        <div className="py-2.5 bg-slate-950 flex justify-center items-center gap-12 text-slate-600 z-20">
          <div className="w-3.5 h-3.5 border-2 border-slate-600 rounded-sm" />
          <div className="w-3.5 h-3.5 border-2 border-slate-600 rounded-full" />
          <div className="w-0 h-0 border-y-4 border-y-transparent border-r-6 border-r-slate-600" />
        </div>
      </div>
    </div>
  );
};
