import React, { useState, useEffect } from 'react';
import { playSound } from '../../utils/audio';
import confetti from 'canvas-confetti';
import { Check, Plus, Trash2, Flame, Award, Calendar, Sparkles, Star } from 'lucide-react';

interface HabitItem {
  id: string;
  title: string;
  icon: string;
  streak: number;
  completedToday: boolean;
  category: string;
}

const DEFAULT_HABITS: HabitItem[] = [
  { id: '1', title: 'قراءة ورد القرآن أو كتاب', icon: '📖', streak: 4, completedToday: false, category: 'تطوير' },
  { id: '2', title: 'شرب 2 لتر ماء', icon: '💧', streak: 7, completedToday: true, category: 'صحة' },
  { id: '3', title: 'مشي أو تمارين 20 دقيقة', icon: '🏃‍♂️', streak: 2, completedToday: false, category: 'رياضة' },
  { id: '4', title: 'أذكار الصباح والمساء', icon: '🤲', streak: 12, completedToday: true, category: 'روحانية' }
];

export const HabitAppSimulator: React.FC = () => {
  const [habits, setHabits] = useState<HabitItem[]>(() => {
    const saved = localStorage.getItem('khotwa_habits');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        return DEFAULT_HABITS;
      }
    }
    return DEFAULT_HABITS;
  });

  const [newTitle, setNewTitle] = useState('');
  const [selectedIcon, setSelectedIcon] = useState('⭐');
  const [showAddModal, setShowAddModal] = useState(false);
  const [activeTab, setActiveTab] = useState<'today' | 'stats'>('today');

  useEffect(() => {
    localStorage.setItem('khotwa_habits', JSON.stringify(habits));
  }, [habits]);

  const toggleHabit = (id: string) => {
    setHabits((prev) =>
      prev.map((h) => {
        if (h.id === id) {
          const nextCompleted = !h.completedToday;
          if (nextCompleted) {
            playSound('success');
            confetti({
              particleCount: 35,
              spread: 50,
              origin: { y: 0.6 }
            });
          } else {
            playSound('click');
          }
          return {
            ...h,
            completedToday: nextCompleted,
            streak: nextCompleted ? h.streak + 1 : Math.max(0, h.streak - 1)
          };
        }
        return h;
      })
    );
  };

  const addHabit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    const newHabit: HabitItem = {
      id: Date.now().toString(),
      title: newTitle.trim(),
      icon: selectedIcon,
      streak: 1,
      completedToday: true,
      category: 'عام'
    };

    setHabits([newHabit, ...habits]);
    setNewTitle('');
    setShowAddModal(false);
    playSound('coin');
    confetti({
      particleCount: 40,
      spread: 60,
      origin: { y: 0.5 }
    });
  };

  const deleteHabit = (id: string) => {
    setHabits(habits.filter((h) => h.id !== id));
    playSound('click');
  };

  const completedCount = habits.filter((h) => h.completedToday).length;
  const progressPercent = habits.length > 0 ? Math.round((completedCount / habits.length) * 100) : 0;
  const totalStreaks = habits.reduce((acc, curr) => acc + curr.streak, 0);

  return (
    <div className="flex flex-col items-center w-full">
      {/* Mobile Frame Container */}
      <div className="relative w-full max-w-[340px] sm:max-w-[360px] bg-slate-900 border-4 border-slate-700/80 rounded-[38px] shadow-2xl shadow-indigo-500/10 overflow-hidden select-none min-h-[580px] flex flex-col justify-between">
        {/* Android Top Speaker Notch */}
        <div className="absolute top-2 left-1/2 -translate-x-1/2 w-24 h-4 bg-slate-950 rounded-full z-30 flex items-center justify-center">
          <div className="w-8 h-1.5 bg-slate-800 rounded-full" />
          <div className="w-2.5 h-2.5 bg-slate-900 border border-slate-700 rounded-full ml-3" />
        </div>

        {/* Android Status Bar */}
        <div className="relative pt-6 px-5 pb-2 bg-slate-950/90 text-xs text-slate-300 flex justify-between items-center z-20 font-mono">
          <div className="flex items-center gap-1.5 font-bold">
            <span>09:30</span>
            <span className="text-[10px] text-indigo-400">5G</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-[10px] text-slate-400">🔋 88%</span>
          </div>
        </div>

        {/* App Header */}
        <div className="px-5 py-3 bg-gradient-to-b from-indigo-950/60 to-slate-900 border-b border-indigo-900/30">
          <div className="flex items-center justify-between mb-2">
            <div>
              <div className="text-[11px] text-indigo-300 flex items-center gap-1 font-semibold">
                <Calendar className="w-3 h-3" />
                <span>اليوم، {new Date().toLocaleDateString('ar-EG', { weekday: 'long', day: 'numeric', month: 'short' })}</span>
              </div>
              <h2 className="text-lg font-black text-white font-heading">تطبيق خطوة 🚀</h2>
            </div>
            
            <div className="flex items-center gap-1.5 bg-indigo-500/20 border border-indigo-500/30 px-2.5 py-1 rounded-xl">
              <Flame className="w-4 h-4 text-amber-400 fill-amber-400 animate-pulse" />
              <span className="text-xs font-mono font-bold text-amber-300">{totalStreaks} يوم</span>
            </div>
          </div>

          {/* Progress Bar Card */}
          <div className="bg-slate-950/60 border border-indigo-500/20 rounded-2xl p-3">
            <div className="flex items-center justify-between text-xs mb-1.5">
              <span className="text-slate-300 font-semibold">إنجاز اليوم</span>
              <span className="text-indigo-400 font-bold font-mono">{progressPercent}%</span>
            </div>
            <div className="w-full h-2.5 bg-slate-800 rounded-full overflow-hidden p-0.5">
              <div
                className="h-full bg-gradient-to-r from-indigo-500 via-purple-500 to-emerald-400 rounded-full transition-all duration-500"
                style={{ width: `${progressPercent}%` }}
              />
            </div>
            <div className="text-[10px] text-slate-400 mt-1.5 flex justify-between">
              <span>{completedCount} من {habits.length} مكتملة</span>
              {progressPercent === 100 && (
                <span className="text-emerald-400 font-bold">أحسنت! أتممت مهام اليوم 🎉</span>
              )}
            </div>
          </div>
        </div>

        {/* Tab Switcher */}
        <div className="flex border-b border-slate-800 bg-slate-950/40 px-5 pt-2">
          <button
            onClick={() => setActiveTab('today')}
            className={`pb-2 text-xs font-bold transition-colors border-b-2 flex-1 text-center ${
              activeTab === 'today'
                ? 'border-indigo-500 text-indigo-400'
                : 'border-transparent text-slate-400 hover:text-slate-300'
            }`}
          >
            عاداتي النشطة
          </button>
          <button
            onClick={() => setActiveTab('stats')}
            className={`pb-2 text-xs font-bold transition-colors border-b-2 flex-1 text-center ${
              activeTab === 'stats'
                ? 'border-indigo-500 text-indigo-400'
                : 'border-transparent text-slate-400 hover:text-slate-300'
            }`}
          >
            الإحصائيات والتحفيز
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 p-4 overflow-y-auto max-h-[300px]">
          {activeTab === 'today' ? (
            <div className="space-y-2.5">
              {habits.map((habit) => (
                <div
                  key={habit.id}
                  onClick={() => toggleHabit(habit.id)}
                  className={`p-3 rounded-2xl border transition-all cursor-pointer flex items-center justify-between gap-3 ${
                    habit.completedToday
                      ? 'bg-emerald-950/20 border-emerald-500/40 text-slate-200'
                      : 'bg-slate-950/70 border-slate-800/80 hover:border-slate-700 text-slate-300'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <button
                      className={`w-7 h-7 rounded-xl flex items-center justify-center transition-all ${
                        habit.completedToday
                          ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/30'
                          : 'border-2 border-slate-600 bg-slate-900 text-transparent'
                      }`}
                    >
                      <Check className="w-4 h-4 stroke-[3]" />
                    </button>
                    <div>
                      <div className="flex items-center gap-1.5 font-bold text-sm">
                        <span>{habit.icon}</span>
                        <span className={habit.completedToday ? 'line-through text-slate-400' : ''}>
                          {habit.title}
                        </span>
                      </div>
                      <div className="text-[10px] text-slate-500 mt-0.5">
                        فئة: {habit.category}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <div className="flex items-center gap-0.5 text-xs text-amber-400 font-mono font-bold bg-amber-500/10 px-1.5 py-0.5 rounded-md border border-amber-500/20">
                      <span>🔥</span>
                      <span>{habit.streak}</span>
                    </div>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        deleteHabit(habit.id);
                      }}
                      className="p-1 text-slate-600 hover:text-rose-400 rounded transition-colors"
                      title="حذف"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}

              {habits.length === 0 && (
                <div className="text-center py-8 text-slate-500 text-xs">
                  لا توجد عادات مسجلة حالياً. اضغط الزر بالأسفل لإضافة أول عادة!
                </div>
              )}
            </div>
          ) : (
            /* Stats Tab */
            <div className="space-y-3 animate-in fade-in">
              <div className="bg-indigo-950/30 border border-indigo-500/20 rounded-2xl p-3 text-center">
                <Award className="w-8 h-8 text-amber-400 mx-auto mb-1" />
                <h4 className="text-xs font-bold text-white mb-0.5">شارة الالتزام الأسبوعي</h4>
                <p className="text-[10px] text-slate-400">حافظ على استمرارية عاداتك لـ 7 أيام لترقية حسابك للمستوى الفضي!</p>
              </div>

              <div className="grid grid-cols-2 gap-2 text-center">
                <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
                  <div className="text-base font-black text-emerald-400 font-mono">{completedCount}</div>
                  <div className="text-[10px] text-slate-400">عادات منجزة اليوم</div>
                </div>
                <div className="bg-slate-950 p-2.5 rounded-xl border border-slate-800">
                  <div className="text-base font-black text-amber-400 font-mono">{totalStreaks}</div>
                  <div className="text-[10px] text-slate-400">إجمالي أيام الستريك</div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Add Habit Modal or Float Button */}
        <div className="p-4 bg-slate-950 border-t border-slate-800/80">
          {showAddModal ? (
            <form onSubmit={addHabit} className="space-y-2 animate-in slide-in-from-bottom-2">
              <input
                type="text"
                placeholder="اسم العادة الجديدة (مثلاً: رياضة الصباح)..."
                value={newTitle}
                onChange={(e) => setNewTitle(e.target.value)}
                autoFocus
                className="w-full bg-slate-900 border border-indigo-500/40 rounded-xl px-3 py-2 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-indigo-400"
              />
              <div className="flex items-center justify-between">
                <div className="flex gap-1.5">
                  {['⭐', '📖', '💧', '🏃‍♂️', '🎯', '💡'].map((emoji) => (
                    <button
                      key={emoji}
                      type="button"
                      onClick={() => setSelectedIcon(emoji)}
                      className={`w-7 h-7 rounded-lg text-sm flex items-center justify-center ${
                        selectedIcon === emoji ? 'bg-indigo-600 scale-110' : 'bg-slate-800'
                      }`}
                    >
                      {emoji}
                    </button>
                  ))}
                </div>
                <div className="flex gap-1.5">
                  <button
                    type="button"
                    onClick={() => setShowAddModal(false)}
                    className="px-2.5 py-1 text-xs text-slate-400 hover:text-white"
                  >
                    إلغاء
                  </button>
                  <button
                    type="submit"
                    className="px-3 py-1 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-bold"
                  >
                    إضافة
                  </button>
                </div>
              </div>
            </form>
          ) : (
            <button
              onClick={() => {
                setShowAddModal(true);
                playSound('click');
              }}
              className="w-full py-3 bg-indigo-600 hover:bg-indigo-500 active:bg-indigo-700 text-white font-bold text-xs rounded-xl shadow-lg shadow-indigo-600/30 flex items-center justify-center gap-1.5 transition-transform active:scale-95"
            >
              <Plus className="w-4 h-4" />
              <span>إضافة عادة جديدة لليوم</span>
            </button>
          )}
        </div>

        {/* Android Bottom Navigation Bar */}
        <div className="py-2.5 bg-slate-950 flex justify-center items-center gap-12 text-slate-600 z-20">
          <div className="w-3.5 h-3.5 border-2 border-slate-600 rounded-sm" />
          <div className="w-3.5 h-3.5 border-2 border-slate-600 rounded-full" />
          <div className="w-0 h-0 border-y-4 border-y-transparent border-r-6 border-r-slate-600" />
        </div>
      </div>

      <div className="mt-3 text-xs text-slate-400 text-center flex items-center gap-1">
        <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
        <span>تطبيق تفاعلي حقيقي متصل بذاكرة الهاتف LocalStorage مع دعم الاحتفال والأصوات.</span>
      </div>
    </div>
  );
};
