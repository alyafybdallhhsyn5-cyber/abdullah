import React, { useState, useEffect } from 'react';
import { playSound } from '../../utils/audio';
import confetti from 'canvas-confetti';
import { Timer, Award, CheckCircle2, XCircle, RotateCcw, HelpCircle } from 'lucide-react';

interface Question {
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

const QUESTIONS: Question[] = [
  {
    question: 'ما هي عاصمة دولة سلطنة عُمان؟',
    options: ['صلالة', 'مسقط', 'صحار', 'نزوى'],
    correctIndex: 1,
    explanation: 'مسقط هي العاصمة والمركز السياسي والاقتصادي لسلطنة عُمان.'
  },
  {
    question: 'ما هو الكوكب الأقرب إلى الشمس في مجموعتنا الشمسية؟',
    options: ['المريخ', 'الزهرة', 'عطارد', 'المشتري'],
    correctIndex: 2,
    explanation: 'عطارد هو أقرب كوكب إلى الشمس وأصغر كواكب المجموعة.'
  },
  {
    question: 'كم عدد الدول العربية في قارة إفريقيا؟',
    options: ['10 دول', '8 دول', '12 دولة', '6 دول'],
    correctIndex: 0,
    explanation: 'تضم القارة الإفريقية 10 دول عربية بينها مصر والجزائر والمغرب والسودان.'
  },
  {
    question: 'من هو العالم العربي الملقب بـ "أبو الكيمياء"؟',
    options: ['ابن سينا', 'جابر بن حيان', 'الخوارزمي', 'ابن الهيثم'],
    correctIndex: 1,
    explanation: 'جابر بن حيان هو مؤسس علم الكيمياء الحديث والتجارب المعملية.'
  }
];

export const TriviaGameSimulator: React.FC = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);
  const [score, setScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(15);
  const [gameOver, setGameOver] = useState(false);
  const [eliminatedOptions, setEliminatedOptions] = useState<number[]>([]);
  const [usedLifeline, setUsedLifeline] = useState(false);

  useEffect(() => {
    if (gameOver || isAnswered) return;

    if (timeLeft <= 0) {
      handleTimeout();
      return;
    }

    const timer = setInterval(() => {
      setTimeLeft((t) => t - 1);
    }, 1000);

    return () => clearInterval(timer);
  }, [timeLeft, isAnswered, gameOver]);

  const handleTimeout = () => {
    setIsAnswered(true);
    playSound('gameover');
  };

  const handleSelect = (index: number) => {
    if (isAnswered) return;
    setSelectedAnswer(index);
    setIsAnswered(true);

    const isCorrect = index === QUESTIONS[currentIndex].correctIndex;
    if (isCorrect) {
      playSound('success');
      setScore((s) => s + 10 + timeLeft);
      confetti({
        particleCount: 30,
        spread: 45,
        origin: { y: 0.6 }
      });
    } else {
      playSound('gameover');
    }
  };

  const handleNext = () => {
    if (currentIndex + 1 < QUESTIONS.length) {
      setCurrentIndex((c) => c + 1);
      setSelectedAnswer(null);
      setIsAnswered(false);
      setTimeLeft(15);
      setEliminatedOptions([]);
      playSound('click');
    } else {
      setGameOver(true);
      playSound('level');
    }
  };

  const restartQuiz = () => {
    setCurrentIndex(0);
    setSelectedAnswer(null);
    setIsAnswered(false);
    setScore(0);
    setTimeLeft(15);
    setGameOver(false);
    setEliminatedOptions([]);
    setUsedLifeline(false);
    playSound('click');
  };

  const useFiftyFifty = () => {
    if (usedLifeline || isAnswered) return;
    const currentQ = QUESTIONS[currentIndex];
    const wrongIndices = [0, 1, 2, 3].filter((idx) => idx !== currentQ.correctIndex);
    const toEliminate = wrongIndices.sort(() => 0.5 - Math.random()).slice(0, 2);
    setEliminatedOptions(toEliminate);
    setUsedLifeline(true);
    playSound('coin');
  };

  const currentQ = QUESTIONS[currentIndex];

  return (
    <div className="flex flex-col items-center w-full">
      <div className="relative w-full max-w-[340px] sm:max-w-[360px] bg-slate-900 border-4 border-slate-700/80 rounded-[38px] shadow-2xl shadow-purple-500/10 overflow-hidden select-none min-h-[580px] flex flex-col justify-between">
        {/* Notch */}
        <div className="absolute top-2 left-1/2 -translate-x-1/2 w-24 h-4 bg-slate-950 rounded-full z-30 flex items-center justify-center">
          <div className="w-8 h-1.5 bg-slate-800 rounded-full" />
          <div className="w-2.5 h-2.5 bg-slate-900 border border-slate-700 rounded-full ml-3" />
        </div>

        {/* Status Bar */}
        <div className="relative pt-6 px-5 pb-2 bg-slate-950/90 text-xs text-slate-300 flex justify-between items-center z-20 font-mono">
          <span className="font-bold">14:15</span>
          <span className="text-[10px] text-purple-400">⚡ 99%</span>
        </div>

        {/* Quiz Top Bar */}
        <div className="px-5 py-3 bg-gradient-to-b from-purple-950/50 to-slate-900 border-b border-purple-900/30 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-xs bg-purple-500/20 text-purple-300 px-2 py-0.5 rounded-lg border border-purple-500/30 font-bold">
              سؤال {currentIndex + 1} / {QUESTIONS.length}
            </span>
            <div className="flex items-center gap-1 text-xs text-amber-400 font-bold font-mono">
              <Award className="w-3.5 h-3.5" />
              <span>{score} نقطة</span>
            </div>
          </div>

          <div className={`flex items-center gap-1 text-xs font-mono font-bold px-2 py-0.5 rounded-lg ${
            timeLeft <= 5 ? 'bg-rose-500/20 text-rose-400 animate-pulse' : 'bg-slate-800 text-slate-300'
          }`}>
            <Timer className="w-3.5 h-3.5" />
            <span>{timeLeft} ث</span>
          </div>
        </div>

        {/* Body Content */}
        <div className="flex-1 p-4 flex flex-col justify-center">
          {!gameOver ? (
            <div className="space-y-4">
              {/* Question Card */}
              <div className="bg-slate-950/80 border border-purple-500/30 rounded-2xl p-4 shadow-lg text-center">
                <h3 className="text-base font-bold text-white leading-relaxed font-heading">
                  {currentQ.question}
                </h3>
              </div>

              {/* Options */}
              <div className="grid grid-cols-1 gap-2">
                {currentQ.options.map((opt, idx) => {
                  const isEliminated = eliminatedOptions.includes(idx);
                  if (isEliminated) {
                    return (
                      <div
                        key={idx}
                        className="py-3 px-4 rounded-xl border border-dashed border-slate-800 bg-slate-950/20 text-slate-600 text-xs text-center line-through"
                      >
                        (تم استبعاد الخيار ✂️)
                      </div>
                    );
                  }

                  let btnStyle = 'bg-slate-950 border-slate-800 text-slate-200 hover:border-purple-500/50';

                  if (isAnswered) {
                    if (idx === currentQ.correctIndex) {
                      btnStyle = 'bg-emerald-950/70 border-emerald-500 text-emerald-300 font-bold';
                    } else if (idx === selectedAnswer) {
                      btnStyle = 'bg-rose-950/70 border-rose-500 text-rose-300 font-bold';
                    } else {
                      btnStyle = 'bg-slate-950/40 border-slate-800/40 text-slate-500';
                    }
                  }

                  return (
                    <button
                      key={idx}
                      onClick={() => handleSelect(idx)}
                      disabled={isAnswered}
                      className={`py-3 px-4 rounded-xl border text-xs text-right transition-all flex items-center justify-between ${btnStyle}`}
                    >
                      <span>{opt}</span>
                      {isAnswered && idx === currentQ.correctIndex && (
                        <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                      )}
                      {isAnswered && idx === selectedAnswer && idx !== currentQ.correctIndex && (
                        <XCircle className="w-4 h-4 text-rose-400 shrink-0" />
                      )}
                    </button>
                  );
                })}
              </div>

              {/* Explanation note if answered */}
              {isAnswered && (
                <div className="p-3 bg-purple-950/30 border border-purple-500/20 rounded-xl text-xs text-slate-300 animate-in fade-in">
                  <span className="font-bold text-purple-300">معلومة: </span>
                  {currentQ.explanation}
                </div>
              )}
            </div>
          ) : (
            /* Game Over Screen */
            <div className="text-center p-4 bg-slate-950/80 border border-purple-500/30 rounded-2xl">
              <div className="text-4xl mb-2">🎉</div>
              <h3 className="text-lg font-black text-white font-heading mb-1">اكتمل التحدي المعرفي!</h3>
              <p className="text-xs text-slate-400 mb-3">لقد جمعت رصيداً ممتازاً من النقاط والمعلومات</p>
              
              <div className="bg-purple-950/40 border border-purple-500/30 rounded-xl p-3 mb-4">
                <div className="text-[11px] text-purple-300">مجموع النقاط النهائي</div>
                <div className="text-3xl font-black text-amber-400 font-mono mt-0.5">{score}</div>
              </div>

              <button
                onClick={restartQuiz}
                className="w-full py-3 bg-purple-600 hover:bg-purple-500 text-white font-bold rounded-xl text-xs flex items-center justify-center gap-1.5"
              >
                <RotateCcw className="w-4 h-4" />
                <span>إعادة خوض التحدي</span>
              </button>
            </div>
          )}
        </div>

        {/* Bottom Actions */}
        <div className="p-4 bg-slate-950 border-t border-slate-800/80 flex items-center justify-between gap-2">
          {!gameOver && !isAnswered ? (
            <button
              onClick={useFiftyFifty}
              disabled={usedLifeline}
              className={`flex-1 py-2.5 rounded-xl text-xs font-bold border flex items-center justify-center gap-1 transition-colors ${
                usedLifeline
                  ? 'border-slate-800 text-slate-600 cursor-not-allowed'
                  : 'border-amber-500/30 bg-amber-500/10 text-amber-300 hover:bg-amber-500/20'
              }`}
            >
              <HelpCircle className="w-3.5 h-3.5" />
              <span>مساعدة 50:50 {usedLifeline ? '(مستخدمة)' : ''}</span>
            </button>
          ) : !gameOver && isAnswered ? (
            <button
              onClick={handleNext}
              className="w-full py-3 bg-purple-600 hover:bg-purple-500 text-white font-bold rounded-xl text-xs transition-colors flex items-center justify-center gap-1"
            >
              <span>السؤال التالي ➡️</span>
            </button>
          ) : null}
        </div>

        {/* Android Bottom Navigation */}
        <div className="py-2.5 bg-slate-950 flex justify-center items-center gap-12 text-slate-600 z-20">
          <div className="w-3.5 h-3.5 border-2 border-slate-600 rounded-sm" />
          <div className="w-3.5 h-3.5 border-2 border-slate-600 rounded-full" />
          <div className="w-0 h-0 border-y-4 border-y-transparent border-r-6 border-r-slate-600" />
        </div>
      </div>
    </div>
  );
};
