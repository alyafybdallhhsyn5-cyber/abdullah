import React, { useState } from 'react';
import { Country } from '../types/history';
import { BILATERAL_RELATIONS_DATA, getBilateralRelation } from '../data/bilateralRelations';
import { playSound } from '../utils/audio';
import { HeartHandshake, Calendar, FileText, Globe, Landmark, TrendingUp, Sparkles, CheckCircle2, ArrowLeftRight, Users } from 'lucide-react';

interface Props {
  countries: Country[];
}

export const RelationsSection: React.FC<Props> = ({ countries }) => {
  // Default to Saudi Arabia and Yemen as specifically requested by user!
  const [selectedCountryA, setSelectedCountryA] = useState('saudi');
  const [selectedCountryB, setSelectedCountryB] = useState('yemen');

  const countryA = countries.find((c) => c.id === selectedCountryA) || countries[0];
  const countryB = countries.find((c) => c.id === selectedCountryB) || countries[1];

  const relation = getBilateralRelation(selectedCountryA, selectedCountryB);

  const handleSelectQuickPair = (idA: string, idB: string) => {
    setSelectedCountryA(idA);
    setSelectedCountryB(idB);
    playSound('coin');
  };

  return (
    <div className="space-y-6 text-right animate-in fade-in">
      {/* Hero Header */}
      <div className="bg-gradient-to-br from-slate-900 via-slate-950 to-slate-900 border border-amber-500/30 rounded-3xl p-6 sm:p-8 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-80 h-80 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 space-y-3">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-300 text-xs font-semibold">
            <HeartHandshake className="w-4 h-4 text-amber-400" />
            <span>قسم العلاقات الثنائية والتاريخ المشترك بين الدول</span>
          </div>

          <h2 className="text-2xl sm:text-3xl font-black text-white font-heading">
            سجل العلاقات والمحطات التاريخية والروابط الأخوية
          </h2>

          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed max-w-3xl">
            استكشف تاريخ العلاقات الدبلوماسية، الاتفاقيات، المعاهدات الحدودية، الروابط القبلية والشعبية، والتعاون الاقتصادي والمصير المشترك بين أي دولتين في الشرق الأوسط.
          </p>

          {/* Quick Preset Pairs */}
          <div className="pt-2 flex flex-wrap items-center gap-2">
            <span className="text-xs text-slate-400 font-semibold">علاقات مميزة:</span>
            {[
              { idA: 'saudi', idB: 'yemen', label: 'السعودية واليمن 🇸🇦 🇾🇪' },
              { idA: 'saudi', idB: 'syria', label: 'السعودية وسوريا 🇸🇦 🇸🇾' },
              { idA: 'egypt', idB: 'syria', label: 'مصر وسوريا 🇪🇬 🇸🇾' },
              { idA: 'saudi', idB: 'egypt', label: 'السعودية ومصر 🇸🇦 🇪🇬' },
              { idA: 'saudi', idB: 'uae', label: 'السعودية والإمارات 🇸🇦 🇦🇪' },
              { idA: 'egypt', idB: 'palestine', label: 'مصر وفلسطين 🇪🇬 🇵🇸' },
              { idA: 'saudi', idB: 'oman', label: 'السعودية وعُمان 🇸🇦 🇴🇲' },
              { idA: 'kuwait', idB: 'saudi', label: 'الكويت والسعودية 🇰🇼 🇸🇦' },
              { idA: 'jordan', idB: 'palestine', label: 'الأردن وفلسطين 🇯🇴 🇵🇸' },
              { idA: 'iraq', idB: 'syria', label: 'العراق وسوريا 🇮🇶 🇸🇾' },
            ].map((pair, idx) => {
              const isSelected =
                (selectedCountryA === pair.idA && selectedCountryB === pair.idB) ||
                (selectedCountryA === pair.idB && selectedCountryB === pair.idA);
              return (
                <button
                  key={idx}
                  onClick={() => handleSelectQuickPair(pair.idA, pair.idB)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all border ${
                    isSelected
                      ? 'bg-amber-500 text-slate-950 border-amber-400 shadow-md shadow-amber-500/20'
                      : 'bg-slate-950/80 border-slate-800 text-slate-300 hover:text-white hover:border-slate-700'
                  }`}
                >
                  {pair.label}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Country Selectors Box */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 shadow-lg">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 items-center">
          <div>
            <label className="text-xs text-slate-400 block mb-1.5 font-semibold">الدولة الأولى:</label>
            <div className="relative">
              <select
                value={selectedCountryA}
                onChange={(e) => {
                  setSelectedCountryA(e.target.value);
                  playSound('click');
                }}
                className="w-full bg-slate-950 border border-slate-700 rounded-2xl px-4 py-3 text-sm text-white focus:outline-none focus:border-amber-500 transition-colors cursor-pointer appearance-none text-right font-heading"
              >
                {countries.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.flag} {c.name}
                  </option>
                ))}
              </select>
              <span className="absolute left-4 top-1/2 -translate-y-1/2 text-lg pointer-events-none">
                {countryA.flag}
              </span>
            </div>
          </div>

          <div>
            <label className="text-xs text-slate-400 block mb-1.5 font-semibold">الدولة الثانية:</label>
            <div className="relative">
              <select
                value={selectedCountryB}
                onChange={(e) => {
                  setSelectedCountryB(e.target.value);
                  playSound('click');
                }}
                className="w-full bg-slate-950 border border-slate-700 rounded-2xl px-4 py-3 text-sm text-white focus:outline-none focus:border-amber-500 transition-colors cursor-pointer appearance-none text-right font-heading"
              >
                {countries.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.flag} {c.name}
                  </option>
                ))}
              </select>
              <span className="absolute left-4 top-1/2 -translate-y-1/2 text-lg pointer-events-none">
                {countryB.flag}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Relation Details */}
      {relation ? (
        <div className="space-y-6 animate-in fade-in">
          {/* Header Banner between Countries */}
          <div className="p-6 rounded-3xl bg-gradient-to-r from-amber-500/10 via-slate-900 to-amber-500/10 border border-amber-500/30 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2 text-4xl sm:text-5xl">
                <span>{countryA.flag}</span>
                <HeartHandshake className="w-6 h-6 text-amber-400" />
                <span>{countryB.flag}</span>
              </div>

              <div>
                <span className="text-[11px] text-amber-400 font-bold bg-amber-500/10 px-2.5 py-0.5 rounded-full border border-amber-500/20">
                  {relation.nature}
                </span>
                <h3 className="text-xl sm:text-2xl font-black text-white font-heading mt-1">
                  {relation.title}
                </h3>
              </div>
            </div>

            <div className="text-xs text-slate-400 font-mono bg-slate-950 px-3 py-1.5 rounded-xl border border-slate-800">
              {relation.sharedEvents.length} محطات تاريخية مشتركة
            </div>
          </div>

          {/* Overview & Historical Depth */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 space-y-2">
              <div className="flex items-center gap-2 text-amber-400 font-bold text-sm font-heading">
                <Globe className="w-4 h-4" />
                <span>الموجز العام للعلاقات الثنائية</span>
              </div>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                {relation.summary}
              </p>
            </div>

            <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 space-y-2">
              <div className="flex items-center gap-2 text-emerald-400 font-bold text-sm font-heading">
                <Landmark className="w-4 h-4" />
                <span>العمق التاريخي والجذور الممتدة</span>
              </div>
              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                {relation.historicalDepth}
              </p>
            </div>
          </div>

          {/* Cultural & Geographic Ties */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5">
            <h4 className="text-base font-bold text-white font-heading mb-3 flex items-center gap-2">
              <Users className="w-4 h-4 text-purple-400" />
              <span>الروابط الجغرافية والاجتماعية والشعبية:</span>
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {relation.geographicCulturalTies.map((tie, idx) => (
                <div
                  key={idx}
                  className="p-3 bg-slate-950/80 border border-slate-800/80 rounded-xl flex items-start gap-2.5 text-xs text-slate-200"
                >
                  <CheckCircle2 className="w-4 h-4 text-purple-400 shrink-0 mt-0.5" />
                  <span className="leading-relaxed">{tie}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Key Treaties and Accords */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5">
            <h4 className="text-base font-bold text-white font-heading mb-3 flex items-center gap-2">
              <FileText className="w-4 h-4 text-sky-400" />
              <span>أبرز الاتفاقيات والمعاهدات والمحطات الرسمية:</span>
            </h4>
            <div className="space-y-2">
              {relation.keyTreatiesAndAgreements.map((treaty, idx) => (
                <div
                  key={idx}
                  className="p-3 bg-slate-950/80 border border-slate-800/80 rounded-xl flex items-start gap-3 text-xs text-slate-200"
                >
                  <span className="w-5 h-5 rounded-md bg-sky-500/20 text-sky-300 border border-sky-500/30 flex items-center justify-center font-mono font-bold shrink-0 text-[10px]">
                    {idx + 1}
                  </span>
                  <span className="leading-relaxed font-medium">{treaty}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Economic Cooperation */}
          <div className="bg-gradient-to-br from-emerald-950/20 via-slate-900 to-slate-950 border border-emerald-500/30 rounded-2xl p-5">
            <div className="flex items-center gap-2 text-emerald-400 font-bold text-sm mb-2 font-heading">
              <TrendingUp className="w-4 h-4" />
              <span>التعاون الاقتصادي والمشاريع التنموية المشتركة</span>
            </div>
            <p className="text-xs sm:text-sm text-slate-200 leading-relaxed">
              {relation.economicCooperation}
            </p>
          </div>

          {/* Shared Timeline of Events between the two countries */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5">
            <h4 className="text-base font-bold text-white font-heading mb-4 flex items-center gap-2">
              <Calendar className="w-4 h-4 text-amber-400" />
              <span>الجدول الزمني للأحداث والمواقف المشتركة بين البلدين:</span>
            </h4>

            <div className="relative border-r-2 border-amber-500/30 pr-5 mr-3 space-y-4">
              {relation.sharedEvents.map((evt, idx) => (
                <div key={idx} className="relative group">
                  <div className="absolute -right-[27px] top-3.5 w-3.5 h-3.5 rounded-full bg-slate-950 border-2 border-amber-500 flex items-center justify-center">
                    <div className="w-1.5 h-1.5 rounded-full bg-amber-400" />
                  </div>

                  <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 hover:border-amber-500/40 transition-colors">
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="font-mono text-xs font-black text-amber-300 bg-amber-500/10 px-2.5 py-0.5 rounded-md border border-amber-500/20">
                        {evt.year}
                      </span>
                    </div>

                    <h5 className="text-sm font-bold text-white font-heading mb-1">
                      {evt.title}
                    </h5>

                    <p className="text-xs text-slate-300 leading-relaxed">
                      {evt.description}
                    </p>

                    <div className="mt-2.5 pt-2 border-t border-slate-800/80 text-[11px] text-amber-200/90 flex items-start gap-1.5">
                      <strong className="text-amber-400">الأثر والنتيجة:</strong>
                      <span>{evt.impact}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Modern & Recent Developments */}
          <div className="p-5 bg-gradient-to-r from-amber-950/30 via-slate-900 to-indigo-950/30 border border-amber-500/30 rounded-2xl text-xs sm:text-sm text-slate-200 leading-relaxed">
            <strong className="text-amber-300 font-heading block text-sm mb-1">
              ✨ التطورات والمستجدات الأخيرة ومسار المستقبل:
            </strong>
            {relation.modernDevelopments}
          </div>
        </div>
      ) : (
        /* Fallback when selected pair doesn't have a dedicated bilateral entry */
        <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-8 text-center space-y-4 animate-in fade-in">
          <div className="flex justify-center items-center gap-3 text-4xl">
            <span>{countryA.flag}</span>
            <ArrowLeftRight className="w-6 h-6 text-slate-500" />
            <span>{countryB.flag}</span>
          </div>

          <h3 className="text-lg font-bold text-white font-heading">
            العلاقات بين {countryA.name} و {countryB.name}
          </h3>

          <p className="text-xs sm:text-sm text-slate-300 max-w-xl mx-auto leading-relaxed">
            تجمع البلدين الشقيقين عضوية جامعة الدول العربية ومنظمة التعاون الإسلامي وتاريخ عريق من التضامن العربي والإسلامي والتنسيق الدبلوماسي المشترك.
          </p>

          <div className="pt-2">
            <button
              onClick={() => handleSelectQuickPair('saudi', 'yemen')}
              className="px-5 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black rounded-xl text-xs shadow-md transition-all"
            >
              استعراض العلاقات السعودية اليمنية 🇸🇦 🇾🇪
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
