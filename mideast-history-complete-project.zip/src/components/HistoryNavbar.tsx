import React, { useState } from 'react';
import { DESIGNER_INFO } from '../data/middleEastData';
import { DesignerBadge } from './DesignerBadge';
import { playSound, isSoundEnabled, setSoundEnabled } from '../utils/audio';
import { Compass, Volume2, VolumeX, Search, Smartphone, User as UserIcon, LogIn, Download } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext.tsx';
import { UserProfileModal } from './UserProfileModal.tsx';

interface Props {
  activeView: 'map' | 'countries' | 'relations' | 'wars' | 'quiz';
  onSelectView: (view: 'map' | 'countries' | 'relations' | 'wars' | 'quiz') => void;
  onOpenCompare: () => void;
  onOpenDesignerModal: () => void;
  onOpenInstallModal: () => void;
  isStandalone?: boolean;
  searchQuery: string;
  onSearchChange: (query: string) => void;
}

export const HistoryNavbar: React.FC<Props> = ({
  activeView,
  onSelectView,
  onOpenCompare,
  onOpenDesignerModal,
  onOpenInstallModal,
  isStandalone = false,
  searchQuery,
  onSearchChange
}) => {
  const [audioOn, setAudioOn] = useState(isSoundEnabled());
  const [isProfileModalOpen, setIsProfileModalOpen] = useState(false);
  const { user, signInWithGoogle } = useAuth();

  const toggleSound = () => {
    const next = !audioOn;
    setAudioOn(next);
    setSoundEnabled(next);
    if (next) playSound('click');
  };

  return (
    <header className="sticky top-0 z-40 w-full bg-slate-950/90 border-b border-slate-800/80 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between gap-4">
        {/* Zone 1: Brand Wordmark */}
        <div className="flex items-center gap-3 shrink-0">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-amber-500 to-amber-700 flex items-center justify-center text-slate-950 shadow-md shadow-amber-500/20">
            <Compass className="w-5 h-5 stroke-[2.5]" />
          </div>
          <div>
            <h1 className="text-base sm:text-lg font-black text-white font-heading tracking-wide whitespace-nowrap">
              تاريخ وحاضر الشرق الأوسط
            </h1>
          </div>
        </div>

        {/* Zone 2: Navigation Links (Single-Line) */}
        <nav className="hidden md:flex items-center gap-5 text-xs sm:text-sm font-semibold text-slate-300">
          <button
            onClick={() => {
              onSelectView('map');
              playSound('click');
            }}
            className={`whitespace-nowrap transition-colors py-1 ${
              activeView === 'map' ? 'text-amber-400 border-b-2 border-amber-400 font-bold' : 'hover:text-white'
            }`}
          >
            الخريطة التفاعلية
          </button>

          <button
            onClick={() => {
              onSelectView('countries');
              playSound('click');
            }}
            className={`whitespace-nowrap transition-colors py-1 ${
              activeView === 'countries' ? 'text-amber-400 border-b-2 border-amber-400 font-bold' : 'hover:text-white'
            }`}
          >
            دليل الدول
          </button>

          <button
            onClick={() => {
              onSelectView('relations');
              playSound('click');
            }}
            className={`whitespace-nowrap transition-colors py-1 flex items-center gap-1 ${
              activeView === 'relations' ? 'text-amber-400 border-b-2 border-amber-400 font-bold' : 'hover:text-white'
            }`}
          >
            <span>العلاقات والتاريخ المشترك</span>
            <span className="text-[10px] bg-amber-500/20 text-amber-300 px-1.5 py-0.2 rounded-full border border-amber-500/30">جديد</span>
          </button>

          <button
            onClick={() => {
              onSelectView('wars');
              playSound('click');
            }}
            className={`whitespace-nowrap transition-colors py-1 flex items-center gap-1 ${
              activeView === 'wars' ? 'text-amber-400 border-b-2 border-amber-400 font-bold' : 'hover:text-white'
            }`}
          >
            <span>الحروب والصراعات ⚔️</span>
            <span className="text-[10px] bg-red-500/20 text-red-300 px-1.5 py-0.2 rounded-full border border-red-500/30">شامل</span>
          </button>

          <button
            onClick={() => {
              onOpenCompare();
              playSound('click');
            }}
            className="whitespace-nowrap transition-colors py-1 hover:text-amber-300"
          >
            مقارنة الدول
          </button>

          <button
            onClick={() => {
              onSelectView('quiz');
              playSound('click');
            }}
            className={`whitespace-nowrap transition-colors py-1 ${
              activeView === 'quiz' ? 'text-amber-400 border-b-2 border-amber-400 font-bold' : 'hover:text-white'
            }`}
          >
            تحدي المؤرخ 🏆
          </button>
        </nav>

        {/* Zone 3: Designer Link, Auth, Install Button & Sound Action */}
        <div className="flex items-center gap-2 sm:gap-2.5 shrink-0">
          {/* User Account / Google Sign-In */}
          {user ? (
            <button
              onClick={() => {
                playSound('click');
                setIsProfileModalOpen(true);
              }}
              className="flex items-center gap-1.5 p-1 sm:px-2.5 sm:py-1 rounded-xl bg-slate-900 border border-amber-500/30 text-amber-300 hover:border-amber-500/60 transition-colors"
              title="الملف الشخصي والمحفوظات السحابية"
            >
              {user.photoURL ? (
                <img src={user.photoURL} alt="" className="w-5 h-5 rounded-full" />
              ) : (
                <UserIcon className="w-4 h-4" />
              )}
              <span className="hidden sm:inline text-xs font-bold max-w-[80px] truncate">
                {user.displayName?.split(' ')[0] || 'حسابي'}
              </span>
            </button>
          ) : (
            <button
              onClick={async () => {
                playSound('click');
                try {
                  await signInWithGoogle();
                } catch (e) {
                  console.error(e);
                }
              }}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 text-amber-400 text-xs font-bold transition-all"
              title="تسجيل الدخول لمزامنة وحفظ بياناتك"
            >
              <LogIn className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">دخول</span>
            </button>
          )}

          {/* Install as App Action (hidden automatically when already installed) */}
          {!isStandalone && (
            <button
              onClick={() => {
                playSound('click');
                onOpenInstallModal();
              }}
              className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-emerald-500/20 to-teal-500/20 hover:from-emerald-500/30 hover:to-teal-500/30 border border-emerald-500/40 text-emerald-300 text-xs font-bold transition-all shadow-sm"
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span>تثبيت كـ تطبيق 📱</span>
            </button>
          )}

          {/* Direct ZIP Project & Android Native Code Download Button */}
          <a
            href="/mideast-history-complete-project.zip"
            download="mideast-history-complete-project.zip"
            onClick={() => playSound('coin')}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-gradient-to-r from-emerald-500/20 via-teal-500/20 to-amber-500/20 hover:from-emerald-500/30 hover:to-amber-500/30 border border-emerald-500/40 text-emerald-300 text-xs font-black transition-all shadow-md shadow-emerald-500/10"
            title="تنزيل المشروع الكامل + كود أندرويد الأصلي بصيغة ZIP"
          >
            <Download className="w-3.5 h-3.5 text-emerald-400" />
            <span className="hidden sm:inline">تحميل كود المشروع الكامل (ZIP 💾)</span>
            <span className="sm:hidden">ZIP 💾</span>
          </a>

          {/* Prominent Designer Badge */}
          <DesignerBadge
            onOpenModal={onOpenDesignerModal}
            variant="nav"
          />

          {/* Sound Toggle Button */}
          <button
            onClick={toggleSound}
            className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-white transition-colors"
            title={audioOn ? 'كتم الصوت' : 'تشغيل الصوت'}
            aria-label="تبديل المؤثرات الصوتية"
          >
            {audioOn ? <Volume2 className="w-4 h-4 text-amber-400" /> : <VolumeX className="w-4 h-4 text-slate-500" />}
          </button>
        </div>
      </div>

      {/* Mobile Sub-Navigation Bar */}
      <div className="md:hidden flex items-center justify-around border-t border-slate-800/80 bg-slate-950/95 px-2 py-2 text-xs overflow-x-auto no-scrollbar">
        <button
          onClick={() => {
            onSelectView('map');
            playSound('click');
          }}
          className={`px-2.5 py-1.5 rounded-lg font-bold shrink-0 whitespace-nowrap ${
            activeView === 'map' ? 'bg-amber-500/20 text-amber-300' : 'text-slate-400'
          }`}
        >
          الخريطة
        </button>

        <button
          onClick={() => {
            onSelectView('countries');
            playSound('click');
          }}
          className={`px-2.5 py-1.5 rounded-lg font-bold shrink-0 whitespace-nowrap ${
            activeView === 'countries' ? 'bg-amber-500/20 text-amber-300' : 'text-slate-400'
          }`}
        >
          الدول
        </button>

        <button
          onClick={() => {
            onSelectView('relations');
            playSound('click');
          }}
          className={`px-2.5 py-1.5 rounded-lg font-bold shrink-0 whitespace-nowrap ${
            activeView === 'relations' ? 'bg-amber-500/20 text-amber-300' : 'text-slate-400'
          }`}
        >
          العلاقات 🤝
        </button>

        <button
          onClick={() => {
            onSelectView('wars');
            playSound('click');
          }}
          className={`px-2.5 py-1.5 rounded-lg font-bold shrink-0 whitespace-nowrap ${
            activeView === 'wars' ? 'bg-red-500/20 text-red-300 font-black' : 'text-slate-400'
          }`}
        >
          الحروب ⚔️
        </button>

        <button
          onClick={() => {
            onOpenCompare();
            playSound('click');
          }}
          className="px-2.5 py-1.5 rounded-lg text-slate-400 font-bold hover:text-white shrink-0 whitespace-nowrap"
        >
          مقارنة
        </button>

        <button
          onClick={() => {
            onSelectView('quiz');
            playSound('click');
          }}
          className={`px-2.5 py-1.5 rounded-lg font-bold shrink-0 whitespace-nowrap ${
            activeView === 'quiz' ? 'bg-amber-500/20 text-amber-300' : 'text-slate-400'
          }`}
        >
          التحدي 🏆
        </button>

        {!isStandalone && (
          <button
            onClick={() => {
              onOpenInstallModal();
              playSound('click');
            }}
            className="px-2.5 py-1.5 rounded-lg font-black shrink-0 whitespace-nowrap bg-emerald-500/25 text-emerald-300 border border-emerald-500/40"
          >
            تحويل لتطبيق 📱
          </button>
        )}
      </div>

      <UserProfileModal
        isOpen={isProfileModalOpen}
        onClose={() => setIsProfileModalOpen(false)}
      />
    </header>
  );
};
