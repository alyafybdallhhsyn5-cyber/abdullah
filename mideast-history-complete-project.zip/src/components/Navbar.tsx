import React, { useState } from 'react';
import { ProjectData } from '../types';
import { playSound, setSoundEnabled, isSoundEnabled } from '../utils/audio';
import { Rocket, Lightbulb, Volume2, VolumeX, FileText, Smartphone } from 'lucide-react';

interface Props {
  project: ProjectData;
  onOpenIdeaModal: () => void;
  onOpenReportModal: () => void;
}

export const Navbar: React.FC<Props> = ({ project, onOpenIdeaModal, onOpenReportModal }) => {
  const [audioActive, setAudioActive] = useState(isSoundEnabled());

  const toggleSound = () => {
    const next = !audioActive;
    setAudioActive(next);
    setSoundEnabled(next);
    if (next) playSound('click');
  };

  return (
    <header className="w-full bg-slate-950/90 border-b border-slate-800/80 sticky top-0 z-40 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between gap-3">
        {/* Brand */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-indigo-600 via-purple-600 to-amber-500 flex items-center justify-center text-white shadow-lg shadow-indigo-500/20">
            <Rocket className="w-5 h-5 fill-white" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-base sm:text-lg font-black text-white font-heading">
                مختبر صانع الألعاب والتطبيقات
              </h1>
              <span className="text-[10px] bg-amber-500/20 text-amber-300 border border-amber-500/30 px-2 py-0.5 rounded-full font-bold">
                أندرويد للمبتدئين
              </span>
            </div>
            <div className="text-xs text-slate-400 flex items-center gap-1.5 truncate max-w-[200px] sm:max-w-xs">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span className="text-slate-300 font-medium truncate">{project.title}</span>
            </div>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2">
          {/* Idea Switcher Button */}
          <button
            onClick={() => {
              onOpenIdeaModal();
              playSound('click');
            }}
            className="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 active:scale-95 text-white text-xs font-bold transition-all flex items-center gap-1.5 shadow-md shadow-indigo-600/20"
            title="تبديل أو إدخال فكرة جديدة"
          >
            <Lightbulb className="w-4 h-4 text-amber-300" />
            <span className="hidden sm:inline">أدخل فكرتك / غيّر المشروع</span>
            <span className="sm:hidden">الفكرة</span>
          </button>

          {/* Report Button */}
          <button
            onClick={() => {
              onOpenReportModal();
              playSound('click');
            }}
            className="p-2 sm:px-3 sm:py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 text-xs font-bold transition-all flex items-center gap-1.5"
            title="وثيقة المشروع الكاملة"
          >
            <FileText className="w-4 h-4 text-purple-400" />
            <span className="hidden md:inline">وثيقة المشروع</span>
          </button>

          {/* Sound Toggle */}
          <button
            onClick={toggleSound}
            className={`p-2 rounded-xl border text-xs transition-colors ${
              audioActive
                ? 'bg-slate-900 border-slate-800 text-slate-300 hover:text-white'
                : 'bg-rose-950/30 border-rose-500/30 text-rose-400'
            }`}
            title={audioActive ? 'كتم المؤثرات الصوتية' : 'تشغيل المؤثرات الصوتية'}
          >
            {audioActive ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          </button>
        </div>
      </div>
    </header>
  );
};
