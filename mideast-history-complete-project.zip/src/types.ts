export type ProjectType = 'game' | 'app';

export interface AudiencePersona {
  name: string;
  age: string;
  description: string;
  usageHabit: string;
  painPoint: string;
  whyTheyLoveIt: string;
}

export interface ScreenButton {
  label: string;
  color: string;
  action: string;
  targetScreen?: string;
  notes: string;
}

export interface ScreenDefinition {
  id: string;
  title: string;
  description: string;
  purpose: string;
  buttons: ScreenButton[];
  keyData: string[];
}

export interface TechOption {
  name: string;
  tag: string;
  isRecommended: boolean;
  difficulty: string;
  androidCompatibility: string;
  cost: string;
  description: string;
  pros: string[];
  cons: string[];
  bestFor: string;
}

export interface CostItem {
  service: string;
  category: 'مجاني بالكامل' | 'اختياري' | 'مدفوع إلزامي للمتجر';
  costAmount: string;
  frequency: 'مرة واحدة' | 'شهرياً' | 'مجاناً للأبد';
  isMandatory: boolean;
  notes: string;
}

export interface ProjectData {
  id: string;
  title: string;
  type: ProjectType;
  slogan: string;
  summary: string;
  coreIdea: string;
  innovations: string[];
  targetAudience: {
    primary: string;
    secondary: string;
    personas: AudiencePersona[];
    usageContext: string;
  };
  designSystem: {
    primaryColor: string;
    secondaryColor: string;
    accentColor: string;
    bgColor: string;
    textColor: string;
    fontFamily: string;
    fontHeading: string;
    thumbErgonomics: string;
    rtlGuidelines: string[];
  };
  screens: ScreenDefinition[];
  techStack: {
    recommended: string;
    justification: string;
    options: TechOption[];
    beginnerTips: string[];
  };
  qaChecklist: {
    id: string;
    title: string;
    category: string;
    status: 'passed' | 'pending' | 'warning';
    details: string;
  }[];
  androidExport: {
    pwaSteps: string[];
    apkSteps: string[];
    capacitorSteps: string[];
    manifestExample: string;
  };
  costBreakdown: CostItem[];
}
