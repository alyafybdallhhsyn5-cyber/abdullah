import React, { useState, useMemo } from 'react';
import { MIDDLE_EAST_COUNTRIES } from './data/middleEastData';
import { Country, EraType } from './types/history';
import { HistoryNavbar } from './components/HistoryNavbar';
import { MiddleEastMap } from './components/MiddleEastMap';
import { CountryDossier } from './components/CountryDossier';
import { EraFilterBar } from './components/EraFilterBar';
import { DesignerModal } from './components/DesignerModal';
import { DesignerBadge } from './components/DesignerBadge';
import { CompareModal } from './components/CompareModal';
import { HistorianQuiz } from './components/HistorianQuiz';
import { RelationsSection } from './components/RelationsSection';
import { WarsSection } from './components/WarsSection';
import { InstallAppModal } from './components/InstallAppModal';
import { useIsStandalone } from './utils/useStandalone';
import { playSound } from './utils/audio';
import { Search, Compass, BookOpen, ArrowLeftRight, Sparkles, Filter, ChevronRight, HeartHandshake, Swords, Smartphone } from 'lucide-react';

export default function App() {
  const isStandalone = useIsStandalone();
  const [selectedCountry, setSelectedCountry] = useState<Country>(MIDDLE_EAST_COUNTRIES[0]);
  const [activeEra, setActiveEra] = useState<EraType>('all');
  const [activeView, setActiveView] = useState<'map' | 'countries' | 'relations' | 'wars' | 'quiz'>('map');
  const [searchQuery, setSearchQuery] = useState('');
  const [isDesignerModalOpen, setIsDesignerModalOpen] = useState(false);
  const [isCompareModalOpen, setIsCompareModalOpen] = useState(false);
  const [isInstallModalOpen, setIsInstallModalOpen] = useState(false);

  // Search results filtering
  const filteredCountries = useMemo(() => {
    if (!searchQuery.trim()) return MIDDLE_EAST_COUNTRIES;
    const query = searchQuery.toLowerCase().trim();
    return MIDDLE_EAST_COUNTRIES.filter((c) => {
      const matchName = c.name.toLowerCase().includes(query);
      const matchCapital = c.capital.toLowerCase().includes(query);
      const matchRegion = c.region.toLowerCase().includes(query);
      const matchEvent = c.events.some((e) => e.title.toLowerCase().includes(query) || e.description.toLowerCase().includes(query));
      return matchName || matchCapital || matchRegion || matchEvent;
    });
  }, [searchQuery]);

  const handleSelectCountryFromCard = (c: Country) => {
    setSelectedCountry(c);
    setActiveView('map');
    playSound('click');
    window.scrollTo({ top: 380, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col justify-between selection:bg-amber-500 selection:text-slate-950 font-sans">
      {/* Top Bar Navigation */}
      <div>
        <HistoryNavbar
          activeView={activeView}
          onSelectView={setActiveView}
          onOpenCompare={() => setIsCompareModalOpen(true)}
          onOpenDesignerModal={() => setIsDesignerModalOpen(true)}
          onOpenInstallModal={() => setIsInstallModalOpen(true)}
          isStandalone={isStandalone}
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
        />

        {/* Hero Section & Quick Search */}
        <section className="relative bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950 border-b border-slate-800/80 px-4 py-8 sm:py-12 overflow-hidden">
          {/* Subtle Decorative Elements */}
          <div className="absolute top-0 right-1/4 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute bottom-0 left-1/4 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />

          <div className="max-w-6xl mx-auto text-center relative z-10 space-y-4">
            <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-semibold">
              <Sparkles className="w-3.5 h-3.5" />
              <span>موسوعة وثائقية تفاعلية شاملة</span>
            </div>

            <h2 className="text-3xl sm:text-5xl font-black text-white font-heading tracking-tight leading-tight max-w-4xl mx-auto">
              تاريخ وحاضر الشرق الأوسط
            </h2>

            <p className="text-sm sm:text-base text-slate-300 max-w-2xl mx-auto leading-relaxed">
              استكشف مسيرة دول الشرق الأوسط عبر العصور: من فجر الحضارات القديمة، ودول الخلافة الإسلامية، إلى قيام الدول الحديثة والنهضة المعاصرة.
            </p>

            {/* Smart Search Bar */}
            <div className="max-w-xl mx-auto relative pt-2">
              <div className="relative flex items-center">
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="ابحث عن دولة، عاصمة، معركة، أو حدث تاريخي (مثال: بابل، القادسية، رؤية 2030)..."
                  className="w-full bg-slate-900/90 border border-slate-700/80 rounded-2xl py-3.5 pr-11 pl-10 text-xs sm:text-sm text-white placeholder:text-slate-500 focus:outline-none focus:border-amber-500 transition-colors shadow-xl text-right"
                />
                <Search className="w-5 h-5 text-slate-400 absolute right-3.5 pointer-events-none" />
                {searchQuery && (
                  <button
                    onClick={() => setSearchQuery('')}
                    className="absolute left-3 text-xs text-slate-400 hover:text-white"
                  >
                    مسح
                  </button>
                )}
              </div>

              {/* Live search feedback */}
              {searchQuery && (
                <div className="text-right text-xs text-amber-300 mt-2 px-1">
                  تم العثور على {filteredCountries.length} دولة مطابقة
                </div>
              )}

              {/* Quick Navigation Action Buttons */}
              <div className="flex flex-wrap items-center justify-center gap-2 pt-3">
                <button
                  onClick={() => {
                    setActiveView('map');
                    playSound('click');
                  }}
                  className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all border ${
                    activeView === 'map'
                      ? 'bg-amber-500 text-slate-950 border-amber-400'
                      : 'bg-slate-900/80 border-slate-700 text-slate-300 hover:text-white'
                  }`}
                >
                  الخريطة التفاعلية 🗺️
                </button>

                <button
                  onClick={() => {
                    setActiveView('relations');
                    playSound('click');
                  }}
                  className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all border flex items-center gap-1.5 ${
                    activeView === 'relations'
                      ? 'bg-amber-500 text-slate-950 border-amber-400 shadow-md shadow-amber-500/20'
                      : 'bg-amber-500/10 border-amber-500/30 text-amber-300 hover:bg-amber-500/20'
                  }`}
                >
                  <HeartHandshake className="w-3.5 h-3.5" />
                  <span>قسم العلاقات والتاريخ المشترك 🤝</span>
                </button>

                <button
                  onClick={() => {
                    setActiveView('wars');
                    playSound('click');
                  }}
                  className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all border flex items-center gap-1.5 ${
                    activeView === 'wars'
                      ? 'bg-red-600 text-white border-red-500 shadow-md shadow-red-600/30 font-black'
                      : 'bg-red-950/40 border-red-800/60 text-red-300 hover:bg-red-900/40'
                  }`}
                >
                  <Swords className="w-3.5 h-3.5" />
                  <span>الحروب والصراعات الكبرى ⚔️</span>
                </button>

                <button
                  onClick={() => {
                    setActiveView('countries');
                    playSound('click');
                  }}
                  className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all border ${
                    activeView === 'countries'
                      ? 'bg-amber-500 text-slate-950 border-amber-400'
                      : 'bg-slate-900/80 border-slate-700 text-slate-300 hover:text-white'
                  }`}
                >
                  دليل الدول 🏛️
                </button>

                <button
                  onClick={() => {
                    setActiveView('quiz');
                    playSound('click');
                  }}
                  className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all border ${
                    activeView === 'quiz'
                      ? 'bg-amber-500 text-slate-950 border-amber-400'
                      : 'bg-slate-900/80 border-slate-700 text-slate-300 hover:text-white'
                  }`}
                >
                  تحدي المؤرخ 🏆
                </button>

                {!isStandalone && (
                  <button
                    onClick={() => {
                      setIsInstallModalOpen(true);
                      playSound('click');
                    }}
                    className="px-3.5 py-1.5 rounded-xl text-xs font-black transition-all border flex items-center gap-1.5 bg-gradient-to-r from-emerald-500/20 to-teal-500/20 hover:from-emerald-500/30 hover:to-teal-500/30 border-emerald-500/40 text-emerald-300 shadow-sm"
                  >
                    <Smartphone className="w-3.5 h-3.5 text-emerald-400" />
                    <span>تحويل وتثبيت التطبيق على هاتف Android 📱</span>
                  </button>
                )}
              </div>
            </div>
          </div>
        </section>

        {/* Main Content Area */}
        <main className="max-w-6xl mx-auto px-4 py-6 sm:py-8 space-y-8">
          {/* Era Filter Toolbar */}
          <EraFilterBar
            activeEra={activeEra}
            onSelectEra={setActiveEra}
          />

          {/* VIEW 1: Interactive Map + Dossier */}
          {activeView === 'map' && (
            <div className="space-y-8 animate-in fade-in">
              {/* Interactive SVG Map */}
              <MiddleEastMap
                countries={filteredCountries}
                selectedCountry={selectedCountry}
                onSelectCountry={(c) => setSelectedCountry(c)}
                activeEra={activeEra}
              />

              {/* Detailed Country Dossier & Timeline */}
              <CountryDossier
                country={selectedCountry}
                activeEra={activeEra}
                onSelectEra={setActiveEra}
              />
            </div>
          )}

          {/* VIEW 2: Countries Directory Grid */}
          {activeView === 'countries' && (
            <div className="space-y-6 animate-in fade-in">
              <div className="flex items-center justify-between">
                <h3 className="text-xl font-bold text-white font-heading">
                  دليل دول الشرق الأوسط ({filteredCountries.length})
                </h3>
                <span className="text-xs text-slate-400">انقر على أي دولة لفتح ملفها الكامل</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {filteredCountries.map((c) => (
                  <div
                    key={c.id}
                    onClick={() => handleSelectCountryFromCard(c)}
                    className="bg-slate-900/90 border border-slate-800 hover:border-amber-500/50 rounded-2xl p-5 cursor-pointer transition-all hover:scale-[1.01] flex flex-col justify-between text-right group shadow-lg"
                  >
                    <div>
                      <div className="flex items-center justify-between mb-3">
                        <span className="text-4xl filter drop-shadow">{c.flag}</span>
                        <span className="text-[11px] font-mono bg-slate-950 text-amber-400 px-2 py-0.5 rounded-md border border-slate-800">
                          {c.region}
                        </span>
                      </div>

                      <h4 className="text-lg font-black text-white font-heading group-hover:text-amber-300 transition-colors">
                        {c.name}
                      </h4>
                      <div className="text-xs text-slate-400 font-mono mt-0.5">
                        العاصمة: {c.capital}
                      </div>

                      <p className="text-xs text-slate-300 mt-2.5 line-clamp-2 leading-relaxed">
                        {c.summary}
                      </p>
                    </div>

                    <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs">
                      <span className="text-slate-400 font-mono">
                        {c.events.length} محطات موثقة
                      </span>
                      <span className="text-amber-400 font-semibold flex items-center gap-1 group-hover:translate-x-[-4px] transition-transform">
                        <span>استعراض الملف</span>
                        <ChevronRight className="w-3.5 h-3.5 rotate-180" />
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* VIEW 3: Bilateral Relations & Shared History */}
          {activeView === 'relations' && (
            <div className="space-y-6 animate-in fade-in">
              <RelationsSection countries={MIDDLE_EAST_COUNTRIES} />
            </div>
          )}

          {/* VIEW 4: Major Wars & Conflicts */}
          {activeView === 'wars' && (
            <div className="space-y-6 animate-in fade-in">
              <WarsSection
                onSelectCountry={(cid) => {
                  const target = MIDDLE_EAST_COUNTRIES.find(c => c.id === cid);
                  if (target) {
                    setSelectedCountry(target);
                    setActiveView('map');
                    window.scrollTo({ top: 380, behavior: 'smooth' });
                  }
                }}
              />
            </div>
          )}

          {/* VIEW 5: Historian Quiz */}
          {activeView === 'quiz' && (
            <div className="space-y-6">
              <HistorianQuiz />
            </div>
          )}

          {/* Prominent Designer Profile Section */}
          <section className="pt-4">
            <DesignerBadge
              onOpenModal={() => setIsDesignerModalOpen(true)}
              variant="card"
            />
          </section>
        </main>
      </div>

      {/* Global Footer */}
      <footer className="w-full bg-slate-950 border-t border-slate-800/80 py-6 px-4 mt-12">
        <div className="max-w-6xl mx-auto space-y-4">
          <DesignerBadge
            onOpenModal={() => setIsDesignerModalOpen(true)}
            variant="footer"
          />
        </div>
      </footer>

      {/* Designer Profile Modal */}
      <DesignerModal
        isOpen={isDesignerModalOpen}
        onClose={() => setIsDesignerModalOpen(false)}
      />

      {/* Comparison Modal */}
      <CompareModal
        isOpen={isCompareModalOpen}
        onClose={() => setIsCompareModalOpen(false)}
        countries={MIDDLE_EAST_COUNTRIES}
      />

      {/* Android Installation & Export Modal */}
      <InstallAppModal
        isOpen={isInstallModalOpen}
        onClose={() => setIsInstallModalOpen(false)}
      />
    </div>
  );
}
