import React, { createContext, useContext, useEffect, useState } from 'react';
import { User, signInWithPopup, signOut, onIdTokenChanged } from 'firebase/auth';
import { auth, googleAuthProvider } from '../lib/firebase.ts';

export interface CloudBookmark {
  id: number;
  userId: number;
  itemType: string;
  itemId: string;
  title: string;
  notes: string | null;
  createdAt: string;
}

export interface CloudQuizScore {
  id: number;
  userId: number;
  category: string;
  score: number;
  total: number;
  completedAt: string;
}

interface AuthContextType {
  user: User | null;
  token: string | null;
  loading: boolean;
  signInWithGoogle: () => Promise<void>;
  signOutUser: () => Promise<void>;
  bookmarks: CloudBookmark[];
  refreshBookmarks: () => Promise<void>;
  addBookmark: (itemType: string, itemId: string, title: string, notes?: string) => Promise<void>;
  removeBookmark: (id: number) => Promise<void>;
  quizScores: CloudQuizScore[];
  saveQuizScore: (category: string, score: number, total: number) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [bookmarks, setBookmarks] = useState<CloudBookmark[]>([]);
  const [quizScores, setQuizScores] = useState<CloudQuizScore[]>([]);

  useEffect(() => {
    const unsubscribe = onIdTokenChanged(auth, async (currentUser) => {
      setUser(currentUser);
      if (currentUser) {
        try {
          const idToken = await currentUser.getIdToken();
          setToken(idToken);
          // Sync user to Cloud SQL database
          await fetch('/api/auth/sync', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              Authorization: `Bearer ${idToken}`,
            },
            body: JSON.stringify({
              email: currentUser.email,
              name: currentUser.displayName,
              picture: currentUser.photoURL,
            }),
          });
          // Load bookmarks and quiz scores
          await loadUserData(idToken);
        } catch (err) {
          console.error('Failed to sync user with Cloud SQL backend:', err);
        }
      } else {
        setToken(null);
        setBookmarks([]);
        setQuizScores([]);
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const loadUserData = async (activeToken: string) => {
    try {
      const [bmRes, qsRes] = await Promise.all([
        fetch('/api/bookmarks', {
          headers: { Authorization: `Bearer ${activeToken}` },
        }),
        fetch('/api/quiz-scores', {
          headers: { Authorization: `Bearer ${activeToken}` },
        }),
      ]);

      if (bmRes.ok) {
        const bms = await bmRes.json();
        setBookmarks(bms);
      }
      if (qsRes.ok) {
        const scores = await qsRes.json();
        setQuizScores(scores);
      }
    } catch (err) {
      console.error('Failed to load user cloud data:', err);
    }
  };

  const refreshBookmarks = async () => {
    if (!token) return;
    try {
      const res = await fetch('/api/bookmarks', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        setBookmarks(data);
      }
    } catch (err) {
      console.error('Failed to refresh bookmarks:', err);
    }
  };

  const signInWithGoogle = async () => {
    try {
      const result = await signInWithPopup(auth, googleAuthProvider);
      const idToken = await result.user.getIdToken();
      setToken(idToken);
    } catch (error) {
      console.error('Error signing in with Google:', error);
      throw error;
    }
  };

  const signOutUser = async () => {
    try {
      await signOut(auth);
      setToken(null);
      setUser(null);
      setBookmarks([]);
      setQuizScores([]);
    } catch (error) {
      console.error('Error signing out:', error);
      throw error;
    }
  };

  const addBookmark = async (itemType: string, itemId: string, title: string, notes?: string) => {
    if (!token) return;
    try {
      const res = await fetch('/api/bookmarks', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ itemType, itemId, title, notes }),
      });
      if (res.ok) {
        const newBm = await res.json();
        setBookmarks((prev) => [newBm, ...prev]);
      }
    } catch (err) {
      console.error('Failed to add bookmark to Cloud SQL:', err);
    }
  };

  const removeBookmark = async (id: number) => {
    if (!token) return;
    try {
      const res = await fetch(`/api/bookmarks/${id}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        setBookmarks((prev) => prev.filter((b) => b.id !== id));
      }
    } catch (err) {
      console.error('Failed to delete bookmark from Cloud SQL:', err);
    }
  };

  const saveQuizScore = async (category: string, score: number, total: number) => {
    if (!token) return;
    try {
      const res = await fetch('/api/quiz-scores', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ category, score, total }),
      });
      if (res.ok) {
        const saved = await res.json();
        setQuizScores((prev) => [saved, ...prev]);
      }
    } catch (err) {
      console.error('Failed to save score to Cloud SQL:', err);
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        token,
        loading,
        signInWithGoogle,
        signOutUser,
        bookmarks,
        refreshBookmarks,
        addBookmark,
        removeBookmark,
        quizScores,
        saveQuizScore,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
