import { db } from './index.ts';
import { bookmarks, users } from './schema.ts';
import { eq, and } from 'drizzle-orm';

export async function getUserBookmarksByUid(uid: string) {
  try {
    const user = await db.select({ id: users.id }).from(users).where(eq(users.uid, uid)).limit(1);
    if (!user.length) return [];
    return await db.select().from(bookmarks).where(eq(bookmarks.userId, user[0].id));
  } catch (error) {
    console.error("Database fetch bookmarks failed:", error);
    throw new Error("Database query failed. Please try again later.", { cause: error });
  }
}

export async function addUserBookmark(uid: string, itemType: string, itemId: string, title: string, notes?: string) {
  try {
    const user = await db.select({ id: users.id }).from(users).where(eq(users.uid, uid)).limit(1);
    if (!user.length) throw new Error("User record not found");
    const result = await db.insert(bookmarks).values({
      userId: user[0].id,
      itemType,
      itemId,
      title,
      notes: notes || null,
    }).returning();
    return result[0];
  } catch (error) {
    console.error("Database add bookmark failed:", error);
    throw new Error("Database query failed. Please try again later.", { cause: error });
  }
}

export async function removeUserBookmark(uid: string, bookmarkId: number) {
  try {
    const user = await db.select({ id: users.id }).from(users).where(eq(users.uid, uid)).limit(1);
    if (!user.length) throw new Error("User record not found");
    return await db.delete(bookmarks).where(and(eq(bookmarks.id, bookmarkId), eq(bookmarks.userId, user[0].id))).returning();
  } catch (error) {
    console.error("Database remove bookmark failed:", error);
    throw new Error("Database query failed. Please try again later.", { cause: error });
  }
}
