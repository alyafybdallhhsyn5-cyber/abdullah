import { db } from './index.ts';
import { quizScores, users } from './schema.ts';
import { eq, desc } from 'drizzle-orm';

export async function getUserQuizScoresByUid(uid: string) {
  try {
    const user = await db.select({ id: users.id }).from(users).where(eq(users.uid, uid)).limit(1);
    if (!user.length) return [];
    return await db.select().from(quizScores).where(eq(quizScores.userId, user[0].id)).orderBy(desc(quizScores.completedAt));
  } catch (error) {
    console.error("Database fetch quiz scores failed:", error);
    throw new Error("Database query failed. Please try again later.", { cause: error });
  }
}

export async function saveUserQuizScore(uid: string, category: string, score: number, total: number) {
  try {
    const user = await db.select({ id: users.id }).from(users).where(eq(users.uid, uid)).limit(1);
    if (!user.length) throw new Error("User record not found");
    const result = await db.insert(quizScores).values({
      userId: user[0].id,
      category,
      score,
      total,
    }).returning();
    return result[0];
  } catch (error) {
    console.error("Database save quiz score failed:", error);
    throw new Error("Database query failed. Please try again later.", { cause: error });
  }
}
