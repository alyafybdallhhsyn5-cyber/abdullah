import { relations } from 'drizzle-orm';
import { integer, pgTable, serial, text, timestamp } from 'drizzle-orm/pg-core';

// Define the 'users' table
export const users = pgTable('users', {
  id: serial('id').primaryKey(),
  uid: text('uid').notNull().unique(), // Firebase Auth UID
  email: text('email').notNull(),
  displayName: text('display_name'),
  photoURL: text('photo_url'),
  createdAt: timestamp('created_at').defaultNow(),
});

// Define the 'bookmarks' table
export const bookmarks = pgTable('bookmarks', {
  id: serial('id').primaryKey(),
  userId: integer('user_id')
    .references(() => users.id, { onDelete: 'cascade' })
    .notNull(),
  itemType: text('item_type').notNull(), // 'country' | 'historical_event' | 'article'
  itemId: text('item_id').notNull(),
  title: text('title').notNull(),
  notes: text('notes'),
  createdAt: timestamp('created_at').defaultNow(),
});

// Define the 'quiz_scores' table
export const quizScores = pgTable('quiz_scores', {
  id: serial('id').primaryKey(),
  userId: integer('user_id')
    .references(() => users.id, { onDelete: 'cascade' })
    .notNull(),
  category: text('category').notNull(),
  score: integer('score').notNull(),
  total: integer('total').notNull(),
  completedAt: timestamp('completed_at').defaultNow(),
});

// Define relationships
export const usersRelations = relations(users, ({ many }) => ({
  bookmarks: many(bookmarks),
  quizScores: many(quizScores),
}));

export const bookmarksRelations = relations(bookmarks, ({ one }) => ({
  user: one(users, {
    fields: [bookmarks.userId],
    references: [users.id],
  }),
}));

export const quizScoresRelations = relations(quizScores, ({ one }) => ({
  user: one(users, {
    fields: [quizScores.userId],
    references: [users.id],
  }),
}));
