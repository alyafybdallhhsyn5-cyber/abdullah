export type EraType = 'all' | 'ancient' | 'islamic' | 'modern' | 'contemporary';

export type EventCategory = 'حضارة وآثار' | 'إسلامي وخلافة' | 'سياسي ومعاهدات' | 'اقتصادي ونفط' | 'معارك وفتوحات' | 'نهضة وتنمية';

export interface HistoricalEvent {
  id: string;
  year: string;
  exactDate?: string;
  era: 'ancient' | 'islamic' | 'modern' | 'contemporary';
  title: string;
  description: string;
  extendedDetails?: string;
  category: EventCategory;
  keyFigures?: string[];
  impact: string;
  location?: string;
}

export interface Landmark {
  name: string;
  period: string;
  description: string;
  type: string;
}

export interface Country {
  id: string;
  name: string;
  officialName: string;
  capital: string;
  flag: string;
  region: 'الخليج العربي' | 'بلاد الشام' | 'وادي النيل وشمال إفريقيا' | 'الجزيرة العربية';
  areaKm2: number;
  population: string;
  currency: string;
  coordinates: { x: number; y: number }; // Relative percentage coordinates on SVG map
  mapPathId?: string;
  color: string;
  summary: string;
  ancientCivilizations: string[];
  modernVision: string;
  economicPillars: string[];
  landmarks: Landmark[];
  events: HistoricalEvent[];
}

export interface QuizQuestion {
  id: string;
  countryId: string;
  countryName: string;
  era: string;
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

export interface DesignerProfile {
  name: string;
  instagram: string;
  instagramUrl: string;
  role: string;
  title: string;
  bio: string;
}

export interface BilateralEvent {
  year: string;
  title: string;
  description: string;
  impact: string;
}

export interface BilateralRelation {
  id: string;
  country1Id: string;
  country2Id: string;
  title: string;
  nature: string;
  summary: string;
  historicalDepth: string;
  geographicCulturalTies: string[];
  keyTreatiesAndAgreements: string[];
  economicCooperation: string;
  sharedEvents: BilateralEvent[];
  modernDevelopments: string;
}

export interface RegionalWar {
  id: string;
  name: string;
  alternativeNames?: string[];
  period: string;
  startDate: string;
  endDate?: string;
  category: 'حروب التحرير العربية الإسرائيلية' | 'حروب الخليج والشرق الأوسط' | 'صراعات داخلية وإقليمية معاصرة' | 'نزاعات الحدود والسيادة';
  parties: {
    sideA: { name: string; countries: string[]; leaders?: string[] };
    sideB: { name: string; countries: string[]; leaders?: string[] };
  };
  causes: string[];
  keyBattles: { name: string; date: string; description: string }[];
  outcomes: string[];
  geopoliticalImpact: string;
  relatedCountryIds: string[];
}
